import { getProviderConnectionById, updateProviderConnection } from "@/lib/localDb";
import { resolveConnectionProxyConfig } from "@/lib/network/connectionProxy";
import { testProxyUrl } from "@/lib/network/proxyTest";
import { isOpenAICompatibleProvider, isAnthropicCompatibleProvider, USAGE_SUPPORTED_PROVIDERS } from "@/shared/constants/providers";
import { getDefaultModel } from "open-sse/config/providerModels.js";
import { CODEX_CLI_VERSION } from "open-sse/config/appConstants.js";
import { GROK_CLI_PAGER_USER_AGENT, GROK_CLI_VERSION } from "open-sse/config/grokCli.js";
import { resolveOllamaLocalHost, PROVIDERS } from "open-sse/config/providers.js";
import { getUsageForProvider } from "open-sse/services/usage.js";
import { extractEarliestPackageExpiry } from "open-sse/services/usage/expiryExtractor.js";
import { resolveQoderModels } from "open-sse/services/qoderModels.js";
import { QODER_USERINFO_URL, QODER_CN_USERINFO_URL } from "open-sse/shared/qoder/constants.js";
import { MODEL_LOCK_PREFIX } from "open-sse/services/accountFallback.js";
import {
  refreshProviderCredentials,
  shouldRefreshCredentials,
} from "open-sse/services/oauthCredentialManager.js";
import {
  GEMINI_CONFIG,
  ANTIGRAVITY_CONFIG,
  KIRO_CONFIG,
  CLAUDE_CONFIG,
  CLINE_CONFIG,
  KILOCODE_CONFIG,
  KIMCHI_CONFIG,
} from "@/lib/oauth/constants/oauth";
import { buildClineHeaders } from "@/shared/utils/clineAuth";
import { buildAccountValidationMessage } from "open-sse/utils/error.js";
import { assertAntigravityAllowed, checkAntigravityResponse, isAntigravityBlockError } from "open-sse/services/antigravityQuarantine.js";

// OAuth provider test endpoints
const OAUTH_TEST_CONFIG = {
  claude: { checkExpiry: true, refreshable: true },
  codex: {
    url: "https://chatgpt.com/backend-api/codex/responses",
    method: "POST",
    authHeader: "Authorization",
    authPrefix: "Bearer ",
    extraHeaders: { "Content-Type": "application/json", "originator": "codex_cli_rs", "User-Agent": `codex_cli_rs/${CODEX_CLI_VERSION}` },
    // Minimal invalid body — triggers fast 400 without consuming quota
    body: JSON.stringify({ model: "gpt-5.3-codex", input: [], stream: false, store: false }),
    // 400 (bad request) means auth succeeded; only 401/403 means token is bad
    acceptStatuses: [400],
    refreshable: true,
  },
  "gemini-cli": {
    url: "https://www.googleapis.com/oauth2/v1/userinfo?alt=json",
    method: "GET",
    authHeader: "Authorization",
    authPrefix: "Bearer ",
    refreshable: true,
  },
  antigravity: {
    url: "https://www.googleapis.com/oauth2/v1/userinfo?alt=json",
    method: "GET",
    authHeader: "Authorization",
    authPrefix: "Bearer ",
    refreshable: true,
  },
  github: {
    url: "https://api.github.com/user",
    method: "GET",
    authHeader: "Authorization",
    authPrefix: "Bearer ",
    extraHeaders: { "User-Agent": "10Router", "Accept": "application/vnd.github+json" },
  },
  iflow: {
    // iFlow getUserInfo requires accessToken as query param, not header
    buildUrl: (token) => `https://iflow.cn/api/oauth/getUserInfo?accessToken=${encodeURIComponent(token)}`,
    method: "GET",
    noAuth: true,
  },
  kiro: { checkExpiry: true, refreshable: true },
  // qoder / qoder-cn are handled by testQoderConnection (short-circuited at the
  // top of testOAuthConnection): the one-by-one picker can select a model, and
  // verifying it needs the account's live catalog, not a plain userinfo probe.
  kimi: { checkExpiry: true, refreshable: true },
  "kimi-coding": { checkExpiry: true, refreshable: true },
  cursor: { tokenExists: true },
  kilocode: {
    url: `${KILOCODE_CONFIG.apiBaseUrl}/api/profile`,
    method: "GET",
    authHeader: "Authorization",
    authPrefix: "Bearer ",
  },
  cline: { refreshable: true },
  gitlab: {
    // Test by hitting the GitLab user API — requires api or read_user scope
    url: "https://gitlab.com/api/v4/user",
    method: "GET",
    authHeader: "Authorization",
    authPrefix: "Bearer ",
  },
  "codebuddy-cn": { tokenExists: true },
  // Same shape as CN: the connection carries an OAuth access token and the
  // gateway exposes no cheap token-validation endpoint, so presence of the
  // token *is* the probe. Missing this entry made the dashboard's Test button
  // answer "Provider test not supported" for an otherwise healthy intl account
  // (routing was never affected — only this test path).
  "codebuddy-intl": { tokenExists: true },
  kimchi: {
    url: KIMCHI_CONFIG.validationUrl || "https://api.cast.ai/v1/llm/openai/supported-providers",
    method: "GET",
    authHeader: "Authorization",
    authPrefix: "Bearer ",
    extraHeaders: {
      Accept: "application/json",
      "User-Agent": "kimchi/0.1.40",
    },
    refreshable: false,
  },
  // Grok CLI / Grok Build — probe /v1/user (no inference quota). Headers mirror official CLI.
  "grok-cli": {
    url: PROVIDERS["grok-cli"]?.userUrl || "https://cli-chat-proxy.grok.com/v1/user",
    method: "GET",
    authHeader: "Authorization",
    authPrefix: "Bearer ",
    extraHeaders: {
      Accept: "application/json",
      ...(PROVIDERS["grok-cli"]?.headers || {
        "User-Agent": GROK_CLI_PAGER_USER_AGENT,
        "x-xai-token-auth": "xai-grok-cli",
        "x-grok-client-identifier": "grok-pager",
        "x-grok-client-version": GROK_CLI_VERSION,
      }),
    },
    refreshable: true,
    // Subscription spending-limit is not an auth failure — token is fine, credits aren't.
    // Accept 402 so the connection stays "active" with a warning (same idea as Codex 400).
    acceptStatuses: [402],
    softFailMessage: {
      402: "Connected, but Grok Build credits are exhausted (spending limit). Add credits or upgrade SuperGrok.",
    },
  },
  // Muse Code 订阅 —— 用铸造的 LLM|… key 探 /v1/models（无 refresh，401 即重新登录）
  "muse": {
    url: "https://api.meta.ai/v1/models",
    method: "GET",
    authHeader: "Authorization",
    authPrefix: "Bearer ",
    extraHeaders: { "x-api-version": "1.0.0" },
    refreshable: false,
  },
};

/**
 * Classify an OAuth probe response as success / soft-success / hard-fail.
 * Soft success (e.g. 402 spending-limit on Grok CLI) means auth works but the
 * account cannot spend — keep connection active and surface a warning.
 * Exported for unit tests.
 */
export function classifyOAuthProbeResult(res, config, bodyText = "") {
  if (!res) return { valid: false, error: "No response", soft: false };
  const status = res.status;
  const accepted = res.ok || (config?.acceptStatuses && config.acceptStatuses.includes(status));
  if (!accepted) {
    if (status === 401) return { valid: false, error: "Token invalid or revoked", soft: false };
    if (status === 403) return { valid: false, error: "Access denied", soft: false };
    return { valid: false, error: `API returned ${status}`, soft: false };
  }

  // Soft success only when the provider configured an explicit message for this
  // status (e.g. Grok CLI 402 spending-limit). Codex-style acceptStatuses:[400]
  // stays silent success — 400 there only proves auth, not a user-facing warning.
  if (!res.ok && config?.acceptStatuses?.includes(status)) {
    const softMap = config.softFailMessage || {};
    if (softMap[status]) {
      return { valid: true, error: softMap[status], soft: true };
    }
    return { valid: true, error: null, soft: false };
  }

  return { valid: true, error: null, soft: false };
}

async function probeClineAccessToken(accessToken) {
  const res = await fetch("https://api.cline.bot/api/v1/users/me", {
    method: "GET",
    headers: buildClineHeaders(accessToken, {
      Accept: "application/json",
    }),
  });

  return res;
}

const CLOUD_CODE_ASSIST_TEST_URL = "https://cloudcode-pa.googleapis.com/v1internal:loadCodeAssist";
const CLOUD_CODE_ASSIST_TEST_BODY = JSON.stringify({
  metadata: {
    ideType: "IDE_UNSPECIFIED",
    platform: "PLATFORM_UNSPECIFIED",
    pluginType: "GEMINI",
  },
});

function parseProviderErrorMessage(bodyText, fallback) {
  if (!bodyText) return fallback;
  try {
    const parsed = JSON.parse(bodyText);
    const message = parsed?.error?.message || parsed?.message || parsed?.error;
    if (typeof message === "string" && message.trim()) return message.trim();
    if (message) return JSON.stringify(message);
  } catch {
    // fall through
  }
  return bodyText.trim() || fallback;
}

/**
 * Error message for a failed cloudcode-pa probe (antigravity / gemini-cli).
 *
 * Google gates a risk-flagged account with 403 VALIDATION_REQUIRED and puts the
 * one-click "Verify your account" URL inside the response body. Surface that URL —
 * the bare error.message ("Verify your account to continue.") leaves the user with
 * no next step. Exported for unit tests.
 */
export function buildCloudCodeProbeError(bodyText, fallbackStatus) {
  return (
    buildAccountValidationMessage(bodyText) ||
    parseProviderErrorMessage(bodyText, `API returned ${fallbackStatus}`)
  );
}

async function probeCloudCodeAssistAccess(connection, accessToken, effectiveProxy = null) {
  if (connection.provider === "antigravity") await assertAntigravityAllowed(connection);
  const userAgent = connection.provider === "antigravity"
    ? "google-api-nodejs-client/9.15.1 vscode-antigravity/1.107.0"
    : "google-api-nodejs-client/9.15.1 gemini-cli/0.34.0";

  const res = await fetchWithConnectionProxy(CLOUD_CODE_ASSIST_TEST_URL, {
    ...(connection.provider === "antigravity" && { antigravityCredentials: connection }),
    method: "POST",
    headers: {
      "Authorization": `Bearer ${accessToken}`,
      "Content-Type": "application/json",
      "User-Agent": userAgent,
    },
    body: CLOUD_CODE_ASSIST_TEST_BODY,
  }, effectiveProxy);

  if (connection.provider === "antigravity") await checkAntigravityResponse(res, connection, console);
  if (res.ok) return { valid: true, error: null };

  const bodyText = await res.text().catch(() => "");
  return {
    valid: false,
    error: buildCloudCodeProbeError(bodyText, res.status),
    status: res.status,
  };
}

async function refreshOAuthToken(connection) {
  const provider = connection.provider;
  const refreshToken = connection.refreshToken;
  if (!refreshToken) return null;

  try {
    if (provider === "gemini-cli" || provider === "antigravity") {
      if (provider === "antigravity") await assertAntigravityAllowed(connection);
      const config = provider === "gemini-cli" ? GEMINI_CONFIG : ANTIGRAVITY_CONFIG;
      const response = await fetch("https://oauth2.googleapis.com/token", {
        ...(provider === "antigravity" && { antigravityCredentials: connection }),
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          client_id: config.clientId,
          client_secret: config.clientSecret,
          grant_type: "refresh_token",
          refresh_token: refreshToken,
        }),
      });
      if (provider === "antigravity") await checkAntigravityResponse(response, connection, console);
      if (!response.ok) return null;
      const data = await response.json();
      return { accessToken: data.access_token, expiresIn: data.expires_in, refreshToken: data.refresh_token || refreshToken };
    }

    if (provider === "codex" || provider === "grok-cli" || provider === "xai") {
      return await refreshProviderCredentials(provider, connection, console);
    }

    if (provider === "claude") {
      const response = await fetch(CLAUDE_CONFIG.tokenUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Accept": "application/json" },
        body: JSON.stringify({
          grant_type: "refresh_token",
          refresh_token: refreshToken,
          client_id: CLAUDE_CONFIG.clientId,
        }),
      });
      if (!response.ok) return null;
      const data = await response.json();
      return { accessToken: data.access_token, expiresIn: data.expires_in, refreshToken: data.refresh_token || refreshToken };
    }

    if (provider === "kiro") {
      const psd = connection.providerSpecificData || {};
      const clientId = psd.clientId || connection.clientId;
      const clientSecret = psd.clientSecret || connection.clientSecret;
      const region = psd.region || connection.region;
      if (clientId && clientSecret) {
        const endpoint = `https://oidc.${region || "us-east-1"}.amazonaws.com/token`;
        const response = await fetch(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ clientId, clientSecret, refreshToken, grantType: "refresh_token" }),
        });
        if (!response.ok) return null;
        const data = await response.json();
        return { accessToken: data.accessToken, expiresIn: data.expiresIn || 3600, refreshToken: data.refreshToken || refreshToken };
      }
      const response = await fetch(KIRO_CONFIG.socialRefreshUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json", "User-Agent": "kiro-cli/1.0.0" },
        body: JSON.stringify({ refreshToken }),
      });
      if (!response.ok) return null;
      const data = await response.json();
      return { accessToken: data.accessToken, expiresIn: data.expiresIn || 3600, refreshToken: data.refreshToken || refreshToken };
    }

    if (provider === "cline") {
      const response = await fetch(CLINE_CONFIG.refreshUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({
          refreshToken,
          grantType: "refresh_token",
          clientType: "extension",
        }),
      });
      if (!response.ok) return null;
      const payload = await response.json();
      const data = payload?.data || payload;
      const expiresIn = data?.expiresAt
        ? Math.max(1, Math.floor((new Date(data.expiresAt).getTime() - Date.now()) / 1000))
        : 3600;
      return {
        accessToken: data?.accessToken,
        expiresIn,
        refreshToken: data?.refreshToken || refreshToken,
      };
    }

    return null;
  } catch (err) {
    if (isAntigravityBlockError(err)) throw err;
    console.log(`Error refreshing ${provider} token:`, err.message);
    return null;
  }
}

function isTokenExpired(connection) {
  return shouldRefreshCredentials(connection.provider, connection);
}

/**
 * Qoder / Qoder CN connection test.
 *
 * Qoder's inference endpoint is a proprietary COSY-signed protocol, so a chat
 * probe would be heavy and would spend credits. Instead we fetch the account's
 * live model catalog (a COSY-signed GET /model/list — no inference, no credits),
 * which both proves the credential works AND enumerates the models this account
 * may call. A selected model is validated by its ALIAS (the catalog key, e.g.
 * "qmodel_38max"), never its display name — sending the display name is exactly
 * what used to 400 upstream.
 *
 * `options.model` is the one-by-one picker's selection (a registry id / alias).
 * With no selection, a non-empty catalog is a passing token check. On a
 * catalog-fetch failure we fall back to the cheap userinfo probe so a transient
 * blip does not mark a good credential broken.
 */
// Aggregator / virtual ids route to a real model server-side, so they never
// appear as their own key in the raw /model/list catalog — for these, a
// non-empty catalog IS the availability check.
const QODER_VIRTUAL_MODELS = new Set(["auto", "efficient"]);

async function testQoderConnection(connection, effectiveProxy = null, options = {}) {
  const { model } = options;

  let catalog = null;
  try {
    // forceRefresh: a Test button must reflect the account NOW, not the 1h cache.
    catalog = await resolveQoderModels(connection, { proxyOptions: effectiveProxy, forceRefresh: true });
  } catch {
    catalog = null;
  }

  if (catalog && Array.isArray(catalog.models)) {
    const nonEmpty = catalog.models.length > 0;
    if (model && !QODER_VIRTUAL_MODELS.has(model)) {
      const available = catalog.models.some((m) => m.id === model);
      return available
        ? { valid: true, error: null, refreshed: false }
        : { valid: false, error: `Model "${model}" is not available on this Qoder account`, refreshed: false };
    }
    // No model, or a virtual/aggregator id: a non-empty catalog proves the account.
    return nonEmpty
      ? { valid: true, error: null, refreshed: false }
      : { valid: false, error: "No models available on this Qoder account", refreshed: false };
  }

  // Catalog unavailable (COSY signing needs a userId, or a transient failure):
  // fall back to the userinfo probe so a good token is not marked broken.
  if (!connection.accessToken) return { valid: false, error: "No access token", refreshed: false };
  const userinfoUrl = connection.provider === "qoder-cn" ? QODER_CN_USERINFO_URL : QODER_USERINFO_URL;
  try {
    const res = await fetchWithConnectionProxy(
      userinfoUrl,
      {
        method: "GET",
        headers: { Authorization: `Bearer ${connection.accessToken}`, Accept: "application/json", "User-Agent": "qodercli/1.0.0" },
      },
      effectiveProxy,
    );
    if (!res.ok) {
      const revoked = res.status === 401 || res.status === 403;
      return { valid: false, error: revoked ? "Token invalid or expired" : `Qoder userinfo error (${res.status})`, refreshed: false };
    }
    // Token is good, but the catalog was unreachable so the picked model could
    // not be verified — pass with a warning rather than a hard failure.
    return model
      ? { valid: true, warning: "Credential OK, but model availability could not be verified (catalog unavailable)", error: null, refreshed: false }
      : { valid: true, error: null, refreshed: false };
  } catch (err) {
    return { valid: false, error: `Qoder test failed: ${err.message}`, refreshed: false };
  }
}

async function testOAuthConnection(connection, effectiveProxy = null, options = {}) {
  // Qoder's test is model-aware and needs the live catalog — handled here, not
  // via OAUTH_TEST_CONFIG (which qoder-cn was never in, so it answered "Provider
  // test not supported" for an otherwise healthy account).
  if (connection.provider === "qoder" || connection.provider === "qoder-cn") {
    return testQoderConnection(connection, effectiveProxy, options);
  }
  const config = OAUTH_TEST_CONFIG[connection.provider];
  if (!config) return { valid: false, error: "Provider test not supported", refreshed: false };
  if (!connection.accessToken) return { valid: false, error: "No access token", refreshed: false };

  // Cursor uses protobuf API - can only verify token exists, not test endpoint
  if (config.tokenExists) {
    return { valid: true, error: null, refreshed: false, newTokens: null };
  }

  let accessToken = connection.accessToken;
  let refreshed = false;
  let newTokens = null;

  const tokenExpired = isTokenExpired(connection);
  if (config.refreshable && tokenExpired && connection.refreshToken) {
    const tokens = await refreshOAuthToken(connection);
    if (tokens) {
      accessToken = tokens.accessToken;
      refreshed = true;
      newTokens = tokens;
    } else {
      return { valid: false, error: "Token expired and refresh failed", refreshed: false };
    }
  }

  if (config.checkExpiry) {
    if (refreshed) return { valid: true, error: null, refreshed, newTokens };
    if (tokenExpired) return { valid: false, error: "Token expired", refreshed: false };
    return { valid: true, error: null, refreshed: false, newTokens: null };
  }

  if (connection.provider === "gemini-cli" || connection.provider === "antigravity") {
    const initial = await probeCloudCodeAssistAccess(connection, accessToken, effectiveProxy);
    if (initial.valid) return { valid: true, error: null, refreshed, newTokens };

    if (initial.status === 401 && config.refreshable && !refreshed && connection.refreshToken) {
      const tokens = await refreshOAuthToken(connection);
      if (tokens?.accessToken) {
        const retry = await probeCloudCodeAssistAccess(connection, tokens.accessToken, effectiveProxy);
        if (retry.valid) return { valid: true, error: null, refreshed: true, newTokens: tokens };
        return { valid: false, error: retry.error, refreshed: true, newTokens: tokens };
      }
      return { valid: false, error: "Token invalid or revoked", refreshed: false };
    }

    return { valid: false, error: initial.error, refreshed };
  }

  if (connection.provider === "cline") {
    const tryProbe = async (token) => {
      const res = await probeClineAccessToken(token);
      if (res.ok) return { valid: true, error: null, refreshed, newTokens };
      if (res.status === 401) return { valid: false, error: "Token invalid or revoked", refreshed };
      if (res.status === 403) return { valid: false, error: "Access denied", refreshed };
      return { valid: false, error: `API returned ${res.status}`, refreshed };
    };

    const initial = await tryProbe(accessToken);
    if (initial.valid || initial.error !== "Token invalid or revoked" || !connection.refreshToken) {
      return initial;
    }

    const tokens = await refreshOAuthToken(connection);
    if (!tokens?.accessToken) {
      return { valid: false, error: "Token invalid or revoked", refreshed: false };
    }

    refreshed = true;
    newTokens = tokens;
    accessToken = tokens.accessToken;
    return await tryProbe(accessToken);
  }

  try {
    const testUrl = config.buildUrl ? config.buildUrl(accessToken) : config.url;
    const headers = config.noAuth
      ? { ...config.extraHeaders }
      : { [config.authHeader]: `${config.authPrefix}${accessToken}`, ...config.extraHeaders };
    const fetchOpts = { method: config.method, headers };
    if (config.body) fetchOpts.body = config.body;
    const res = await fetchWithConnectionProxy(testUrl, fetchOpts, effectiveProxy);
    const bodyText = !res.ok ? await res.text().catch(() => "") : "";

    const classified = classifyOAuthProbeResult(res, config, bodyText);
    if (classified.valid) {
      return {
        valid: true,
        // soft success surfaces warning text without marking connection error
        error: classified.soft ? classified.error : null,
        warning: classified.soft ? classified.error : null,
        refreshed,
        newTokens,
      };
    }

    if (res.status === 401 && config.refreshable && !refreshed && connection.refreshToken) {
      const tokens = await refreshOAuthToken(connection);
      if (tokens) {
        const retryUrl = config.buildUrl ? config.buildUrl(tokens.accessToken) : testUrl;
        const retryHeaders = config.noAuth
          ? { ...config.extraHeaders }
          : { [config.authHeader]: `${config.authPrefix}${tokens.accessToken}`, ...config.extraHeaders };
        const retryOpts = { method: config.method, headers: retryHeaders };
        if (config.body) retryOpts.body = config.body;
        const retryRes = await fetchWithConnectionProxy(retryUrl, retryOpts, effectiveProxy);
        const retryBody = !retryRes.ok ? await retryRes.text().catch(() => "") : "";
        const retryClassified = classifyOAuthProbeResult(retryRes, config, retryBody);
        if (retryClassified.valid) {
          return {
            valid: true,
            error: retryClassified.soft ? retryClassified.error : null,
            warning: retryClassified.soft ? retryClassified.error : null,
            refreshed: true,
            newTokens: tokens,
          };
        }
      }
      return { valid: false, error: "Token invalid or revoked", refreshed: false };
    }

    return { valid: false, error: classified.error, refreshed };
  } catch (err) {
    return { valid: false, error: err.message, refreshed };
  }
}

async function fetchWithConnectionProxy(url, options = {}, effectiveProxy = null) {
  // Add a 15-second timeout to prevent connection testing from hanging indefinitely
  // and exhausting the browser/Node.js connection pools.
  if (!options.signal) {
    options.signal = AbortSignal.timeout(15000);
  }

  // Vercel relay: forward via relay URL
  if (effectiveProxy?.vercelRelayUrl) {
    const { proxyAwareFetch } = await import("open-sse/utils/proxyFetch.js");
    return proxyAwareFetch(url, options, {
      vercelRelayUrl: effectiveProxy.vercelRelayUrl,
    });
  }

  if (!effectiveProxy?.connectionProxyEnabled || !effectiveProxy?.connectionProxyUrl) {
    return fetch(url, options);
  }

  const { proxyAwareFetch } = await import("open-sse/utils/proxyFetch.js");
  return proxyAwareFetch(url, options, {
    connectionProxyEnabled: true,
    connectionProxyUrl: effectiveProxy.connectionProxyUrl,
    connectionNoProxy: effectiveProxy.connectionNoProxy || "",
  });
}

async function testApiKeyConnection(connection, effectiveProxy = null, options = {}) {
  const { model } = options;
  if (isOpenAICompatibleProvider(connection.provider)) {
    const modelsBase = connection.providerSpecificData?.baseUrl;
    if (!modelsBase) return { valid: false, error: "Missing base URL" };
    try {
      const res = await fetchWithConnectionProxy(`${modelsBase.replace(/\/$/, "")}/models`, {
        headers: { "Authorization": `Bearer ${connection.apiKey}` },
      }, effectiveProxy);
      return { valid: res.ok, error: res.ok ? null : "Invalid API key or base URL" };
    } catch (err) {
      return { valid: false, error: err.message };
    }
  }

  if (isAnthropicCompatibleProvider(connection.provider)) {
    let modelsBase = connection.providerSpecificData?.baseUrl;
    if (!modelsBase) return { valid: false, error: "Missing base URL" };
    try {
      modelsBase = modelsBase.replace(/\/$/, "");
      if (modelsBase.endsWith("/messages")) modelsBase = modelsBase.slice(0, -9);
      const messagesUrl = `${modelsBase}/v1/messages`;
      // Selection (options.model) wins over the connection's configured default.
      // Do not name this `model` — the destructured option is in scope.
      const probeModel = model || connection.defaultModel || "claude-3-haiku-20240307";
      const res = await fetchWithConnectionProxy(messagesUrl, {
        method: "POST",
        headers: {
          "x-api-key": connection.apiKey,
          "anthropic-version": "2023-06-01",
          "content-type": "application/json",
          "Authorization": `Bearer ${connection.apiKey}`,
        },
        body: JSON.stringify({
          model: probeModel,
          max_tokens: 1,
          messages: [{ role: "user", content: "test" }],
        }),
      }, effectiveProxy);
      // 400/529 still confirms key accepted; only 401/403 = bad key
      const valid = res.status !== 401 && res.status !== 403;
      return { valid, error: valid ? null : "Invalid API key or base URL" };
    } catch (err) {
      return { valid: false, error: err.message };
    }
  }

  try {
    switch (connection.provider) {
      case "cloudflare-ai": {
        const psd = connection.providerSpecificData || {};
        const accountId = psd.accountId;
        if (!accountId) return { valid: false, error: "Missing Account ID" };
        const url = `https://api.cloudflare.com/client/v4/accounts/${accountId}/ai/v1/chat/completions`;
        const testModel = model || getDefaultModel("cloudflare-ai");
        const res = await fetchWithConnectionProxy(url, {
          method: "POST",
          headers: { "Authorization": `Bearer ${connection.apiKey}`, "Content-Type": "application/json" },
          body: JSON.stringify({ model: testModel, messages: [{ role: "user", content: "test" }], max_tokens: 1 }),
        }, effectiveProxy);
        const valid = res.status !== 401 && res.status !== 403 && res.status !== 404;
        return { valid, error: valid ? null : "Invalid API token or Account ID" };
      }
      case "azure": {
        const psd = connection.providerSpecificData || {};
        const endpoint = (psd.azureEndpoint || "").replace(/\/$/, "");
        const deployment = psd.deployment || "gpt-4";
        const apiVersion = psd.apiVersion || "2024-10-01-preview";
        const url = `${endpoint}/openai/deployments/${deployment}/chat/completions?api-version=${apiVersion}`;
        const headers = { "api-key": connection.apiKey, "Content-Type": "application/json" };
        if (psd.organization) headers["OpenAI-Organization"] = psd.organization;
        // For Azure, model selection is handled via deployment name; no need for test model param
        const res = await fetchWithConnectionProxy(url, {
          method: "POST", headers,
          body: JSON.stringify({ messages: [{ role: "user", content: "test" }], max_completion_tokens: 1 }),
        }, effectiveProxy);
        const valid = res.status !== 401 && res.status !== 403;
        return { valid, error: valid ? null : "Invalid API key or Azure configuration" };
      }
      case "openai": {
        const res = await fetchWithConnectionProxy("https://api.openai.com/v1/models", { headers: { Authorization: `Bearer ${connection.apiKey}` } }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "vercel-ai-gateway": {
        const res = await fetchWithConnectionProxy("https://ai-gateway.vercel.sh/v1/models", { headers: { Authorization: `Bearer ${connection.apiKey}` } }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "anthropic": {
        const testModel = model || "claude-3-haiku-20240307";
        const res = await fetchWithConnectionProxy("https://api.anthropic.com/v1/messages", {
          method: "POST",
          headers: { "x-api-key": connection.apiKey, "anthropic-version": "2023-06-01", "content-type": "application/json" },
          body: JSON.stringify({ model: testModel, max_tokens: 1, messages: [{ role: "user", content: "test" }] }),
        }, effectiveProxy);
        const valid = res.status !== 401;
        return { valid, error: valid ? null : "Invalid API key" };
      }
      case "gemini": {
        const res = await fetchWithConnectionProxy(`https://generativelanguage.googleapis.com/v1/models?key=${connection.apiKey}`, {}, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "openrouter": {
        const res = await fetchWithConnectionProxy("https://openrouter.ai/api/v1/auth/key", { headers: { Authorization: `Bearer ${connection.apiKey}` } }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "glm": {
        const testModel = model || "glm-4.7";
        const res = await fetchWithConnectionProxy("https://api.z.ai/api/anthropic/v1/messages", {
          method: "POST",
          headers: { "x-api-key": connection.apiKey, "anthropic-version": "2023-06-01", "content-type": "application/json" },
          body: JSON.stringify({ model: testModel, max_tokens: 1, messages: [{ role: "user", content: "test" }] }),
        }, effectiveProxy);
        const valid = res.status !== 401 && res.status !== 403;
        return { valid, error: valid ? null : "Invalid API key" };
      }
      case "glm-cn": {
        const testModel = model || "glm-4.7";
        const res = await fetchWithConnectionProxy("https://open.bigmodel.cn/api/coding/paas/v4/chat/completions", {
          method: "POST",
          headers: { "Authorization": `Bearer ${connection.apiKey}`, "content-type": "application/json" },
          body: JSON.stringify({ model: testModel, max_tokens: 1, messages: [{ role: "user", content: "test" }] }),
        }, effectiveProxy);
        const valid = res.status !== 401 && res.status !== 403;
        return { valid, error: valid ? null : "Invalid API key" };
      }
      case "minimax":
      case "minimax-cn": {
        const endpoints = { minimax: "https://api.minimax.io/anthropic/v1/messages", "minimax-cn": "https://api.minimaxi.com/anthropic/v1/messages" };
        const testModel = model || "minimax-m2";
        const res = await fetchWithConnectionProxy(endpoints[connection.provider], {
          method: "POST",
          headers: { "x-api-key": connection.apiKey, "anthropic-version": "2023-06-01", "content-type": "application/json" },
          body: JSON.stringify({ model: testModel, max_tokens: 1, messages: [{ role: "user", content: "test" }] }),
        }, effectiveProxy);
        const valid = res.status !== 401 && res.status !== 403;
        return { valid, error: valid ? null : "Invalid API key" };
      }
      case "kimi": {
        const testModel = model || "kimi-latest";
        const res = await fetchWithConnectionProxy("https://api.kimi.com/coding/v1/messages", {
          method: "POST",
          headers: { "x-api-key": connection.apiKey, "anthropic-version": "2023-06-01", "content-type": "application/json" },
          body: JSON.stringify({ model: testModel, max_tokens: 1, messages: [{ role: "user", content: "test" }] }),
        }, effectiveProxy);
        const valid = res.status !== 401 && res.status !== 403;
        return { valid, error: valid ? null : "Invalid API key" };
      }
      case "alicode":
      case "alicode-intl":
      case "alims-intl": {
        // Aliyun Coding Plan uses OpenAI-compatible API; alims-intl uses Model Studio compatible-mode
        const aliBaseUrl = connection.provider === "alicode-intl"
          ? "https://coding-intl.dashscope.aliyuncs.com/v1/chat/completions"
          : connection.provider === "alims-intl"
          ? "https://dashscope-intl.aliyuncs.com/compatible-mode/v1/chat/completions"
          : "https://coding.dashscope.aliyuncs.com/v1/chat/completions";
        const testModel = model || getDefaultModel(connection.provider);
        const res = await fetchWithConnectionProxy(aliBaseUrl, {
          method: "POST",
          headers: { "Authorization": `Bearer ${connection.apiKey}`, "content-type": "application/json" },
          body: JSON.stringify({ model: testModel, max_tokens: 1, messages: [{ role: "user", content: "test" }] }),
        }, effectiveProxy);
        const valid = res.status !== 401 && res.status !== 403;
        return { valid, error: valid ? null : "Invalid API key" };
      }
      case "volcengine-ark":
      case "byteplus": {
        const testModel = model || getDefaultModel(connection.provider);
        const res = await fetchWithConnectionProxy(PROVIDERS[connection.provider]?.baseUrl, {
          method: "POST",
          headers: { "Authorization": `Bearer ${connection.apiKey}`, "content-type": "application/json" },
          body: JSON.stringify({ model: testModel, max_tokens: 1, messages: [{ role: "user", content: "test" }] }),
        }, effectiveProxy);
        const valid = res.status !== 401 && res.status !== 403;
        return { valid, error: valid ? null : "Invalid API key" };
      }
      case "deepseek": {
        const res = await fetchWithConnectionProxy("https://api.deepseek.com/models", { headers: { Authorization: `Bearer ${connection.apiKey}` } }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "groq": {
        const res = await fetchWithConnectionProxy("https://api.groq.com/openai/v1/models", { headers: { Authorization: `Bearer ${connection.apiKey}` } }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "mistral": {
        const res = await fetchWithConnectionProxy("https://api.mistral.ai/v1/models", { headers: { Authorization: `Bearer ${connection.apiKey}` } }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "xai": {
        const res = await fetchWithConnectionProxy("https://api.x.ai/v1/models", { headers: { Authorization: `Bearer ${connection.apiKey}` } }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "nvidia": {
        const res = await fetchWithConnectionProxy("https://integrate.api.nvidia.com/v1/models", { headers: { Authorization: `Bearer ${connection.apiKey}` } }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "perplexity": {
        const res = await fetchWithConnectionProxy("https://api.perplexity.ai/v1/models", { headers: { Authorization: `Bearer ${connection.apiKey}` } }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "together": {
        const res = await fetchWithConnectionProxy("https://api.together.xyz/v1/models", { headers: { Authorization: `Bearer ${connection.apiKey}` } }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "fireworks": {
        const res = await fetchWithConnectionProxy("https://api.fireworks.ai/inference/v1/models", { headers: { Authorization: `Bearer ${connection.apiKey}` } }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "cerebras": {
        const res = await fetchWithConnectionProxy("https://api.cerebras.ai/v1/models", { headers: { Authorization: `Bearer ${connection.apiKey}` } }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "cohere": {
        const res = await fetchWithConnectionProxy("https://api.cohere.ai/v1/models", { headers: { Authorization: `Bearer ${connection.apiKey}` } }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "nebius": {
        const res = await fetchWithConnectionProxy("https://api.studio.nebius.ai/v1/models", { headers: { Authorization: `Bearer ${connection.apiKey}` } }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "siliconflow": {
        const res = await fetchWithConnectionProxy("https://api.siliconflow.com/v1/models", { headers: { Authorization: `Bearer ${connection.apiKey}` } }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "hyperbolic": {
        const res = await fetchWithConnectionProxy("https://api.hyperbolic.xyz/v1/models", { headers: { Authorization: `Bearer ${connection.apiKey}` } }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "ollama": {
        const res = await fetch("https://ollama.com/api/tags", { headers: { Authorization: `Bearer ${connection.apiKey}` } });
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "ollama-local": {
        const host = resolveOllamaLocalHost(connection);
        const res = await fetch(`${host}/api/tags`);
        return { valid: res.ok, error: res.ok ? null : `Ollama not reachable at ${host}` };
      }
      case "deepgram": {
        const res = await fetchWithConnectionProxy("https://api.deepgram.com/v1/projects", { headers: { Authorization: `Token ${connection.apiKey}` } }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "assemblyai": {
        const res = await fetchWithConnectionProxy("https://api.assemblyai.com/v1/account", { headers: { Authorization: `Bearer ${connection.apiKey}` } }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "nanobanana": {
        const res = await fetchWithConnectionProxy("https://api.nanobananaapi.ai/v1/models", { headers: { Authorization: `Bearer ${connection.apiKey}` } }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "fal-ai": {
        const res = await fetchWithConnectionProxy("https://api.fal.ai/v1/models?limit=1", { headers: { Authorization: `Key ${connection.apiKey}` } }, effectiveProxy);
        const valid = res.status !== 401 && res.status !== 403;
        return { valid, error: valid ? null : "Invalid API key" };
      }
      case "chutes": {
        const res = await fetchWithConnectionProxy("https://llm.chutes.ai/v1/models", { headers: { Authorization: `Bearer ${connection.apiKey}` } }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "grok-web": {
        const token = connection.apiKey.startsWith("sso=") ? connection.apiKey.slice(4) : connection.apiKey;
        const randomHex = (n) => Array.from(crypto.getRandomValues(new Uint8Array(n)), (b) => b.toString(16).padStart(2, "0")).join("");
        const statsigId = Buffer.from("e:TypeError: Cannot read properties of null (reading 'children')").toString("base64");
        const res = await fetchWithConnectionProxy("https://grok.com/rest/app-chat/conversations/new", {
          method: "POST",
          headers: {
            Accept: "*/*", "Content-Type": "application/json",
            Cookie: `sso=${token}`, Origin: "https://grok.com", Referer: "https://grok.com/",
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36",
            "x-statsig-id": statsigId, "x-xai-request-id": crypto.randomUUID(),
            traceparent: `00-${randomHex(16)}-${randomHex(8)}-00`,
          },
          body: JSON.stringify({ temporary: true, modelName: "grok-4", message: "ping", fileAttachments: [], imageAttachments: [], disableSearch: false, enableImageGeneration: false, sendFinalMetadata: true }),
        }, effectiveProxy);
        const valid = res.status !== 401 && res.status !== 403;
        return { valid, error: valid ? null : "Invalid SSO cookie" };
      }
      case "perplexity-web": {
        let sessionToken = connection.apiKey;
        if (sessionToken.startsWith("__Secure-next-auth.session-token=")) sessionToken = sessionToken.slice("__Secure-next-auth.session-token=".length);
        const res = await fetchWithConnectionProxy("https://www.perplexity.ai/api/auth/session", {
          method: "GET",
          headers: {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36",
            Cookie: `__Secure-next-auth.session-token=${sessionToken}`,
          },
        }, effectiveProxy);
        if (!res.ok) return { valid: false, error: "Invalid session cookie" };
        const data = await res.json().catch(() => null);
        const valid = !!(data && data.user);
        return { valid, error: valid ? null : "Session expired — re-paste cookie" };
      }
      case "opencode-go": {
        const res = await fetchWithConnectionProxy("https://opencode.ai/zen/go/v1/chat/completions", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${connection.apiKey}` },
          body: JSON.stringify({ model: getDefaultModel("opencode-go"), messages: [{ role: "user", content: "ping" }], max_tokens: 1, stream: false }),
        }, effectiveProxy);
        const valid = res.status !== 401 && res.status !== 403;
        return { valid, error: valid ? null : "Invalid API key" };
      }
      case "xiaomi-mimo":
      case "mimo-desktop":
      case "xiaomi-tokenplan": {
        // Xiaomi has TWO credential families and the test must exercise the one
        // this connection actually holds:
        //   • Desktop session (QR login, no sk-) → real request to a Preview
        //     model over the account-service route. That is the ONLY way to
        //     prove the session works end-to-end (a quota read can succeed
        //     while the chat route still rejects).
        //   • sk- key (manual / browser sign-in) → GET /models, as before.
        // A connection that has BOTH prefers the key (cheaper, and its failure
        // mode is clearer); the session path is the fallback.
        const authMethod = connection.providerSpecificData?.authMethod;
        const hasPlaceholderKey =
          typeof connection.apiKey === "string" && connection.apiKey.startsWith("mimo-desktop-session");
        const hasRealKey =
          typeof connection.apiKey === "string" && connection.apiKey.startsWith("sk-") && !hasPlaceholderKey;
        const isSessionConnection =
          (connection.provider === "xiaomi-mimo" || connection.provider === "mimo-desktop") &&
          !hasRealKey &&
          (authMethod === "desktop-session" || hasPlaceholderKey || Boolean(connection.providerSpecificData?.mimoPassToken));

        if (isSessionConnection) {
          try {
            const { getMimoAccountCookie } = await import("open-sse/shared/mimoAccount.js");
            const cookie = await getMimoAccountCookie(connection.providerSpecificData, effectiveProxy);
            if (!cookie) {
              return { valid: false, error: "Desktop session unavailable — sign in to MiMo Desktop once, then re-import" };
            }
            // Minimal real call against the Desktop card's live model. This must
            // name a model that exists: the retired mimo-x-*-preview pair would make
            // every session test fail with a 404-shaped upstream error that looks
            // like a bad cookie. The picker on the Desktop page offers exactly the
            // session models, so a selected id is always safe to probe; flash stays
            // the default because it is the cheapest.
            const probe = await fetchWithConnectionProxy(
              "https://mimo-server-cn.xiaomimimo.com/api/route/chat/completions",
              {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  Cookie: cookie,
                  Accept: "text/event-stream",
                },
                body: JSON.stringify({
                  model: model || "mimo-v2.6-flash",
                  stream: true,
                  max_tokens: 8,
                  messages: [
                    { role: "system", content: "You are CodeBuddy Code." },
                    // Plain string: the account-service route rejects OpenAI
                    // content-part arrays (same rule as translator/concerns/paramSupport.js).
                    { role: "user", content: "hi" },
                  ],
                }),
              },
              effectiveProxy,
            );
            if (probe.status === 401 || probe.status === 403) {
              let overseasHint = "";
              try {
                const { getEgressRegion } = await import("@/lib/network/egressRegion");
                const egress = await getEgressRegion({ timeoutMs: 1500 });
                if (egress?.countryCode && egress.countryCode !== "CN") {
                  overseasHint = " (detected non-mainland network; desktop preview models require China-side proxy)";
                }
              } catch {}
              return { valid: false, error: `Desktop session expired or unauthorized — sign in to MiMo Desktop again${overseasHint}` };
            }
            if (!probe.ok) {
              return { valid: false, error: `Preview probe failed (HTTP ${probe.status})` };
            }
            // Drain a little so the connection is not left half-open, then report.
            try {
              await probe.body?.cancel?.();
            } catch {
              /* best effort */
            }
            // Plain success: the session works. Do NOT report a `warning` —
            // that field lands in connection.lastError and renders as a red
            // error line in the dashboard, which reads as a problem when the
            // test actually passed.
            return { valid: true, error: null };
          } catch (e) {
            return { valid: false, error: e?.message || "Preview probe failed" };
          }
        }
        let testUrl = "https://api.xiaomimimo.com/v1/models";
        if (connection.provider === "xiaomi-tokenplan") {
          const { resolveXiaomiTokenplanBaseUrl } = await import("open-sse/config/providers.js");
          testUrl = `${resolveXiaomiTokenplanBaseUrl(connection)}/models`;
        } else {
          // xiaomi-mimo: a Token Plan subscriber's browser sign-in stores a
          // token-plan baseUrl — test the cluster the key actually belongs to.
          const { normalizeMimoApiBase } = await import("open-sse/config/providers.js");
          const stored = normalizeMimoApiBase(connection.providerSpecificData?.baseUrl);
          if (stored) testUrl = `${stored}/models`;
        }
        const res = await fetchWithConnectionProxy(testUrl, {
          headers: { Authorization: `Bearer ${connection.apiKey}` },
        }, effectiveProxy);
        // Xiaomi plan clusters: /models returns 403 for valid keys lacking list
        // permission; only 401 means invalid. (Billing keeps strict res.ok.)
        const isPlanCluster = connection.provider === "xiaomi-tokenplan" || testUrl.includes("token-plan");
        const valid = isPlanCluster ? res.status !== 401 : res.ok;
        return { valid, error: valid ? null : "Invalid API key" };
      }
      case "blackbox": {
        const baseUrl = PROVIDERS["blackbox"]?.baseUrl?.replace(/\/chat\/completions$/, "") || "https://api.blackbox.ai/v1";
        const res = await fetchWithConnectionProxy(`${baseUrl}/models`, {
          headers: { Authorization: `Bearer ${connection.apiKey}` },
        }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key" };
      }
      case "qoder": {
        // PAT (pt-...) exchange → job token. A successful exchange proves the PAT.
        const raw = connection.apiKey || "";
        const pat = raw.startsWith("pt-") ? raw : `pt-${raw}`;
        const exRes = await fetchWithConnectionProxy(
          "https://openapi.qoder.sh/api/v1/jobToken/exchange",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Accept: "application/json",
              "Cosy-Version": "1.0.1",
              "Cosy-ClientType": "5",
            },
            body: JSON.stringify({ personal_token: pat }),
          },
          effectiveProxy,
        );
        return { valid: exRes.ok, error: exRes.ok ? null : "Invalid Personal Access Token" };
      }
case "llm7": {
        const baseUrl = connection.providerSpecificData?.baseUrl || "https://api.llm7.io/v1";
        const res = await fetchWithConnectionProxy(`${baseUrl.replace(/\/$/, "")}/models`, {
          headers: { Authorization: `Bearer ${connection.apiKey}` },
        }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key or base URL" };
      }
      case "kimchi": {
        // Dual-auth: same validation endpoint as the OAuth flow — the token (API key
        // or OAuth access token) is sent as Authorization: Bearer.
        const url = KIMCHI_CONFIG.validationUrl || "https://api.cast.ai/v1/llm/openai/supported-providers";
        const res = await fetchWithConnectionProxy(url, {
          method: "GET",
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ${connection.apiKey}`,
            "User-Agent": "kimchi/0.1.40",
          },
        }, effectiveProxy);
        return { valid: res.ok, error: res.ok ? null : "Invalid API key", refreshed: false };
      }
      case "stepfun":
      case "stepfun-cn":
      case "stepfun-plan":
      case "stepfun-plan-cn":
      // StepFun's four channels (Domestic/International × Pay-as-you-go/Step Plan)
      // all expose a plain Bearer-auth GET /models — including the Step Plan
      // `/step_plan/v1/models` path (the `/accounts` quota route is the only one
      // that 404s there). Routed to the generic validator below.
      case "sensenova":
      case "longcat":
      case "bai":
      case "atria":
      case "tokenharbor":
      case "api-airforce":
      case "bazaarlink":
      case "baidu":
      case "featherless":
      case "bluesminds":
      case "alitp-intl":
      case "tokenbom": {
        // Generic OpenAI-compatible freeTier/apikey providers with a GET
        // /models endpoint and default Bearer auth — validate via that.
        const validateUrl =
          PROVIDERS[connection.provider]?.validateUrl ||
          (PROVIDERS[connection.provider]?.baseUrl?.replace(/\/chat\/completions$/, "") + "/models");
        if (!validateUrl || validateUrl === "/models") return { valid: false, error: "Provider test not supported" };
        let res;
        try {
          res = await fetchWithConnectionProxy(validateUrl, {
            headers: { Authorization: `Bearer ${connection.apiKey}` },
          }, effectiveProxy);
        } catch (err) {
          // Network-level failure (DNS, timeout, TLS, connection reset) — the
          // upstream endpoint may be down / still under maintenance.
          return {
            valid: false,
            error: "Endpoint unreachable — the provider may be under maintenance, try again later",
            maintenance: true,
          };
        }
        // Cloudflare challenge page (or any HTML, not JSON) means the gateway
        // is up but blocking direct API access — likely WAF / under maintenance.
        const contentType = res.headers.get("content-type") || "";
        const isCloudflare = /text\/html/i.test(contentType) || res.status === 403;
        const valid = res.status !== 401 && res.status !== 403;
        if (!valid && (isCloudflare || !/json/i.test(contentType))) {
          return {
            valid: false,
            error: "Provider may be under maintenance — blocked by its gateway (e.g. Cloudflare). Try again later or check the provider status page",
            maintenance: true,
          };
        }
        return { valid, error: valid ? null : "Invalid API key" };
      }
      case "codebuddy-cn": {
        // Tencent coding plan — OpenAI-compatible chat endpoint (Bearer).
        const baseUrl = PROVIDERS["codebuddy-cn"]?.baseUrl || "https://copilot.tencent.com/v2/chat/completions";
        const res = await fetchWithConnectionProxy(baseUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${connection.apiKey}` },
          body: JSON.stringify({ model: getDefaultModel("codebuddy-cn"), messages: [{ role: "user", content: "ping" }], max_tokens: 1, stream: false }),
        }, effectiveProxy);
        const valid = res.status !== 401 && res.status !== 403;
        return { valid, error: valid ? null : "Invalid API key" };
      }
      case "codebuddy-intl": {
        // International gateway (codebuddy.ai) — same OpenAI-compatible,
        // stream-only surface as CN. The IDE-channel headers are required (an
        // unapproved channel answers 11128) and `stream:false` can be rejected
        // outright (11101), so the verdict must stay auth-only (401/403) —
        // do NOT tighten it to `res.ok` or this case reports failure forever.
        const baseUrl = PROVIDERS["codebuddy-intl"]?.baseUrl || "https://www.codebuddy.ai/v2/chat/completions";
        const res = await fetchWithConnectionProxy(baseUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${connection.apiKey}`,
            ...(PROVIDERS["codebuddy-intl"]?.headers || {}),
          },
          body: JSON.stringify({ model: getDefaultModel("codebuddy-intl"), messages: [{ role: "user", content: "ping" }], max_tokens: 1, stream: false }),
        }, effectiveProxy);
        const valid = res.status !== 401 && res.status !== 403;
        return { valid, error: valid ? null : "Invalid API key" };
      }
      case "commandcode": {
        // CommandCode — NDJSON custom format, Bearer auth. Chat ping validates the key.
        const baseUrl = PROVIDERS["commandcode"]?.baseUrl || "https://api.commandcode.ai/alpha/generate";
        const res = await fetchWithConnectionProxy(baseUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${connection.apiKey}`, "x-command-code-version": "0.25.7", "x-cli-environment": "cli" },
          body: JSON.stringify({ model: getDefaultModel("commandcode"), messages: [{ role: "user", content: "ping" }], max_tokens: 1, stream: false }),
        }, effectiveProxy);
        const valid = res.status !== 401 && res.status !== 403;
        return { valid, error: valid ? null : "Invalid API key" };
      }
      case "dots": {
        // Dots uses a custom "api-key" header (raw, not Bearer) and has no GET
        // /models endpoint — connection validation falls back to a chat ping.
        const baseUrl = PROVIDERS["dots"]?.baseUrl || "https://note3-prev-api.askdiandian.com/v1/chat/completions";
        const res = await fetchWithConnectionProxy(baseUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json", "api-key": connection.apiKey },
          body: JSON.stringify({ model: getDefaultModel("dots"), messages: [{ role: "user", content: "ping" }], max_tokens: 1, stream: false }),
        }, effectiveProxy);
        const valid = res.status !== 401 && res.status !== 403;
        return { valid, error: valid ? null : "Invalid API key" };
      }
      default:
        return { valid: false, error: "Provider test not supported" };
    }
  } catch (err) {
    return { valid: false, error: err.message };
  }
}

/**
 * Null-out every `modelLock_*` field on a connection (successful-test cleanup).
 *
 * Export for tests: the keys are flat and model-named (`modelLock_<model>`, plus
 * the account-level `modelLock___all`), so they can only be found by prefix — a
 * fixed key list would silently miss the model that is actually locked.
 *
 * @param {object} connection - raw connection row
 * @returns {Record<string, null>} patch object, safe to spread into an update
 */
export function clearModelLockFields(connection) {
  if (!connection) return {};
  return Object.fromEntries(
    Object.keys(connection)
      .filter((key) => key.startsWith(MODEL_LOCK_PREFIX))
      .map((key) => [key, null])
  );
}

/**
 * Test a single connection by ID, update DB, and return result.
 * `options.model` (optional) overrides the model used for the probe request.
 */
export async function testSingleConnection(id, options = {}) {
  const connection = await getProviderConnectionById(id);
  if (!connection) return { valid: false, error: "Connection not found", latencyMs: 0, testedAt: new Date().toISOString() };
  if (connection.provider === "antigravity") await assertAntigravityAllowed(connection);

  const effectiveProxy = await resolveConnectionProxyConfig(connection.providerSpecificData || {});

  if (effectiveProxy.connectionProxyEnabled && effectiveProxy.connectionProxyUrl && !effectiveProxy.vercelRelayUrl) {
    const proxyResult = await testProxyUrl({ proxyUrl: effectiveProxy.connectionProxyUrl });
    if (!proxyResult.ok) {
      const proxyError = proxyResult.error || `Proxy test failed with status ${proxyResult.status}`;
      await updateProviderConnection(id, {
        testStatus: "error",
        lastError: proxyError,
        lastErrorAt: new Date().toISOString(),
      });
      return { valid: false, error: proxyError, latencyMs: 0, testedAt: new Date().toISOString() };
    }
  }

  const start = Date.now();
  let result;

  // NOTE: both spellings exist in the wild — legacy rows and some routes write
  // "api_key", the dashboard/test paths use "apikey". Treat them as one.
  const isKeyLike = connection.authType === "apikey" || connection.authType === "api_key" || connection.authType === "cookie";
  // Xiaomi MiMo dual-credential rows carry authType "oauth" when they arrive
  // via transfer import (accountTransfer defaults to it), but their probe —
  // sk- key → /models, session cookie → Preview model — lives in the apikey
  // path's provider switch. Route xiaomi-mimo there regardless of authType,
  // otherwise the Test button reports "Provider test not supported".
  if (isKeyLike || connection.provider === "xiaomi-mimo" || connection.provider === "mimo-desktop") {
    result = await testApiKeyConnection(connection, effectiveProxy, options);
  } else {
    result = await testOAuthConnection(connection, effectiveProxy, options);
  }

  const latencyMs = Date.now() - start;

  // Soft success (e.g. Grok CLI 402 spending-limit): credentials are good, account is
  // out of credits. Keep testStatus active; surface the message as lastError so the
  // dashboard can show a warning without marking the connection broken.
  const softWarning = result.valid && (result.warning || result.error);
  const updateData = {
    testStatus: result.valid ? "active" : "error",
    lastError: result.valid ? (softWarning || null) : result.error,
    lastErrorAt: result.valid
      ? softWarning
        ? new Date().toISOString()
        : null
      : new Date().toISOString(),
  };

  // A successful test is proof the credential works RIGHT NOW, so no runtime
  // health state may outlive it. Without this, re-logging into an account whose
  // token had gone stale still left the old locks in place: the dashboard showed
  // a green connection while every request kept being answered with the stale
  // lock ("no account available"), so the user's fix looked like it did nothing.
  //
  // Only on success — clearing health state after a FAILED test would erase the
  // evidence the dashboard is about to show.
  if (result.valid) {
    Object.assign(updateData, {
      backoffLevel: 0,
      rateLimitedUntil: null,
      errorCode: null,
      ...clearModelLockFields(connection),
    });
  }

  if (result.refreshed && result.newTokens) {
    if (result.newTokens.accessToken) updateData.accessToken = result.newTokens.accessToken;
    if (result.newTokens.refreshToken) updateData.refreshToken = result.newTokens.refreshToken;
    if (result.newTokens.idToken) updateData.idToken = result.newTokens.idToken;
    if (result.newTokens.lastRefreshAt) updateData.lastRefreshAt = result.newTokens.lastRefreshAt;
    if (result.newTokens.expiresIn) updateData.expiresIn = result.newTokens.expiresIn;
    if (result.newTokens.expiresIn) {
      updateData.expiresAt = new Date(Date.now() + result.newTokens.expiresIn * 1000).toISOString();
    } else if (result.newTokens.expiresAt) {
      updateData.expiresAt = result.newTokens.expiresAt;
    }
    if (result.newTokens.providerSpecificData) {
      updateData.providerSpecificData = {
        ...(connection.providerSpecificData || {}),
        ...result.newTokens.providerSpecificData,
      };
    }
  }

  await updateProviderConnection(id, updateData);

  // Background refresh of package expiry on successful connection test
  if (result.valid && USAGE_SUPPORTED_PROVIDERS.includes(connection.provider)) {
    (async () => {
      try {
        const mergedConn = { ...connection, ...updateData };
        // `proxyOptions` was an undefined identifier here — the ReferenceError
        // hit the empty catch below, so this background expiry refresh silently
        // never ran. The resolved proxy for this connection is `effectiveProxy`.
        const usage = await getUsageForProvider(mergedConn, effectiveProxy);
        const expiryInfo = extractEarliestPackageExpiry(usage);
        if (expiryInfo) {
          await updateProviderConnection(id, {
            earliestPackageExpiry: expiryInfo.expiry,
            earliestPackageName: expiryInfo.name,
            quotaCheckedAt: new Date().toISOString(),
          });
        }
      } catch {
        // Non-blocking, ignore background errors
      }
    })();
  }

  return { valid: result.valid, error: result.error, refreshed: !!result.refreshed, latencyMs, testedAt: new Date().toISOString() };
}
