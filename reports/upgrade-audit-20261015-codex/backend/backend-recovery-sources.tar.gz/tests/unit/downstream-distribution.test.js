import { beforeEach, describe, expect, it, vi } from "vitest";

// ───────────────────────────────────────────────────────────────────────────
// Downstream distribution allowlist.
//
// Two surfaces must agree: /v1/models stops advertising unpublished models, and
// the call path refuses them. If only the list were filtered, a client that
// remembered an id could still call it — the operator asked for the opposite.
// ───────────────────────────────────────────────────────────────────────────

const mocks = vi.hoisted(() => ({
  getProviderConnections: vi.fn(),
  getProviderNodes: vi.fn(),
  getCombos: vi.fn(),
  getCustomModels: vi.fn(),
  getModelAliases: vi.fn(),
  getDisabledModels: vi.fn(),
  getSettings: vi.fn(),
  getModelInfo: vi.fn(),
  // distribution state is swapped per-test
  distribution: { mode: "all", models: [] },
}));

vi.mock("@/lib/localDb", () => ({
  getProviderConnections: mocks.getProviderConnections,
  getProviderNodes: mocks.getProviderNodes,
  getCombos: mocks.getCombos,
  getCustomModels: mocks.getCustomModels,
  getModelAliases: mocks.getModelAliases,
  getSettings: mocks.getSettings,
}));

vi.mock("@/lib/disabledModelsDb", () => ({
  getDisabledModels: mocks.getDisabledModels,
}));

vi.mock("@/lib/distributionDb", () => ({
  getDistribution: vi.fn(async () => mocks.distribution),
  setDistribution: vi.fn(),
  isDistributed: (id, state) => {
    const s = state || mocks.distribution;
    if (!s || s.mode !== "allowlist") return true;
    return typeof id === "string" && s.models.includes(id.trim());
  },
  DISTRIBUTION_MODES: ["all", "allowlist"],
}));

vi.mock("../../src/sse/services/model.js", () => ({
  getModelInfo: mocks.getModelInfo,
  getComboModels: vi.fn(async () => null),
}));

const { buildModelsList, GET: getPublicModels } = await import("../../src/app/api/v1/models/route.js");
const { GET: getDistributionConfig } = await import("../../src/app/api/models/distribution/route.js");

const LLM_KIND = "llm";
const NODE_ID = "openai-compatible-chat-dist-0001";

describe("downstream distribution allowlist", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.getProviderNodes.mockResolvedValue([
      { id: NODE_ID, type: "openai-compatible", name: "DistNode" },
    ]);
    mocks.getCombos.mockResolvedValue([]);
    mocks.getModelAliases.mockResolvedValue({});
    mocks.getDisabledModels.mockResolvedValue({});
    mocks.getSettings.mockResolvedValue({ requireApiKey: false });
    mocks.getProviderConnections.mockResolvedValue([
      {
        id: "conn-dist",
        provider: NODE_ID,
        authType: "apikey",
        isActive: true,
        apiKey: "sk-test",
        providerSpecificData: { baseUrl: "https://api.distnode.com/v1", prefix: "fw", apiType: "chat" },
      },
    ]);
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ data: [
        { id: "deepseek-v4.1-flash" },
        { id: "glm-5.3-flash" },
        { id: "kimi-k3" },
      ] }), { status: 200 })
    );
    mocks.getCustomModels.mockResolvedValue([
      { providerAlias: NODE_ID, id: "deepseek-v4.1-flash", type: "llm", name: "deepseek-v4.1-flash", enabled: true },
      { providerAlias: NODE_ID, id: "glm-5.3-flash", type: "llm", name: "glm-5.3-flash", enabled: true },
      { providerAlias: NODE_ID, id: "kimi-k3", type: "llm", name: "kimi-k3", enabled: true },
    ]);
    mocks.distribution = { mode: "all", models: [] };
  });

  it("mode=all publishes everything (default, unchanged behaviour)", async () => {
    const ids = (await buildModelsList([LLM_KIND])).map((m) => m.id);
    expect(ids).toContain("fw/deepseek-v4.1-flash");
    expect(ids).toContain("fw/glm-5.3-flash");
    expect(ids).toContain("fw/kimi-k3");
  });

  it("mode=allowlist publishes ONLY the listed ids", async () => {
    mocks.distribution = { mode: "allowlist", models: ["fw/deepseek-v4.1-flash", "fw/kimi-k3"] };
    const ids = (await buildModelsList([LLM_KIND])).map((m) => m.id);
    expect(ids).toContain("fw/deepseek-v4.1-flash");
    expect(ids).toContain("fw/kimi-k3");
    expect(ids).not.toContain("fw/glm-5.3-flash");
  });

  it("mode=allowlist with an empty list publishes nothing", async () => {
    mocks.distribution = { mode: "allowlist", models: [] };
    const ids = (await buildModelsList([LLM_KIND])).map((m) => m.id);
    expect(ids).toEqual([]);
  });

  it("allowlist does not leak models through the upstream live feed", async () => {
    // The upstream /models feed still reports all three; the allowlist must
    // subtract glm-5.3-flash even though it arrives from the live catalog.
    mocks.distribution = { mode: "allowlist", models: ["fw/deepseek-v4.1-flash"] };
    const ids = (await buildModelsList([LLM_KIND])).map((m) => m.id);
    expect(ids).toEqual(["fw/deepseek-v4.1-flash"]);
  });

  it("management catalog retains unpublished live models while preserving the selected ids", async () => {
    mocks.distribution = { mode: "allowlist", models: ["fw/kimi-k3"] };
    const response = await getDistributionConfig();
    expect(response.status).toBe(200);
    const body = await response.json();
    expect(body.mode).toBe("allowlist");
    expect(body.models).toEqual(["fw/kimi-k3"]);
    expect(body.catalog.map((model) => model.id)).toEqual(expect.arrayContaining([
      "fw/deepseek-v4.1-flash", "fw/glm-5.3-flash", "fw/kimi-k3",
    ]));
    expect((await buildModelsList([LLM_KIND])).map((model) => model.id)).toEqual(["fw/kimi-k3"]);
  });

  it("public requests cannot bypass distribution through a query parameter", async () => {
    mocks.distribution = { mode: "allowlist", models: [] };
    const response = await getPublicModels(new Request("http://localhost/api/v1/models?ignoreDistribution=true"));
    expect(response.status).toBe(200);
    expect((await response.json()).data).toEqual([]);
  });
});
