import { describe, expect, it, vi } from "vitest";
import { createSSEStream } from "open-sse/utils/stream.js";
import { parseSSEEvents } from "open-sse/utils/sse.js";
import { FORMATS } from "open-sse/translator/formats.js";

vi.mock("@/lib/usageDb.js", () => ({
  appendRequestLog: vi.fn(async () => {}), trackPendingRequest: vi.fn(),
  saveRequestDetail: vi.fn(async () => {}), saveRequestUsage: vi.fn(async () => {})
}));

describe("SSE event framing across network chunks", () => {
  for (const newline of ["\n", "\r\n", "\r"]) {
    it.each([FORMATS.OPENAI, FORMATS.CLAUDE])(`preserves split UTF-8 and multiline data with ${JSON.stringify(newline)} for %s`, async sourceFormat => {
      const wire = [
        ": keep-alive", "", 'data: {"id":"chatcmpl-framing","choices":[',
        'data: {"index":0,"delta":{"content":"中文🙂"},"finish_reason":null}]}', "",
        'data: {"choices":[{"index":0,"delta":{},"finish_reason":"stop"}]}', "", "data: [DONE]"
      ].join(newline);
      const bytes = new TextEncoder().encode(wire);
      const upstream = new ReadableStream({
        start(controller) {
          for (let i = 0; i < bytes.length; i++) controller.enqueue(bytes.slice(i, i + 1));
          controller.close();
        }
      });
      const complete = vi.fn();
      const output = await new Response(upstream.pipeThrough(createSSEStream({
        mode: sourceFormat === FORMATS.OPENAI ? "passthrough" : "translate",
        sourceFormat, targetFormat: FORMATS.OPENAI, onStreamComplete: complete
      }))).text();
      const events = parseSSEEvents(output);
      expect(events.some(event => event.error || event.data?.error)).toBe(false);
      expect(output).toContain("中文🙂");
      expect(complete).toHaveBeenCalledTimes(1);
      expect(complete.mock.calls[0][0].status).not.toBe("failed");
      if (sourceFormat === FORMATS.OPENAI) {
        expect(events.filter(event => event.done)).toHaveLength(1);
        expect(output).toContain(": keep-alive");
      } else expect(events.filter(event => event.event === "message_stop")).toHaveLength(1);
    });
  }

  it("retains the final multiline event without a trailing separator", async () => {
    const wire = 'data: {"choices":[\ndata: {"index":0,"delta":{"content":"tail"},"finish_reason":"stop"}]}';
    const output = await new Response(new Response(wire).body.pipeThrough(createSSEStream({
      mode: "passthrough", sourceFormat: FORMATS.OPENAI, targetFormat: FORMATS.OPENAI
    }))).text();
    expect(parseSSEEvents(output)[0].data.choices[0].delta.content).toBe("tail");
    expect(output).not.toContain('"error"');
  });

  it("keeps Ollama NDJSON framing and its terminal usage", async () => {
    const wire = JSON.stringify({ model: "test", message: { role: "assistant", content: "ollama" }, done: false }) + "\n"
      + JSON.stringify({ model: "test", message: { content: "" }, done: true, done_reason: "stop", prompt_eval_count: 3, eval_count: 2 });
    const output = await new Response(new Response(wire).body.pipeThrough(createSSEStream({
      targetFormat: FORMATS.OLLAMA, sourceFormat: FORMATS.OPENAI
    }))).text();
    expect(output).toContain("ollama");
    expect(output).not.toContain('"error"');
    expect(parseSSEEvents(output).some(event => event.data?.choices?.[0]?.finish_reason === "stop")).toBe(true);
  });
});
