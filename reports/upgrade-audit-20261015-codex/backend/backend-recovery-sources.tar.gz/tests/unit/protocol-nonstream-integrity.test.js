import { describe, expect, it, vi } from "vitest";
import { convertResponsesStreamToJson } from "open-sse/transformer/streamToJsonConverter.js";
import { handleForcedSSEToJson, parseSSEToOpenAIResponse } from "open-sse/handlers/chatCore/sseToJsonHandler.js";
import { handleNonStreamingResponse, translateNonStreamingResponse } from "open-sse/handlers/chatCore/nonStreamingHandler.js";
import { FORMATS } from "open-sse/translator/formats.js";

vi.mock("@/lib/usageDb.js", () => ({
  appendRequestLog: vi.fn(async () => {}), trackPendingRequest: vi.fn(),
  saveRequestDetail: vi.fn(async () => {}), saveRequestUsage: vi.fn(async () => {})
}));

const frame = (type, payload) => `event: ${type}\ndata: ${JSON.stringify({ type, ...payload })}\n\n`;
const messageItem = { type: "message", role: "assistant", content: [{ type: "output_text", text: "hello" }] };
const claudeWire = () => frame("message_start", { message: {
  id: "msg_audit", type: "message", role: "assistant", model: "audit-model", content: [],
  usage: { input_tokens: 5, output_tokens: 0, cache_read_input_tokens: 9 }
} }) + frame("content_block_start", { index: 0, content_block: { type: "text", text: "" } })
  + frame("content_block_delta", { index: 0, delta: { type: "text_delta", text: "hello" } })
  + frame("content_block_stop", { index: 0 })
  + frame("content_block_start", { index: 1, content_block: { type: "tool_use", id: "toolu_audit", name: "echo", input: {} } })
  + frame("content_block_delta", { index: 1, delta: { type: "input_json_delta", partial_json: '{"value":1}' } })
  + frame("content_block_stop", { index: 1 })
  + frame("message_delta", { delta: { stop_reason: "tool_use", stop_sequence: null }, usage: { output_tokens: 2 } })
  + frame("message_stop", {});

function context(wire, sourceFormat, targetFormat, contentType = "text/event-stream") {
  return {
    providerResponse: new Response(wire, { headers: { "content-type": contentType } }),
    sourceFormat, targetFormat, provider: "audit-provider", model: "audit-model",
    body: { messages: [{ role: "user", content: "hi" }] }, stream: false,
    requestStartTime: Date.now(), trackDone: vi.fn(), appendLog: vi.fn(), onRequestSuccess: vi.fn(),
    reqLogger: { logProviderResponse: vi.fn(), logConvertedResponse: vi.fn() },
    translateToClientFormat: raw => translateNonStreamingResponse(raw, targetFormat, sourceFormat)
  };
}

describe("non-streaming protocol integrity", () => {
  it("aggregates native Claude text, tools and cache usage in forced streaming", async () => {
    const result = await handleForcedSSEToJson(context(claudeWire(), FORMATS.CLAUDE, FORMATS.CLAUDE));
    const json = await result.response.json();
    expect(json.type).toBe("message");
    expect(json.content).toEqual([
      { type: "text", text: "hello" },
      { type: "tool_use", id: "toolu_audit", name: "echo", input: { value: 1 } }
    ]);
    expect(json.usage).toMatchObject({ input_tokens: 5, output_tokens: 2, cache_read_input_tokens: 9 });
  });

  it("converts forced Claude SSE to OpenAI without losing content", async () => {
    const result = await handleForcedSSEToJson(context(claudeWire(), FORMATS.OPENAI, FORMATS.CLAUDE));
    const json = await result.response.json();
    expect(json.choices[0].message.content).toBe("hello");
    expect(json.choices[0].message.tool_calls[0].function.arguments).toBe('{"value":1}');
  });

  it("aggregates unexpected Claude SSE on the ordinary JSON path", async () => {
    const result = await handleNonStreamingResponse(context(claudeWire(), FORMATS.CLAUDE, FORMATS.CLAUDE));
    expect((await result.response.json()).content[0].text).toBe("hello");
  });

  it("rejects truncated Chat SSE instead of manufacturing a stop", () => {
    const wire = 'data: {"id":"chatcmpl-audit","choices":[{"index":0,"delta":{"content":"partial"}}]}\n\n';
    expect(parseSSEToOpenAIResponse(wire, "audit-model").error).toBeDefined();
  });

  it("preserves multiple choices in Chat SSE aggregation", () => {
    const wire = 'data: {"id":"chatcmpl-audit","choices":[{"index":0,"delta":{"content":"one"},"finish_reason":"stop"},{"index":1,"delta":{"content":"two"},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n';
    expect(parseSSEToOpenAIResponse(wire, "audit-model").choices.map(choice => choice.message.content)).toEqual(["one", "two"]);
  });

  it("does not mark an SSE error successful on the ordinary JSON path", async () => {
    const ctx = context('data: {"error":{"message":"AUDIT_UPSTREAM_FAILURE"}}\n\n', FORMATS.OPENAI, FORMATS.OPENAI);
    const result = await handleNonStreamingResponse(ctx);
    expect(result.response.status).toBe(502);
    expect(ctx.onRequestSuccess).not.toHaveBeenCalled();
    expect((await result.response.json()).error.message).toContain("AUDIT_UPSTREAM_FAILURE");
  });

  it("does not mark a failed Responses stream successful", async () => {
    const ctx = context(frame("response.failed", { response: {
      id: "resp_audit", status: "failed", error: { code: "server_error", message: "AUDIT_RESPONSE_FAILURE" }
    } }), FORMATS.OPENAI_RESPONSES, FORMATS.OPENAI_RESPONSES);
    const result = await handleForcedSSEToJson(ctx);
    expect(result.response.status).toBe(502);
    expect(ctx.onRequestSuccess).not.toHaveBeenCalled();
    expect((await result.response.json()).error).toMatchObject({ code: "server_error", message: "AUDIT_RESPONSE_FAILURE" });
  });

  it("preserves Responses CRLF framing and complete terminal envelopes", async () => {
    const wire = frame("response.created", { response: { id: "resp_audit", model: "audit-model" } })
      + frame("response.completed", { response: {
        id: "resp_audit", model: "audit-model", status: "completed", output: [messageItem],
        usage: { input_tokens: 5, output_tokens: 2, total_tokens: 7, input_tokens_details: { cached_tokens: 3 } }
      } });
    const json = await convertResponsesStreamToJson(new Response(wire.replaceAll("\n", "\r\n")).body);
    expect(json).toMatchObject({ id: "resp_audit", model: "audit-model", status: "completed", output: [messageItem] });
    expect(json.usage.input_tokens_details.cached_tokens).toBe(3);
  });

  it("preserves Responses incomplete reason and usage", async () => {
    const wire = frame("response.incomplete", { response: {
      id: "resp_audit", status: "incomplete", output: [messageItem],
      incomplete_details: { reason: "max_output_tokens" }, usage: { input_tokens: 5, output_tokens: 2, total_tokens: 7 }
    } });
    const json = await convertResponsesStreamToJson(new Response(wire).body);
    expect(json.status).toBe("incomplete");
    expect(json.incomplete_details.reason).toBe("max_output_tokens");
    expect(json.usage.output_tokens).toBe(2);
  });

  it("marks Responses streams without terminal events failed", async () => {
    const json = await convertResponsesStreamToJson(new Response(frame("response.created", { response: { id: "resp_audit" } })).body);
    expect(json.status).toBe("failed");
    expect(json.error.code).toBe("stream_disconnected");
  });

  it("preserves incomplete as length for a Chat client", async () => {
    const wire = frame("response.incomplete", { response: {
      id: "resp_audit", status: "incomplete", output: [messageItem], incomplete_details: { reason: "max_output_tokens" }
    } });
    const result = await handleForcedSSEToJson(context(wire, FORMATS.OPENAI, FORMATS.OPENAI_RESPONSES));
    expect((await result.response.json()).choices[0].finish_reason).toBe("length");
  });

  it("preserves mislabeled JSON fallback", async () => {
    const result = await handleNonStreamingResponse(context(JSON.stringify({
      id: "chatcmpl-audit", model: "audit-model", choices: [{ index: 0, message: { role: "assistant", content: "hello" }, finish_reason: "stop" }]
    }), FORMATS.OPENAI, FORMATS.OPENAI));
    expect(result.response.status).toBe(200);
    expect((await result.response.json()).choices[0].message.content).toBe("hello");
  });

  for (const contentType of ["application/json", "text/event-stream"]) {
    it(`unwraps a gateway Chat completion envelope with ${contentType}`, async () => {
      const completion = {
        id: "chatcmpl-wrapped", model: "audit-model", object: "chat.completion",
        choices: [{ index: 0, message: { role: "assistant", content: "hello" }, finish_reason: "stop" }],
        usage: { prompt_tokens: 5, completion_tokens: 2, total_tokens: 7 }
      };
      const ctx = context(JSON.stringify({ success: true, data: completion,
        usage: { prompt_tokens: 2000, completion_tokens: 0, total_tokens: 2000 }
      }), FORMATS.OPENAI, FORMATS.OPENAI, contentType);
      const result = await handleNonStreamingResponse(ctx);
      const json = await result.response.json();
      expect(result.response.status).toBe(200);
      expect(json.id).toBe(completion.id);
      expect(json.choices[0].message.content).toBe("hello");
      expect(json.usage.completion_tokens).toBe(2);
      const plain = await handleNonStreamingResponse(context(JSON.stringify(completion), FORMATS.OPENAI, FORMATS.OPENAI, "application/json"));
      expect(json.usage).toEqual((await plain.response.json()).usage);
      expect(json.data).toBeUndefined();
    });
  }

  for (const handler of [handleNonStreamingResponse, handleForcedSSEToJson]) {
    it(`aggregates wrapped Chat SSE via ${handler.name}`, async () => {
      const chunk = payload => `data: ${JSON.stringify({ success: true, data: payload })}\n\n`;
      const wire = chunk({ id: "chatcmpl-wrapped", choices: [{ index: 0, delta: {
        content: "hello", reasoning_content: "thinking",
        tool_calls: [{ index: 0, id: "call_1", function: { name: "echo", arguments: '{"value":' } }]
      } }] }) + chunk({ choices: [{ index: 0, delta: {
        tool_calls: [{ index: 0, function: { arguments: "1}" } }]
      }, finish_reason: "tool_calls" }] })
        + chunk({ usage: { prompt_tokens: 5, completion_tokens: 2, total_tokens: 7 } }) + "data: [DONE]\n\n";
      const result = await handler(context(wire, FORMATS.OPENAI, FORMATS.OPENAI));
      const json = await result.response.json();
      expect(result.response.status).toBe(200);
      expect(json.id).toBe("chatcmpl-wrapped");
      expect(json.choices[0].message.content).toBe("hello");
      expect(json.choices[0].message.tool_calls[0].function.arguments).toBe('{"value":1}');
      expect(json.choices[0].finish_reason).toBe("tool_calls");
      expect(json.usage.completion_tokens).toBe(2);
    });
  }

  it("retains a complete message sent inside a wrapped SSE event", () => {
    const wire = 'data: {"success":true,"data":{"choices":[{"index":0,"message":{"role":"assistant","content":"hello"},"finish_reason":"stop"}]}}\n\ndata: [DONE]\n\n';
    expect(parseSSEToOpenAIResponse(wire, "audit-model").choices[0].message.content).toBe("hello");
  });

  it("keeps separate tool calls in a wrapped complete message", () => {
    const tools = ["first", "second"].map(name => ({ id: `call_${name}`, type: "function", function: { name, arguments: "{}" } }));
    const wire = `data: ${JSON.stringify({ data: { choices: [{ index: 0,
      message: { role: "assistant", content: null, tool_calls: tools }, finish_reason: "tool_calls"
    }] } })}\n\ndata: [DONE]\n\n`;
    expect(parseSSEToOpenAIResponse(wire, "audit-model").choices[0].message.tool_calls).toEqual(tools);
  });

  it("rejects a truncated wrapped stream and an empty wrapped stream", () => {
    const partial = 'data: {"data":{"choices":[{"index":0,"delta":{"content":"partial"}}]}}\n\n';
    expect(parseSSEToOpenAIResponse(partial, "audit-model").error.code).toBe("stream_disconnected");
    expect(parseSSEToOpenAIResponse('data: {"success":true,"data":{}}\n\ndata: [DONE]\n\n', "audit-model")).toBeNull();
  });

  for (const contentType of ["application/json", "text/event-stream"]) {
    it(`preserves wrapped upstream errors with ${contentType}`, async () => {
      const payload = { success: false, data: { error: { message: "WRAPPED_UPSTREAM_FAILURE" } } };
      const wire = contentType === "application/json" ? JSON.stringify(payload) : `data: ${JSON.stringify(payload)}\n\n`;
      const ctx = context(wire, FORMATS.OPENAI, FORMATS.OPENAI, contentType);
      const result = await handleNonStreamingResponse(ctx);
      expect(result.response.status).toBe(502);
      expect((await result.response.json()).error.message).toContain("WRAPPED_UPSTREAM_FAILURE");
      expect(ctx.onRequestSuccess).not.toHaveBeenCalled();
    });
  }

  it("does not hide an outer failure behind a nested completion", async () => {
    const ctx = context(JSON.stringify({ success: false, error: { message: "OUTER_FAILURE" }, data: {
      choices: [{ index: 0, message: { content: "must not succeed" }, finish_reason: "stop" }]
    } }), FORMATS.OPENAI, FORMATS.OPENAI, "application/json");
    const result = await handleNonStreamingResponse(ctx);
    expect(result.response.status).toBe(502);
    expect((await result.response.json()).error.message).toContain("OUTER_FAILURE");
    expect(ctx.onRequestSuccess).not.toHaveBeenCalled();
  });

  it("does not double-count cached tokens in Responses to Chat JSON", () => {
    const json = translateNonStreamingResponse({
      id: "resp_audit", object: "response", status: "completed", output: [messageItem],
      usage: { input_tokens: 5, output_tokens: 2, total_tokens: 7, input_tokens_details: { cached_tokens: 3 } }
    }, FORMATS.OPENAI_RESPONSES, FORMATS.OPENAI);
    expect(json.usage.prompt_tokens).toBe(5);
    expect(json.usage.prompt_tokens_details.cached_tokens).toBe(3);
  });

  it("preserves cache counters when Chat JSON becomes Claude", () => {
    const json = translateNonStreamingResponse({
      id: "chatcmpl-audit", choices: [{ message: { content: "hello" }, finish_reason: "stop" }],
      usage: { prompt_tokens: 14, completion_tokens: 2, prompt_tokens_details: { cached_tokens: 9 } }
    }, FORMATS.OPENAI, FORMATS.CLAUDE);
    expect(json.usage).toMatchObject({ input_tokens: 5, output_tokens: 2, cache_read_input_tokens: 9 });
  });

  it("converts ordinary Responses SSE to Claude JSON", async () => {
    const wire = frame("response.completed", { response: {
      id: "resp_audit", status: "completed", output: [messageItem], usage: { input_tokens: 5, output_tokens: 2, total_tokens: 7 }
    } });
    const result = await handleNonStreamingResponse(context(wire, FORMATS.CLAUDE, FORMATS.OPENAI_RESPONSES));
    expect(await result.response.json()).toMatchObject({ type: "message", content: [{ type: "text", text: "hello" }] });
  });
});
