import { describe, expect, it } from "vitest";
import { mergeUsage } from "../../open-sse/utils/usageTracking.js";

describe("upstream usage takes precedence over estimates", () => {
  it("replaces an estimate when actual tail usage arrives, even when actual counts are lower", () => {
    const usage = mergeUsage({ prompt_tokens: 2000, completion_tokens: 30, estimated: true }, { prompt_tokens: 11, completion_tokens: 2, cached_tokens: 8 });
    expect(usage).toEqual({ prompt_tokens: 11, completion_tokens: 2, cached_tokens: 8 });
  });

  it("does not overwrite measured usage with an estimated finish chunk", () => {
    const usage = mergeUsage({ prompt_tokens: 11, completion_tokens: 2, cached_tokens: 8 }, { prompt_tokens: 2000, completion_tokens: 30, estimated: true });
    expect(usage).toEqual({ prompt_tokens: 11, completion_tokens: 2, cached_tokens: 8 });
  });

  it("still merges increasing actual usage and keeps earlier cache counts", () => {
    const usage = mergeUsage({ prompt_tokens: 11, completion_tokens: 2, cached_tokens: 8 }, { prompt_tokens: 11, completion_tokens: 5 });
    expect(usage).toEqual({ prompt_tokens: 11, completion_tokens: 5, cached_tokens: 8 });
  });
});
