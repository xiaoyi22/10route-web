import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

let testApi;
try { testApi = await import("vitest"); }
catch (error) {
  if (error.code !== "ERR_MODULE_NOT_FOUND") throw error;
  testApi = await import("node:test");
}
const { describe, it, beforeEach, afterEach } = testApi;

// Set isolation and the network tripwire BEFORE importing the real entry/DB.
const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "10router-ag-chat-stop-"));
process.env.DATA_DIR = tempDir;
const unexpectedFetches = [];
let mockFetch = async url => { unexpectedFetches.push(String(url)); throw new Error(`Unexpected offline fetch: ${url}`); };
globalThis.fetch = (...args) => mockFetch(...args);
const repo = await import("../../src/lib/db/repos/connectionsRepo.js");
const { createCombo, getCombos, deleteCombo } = await import("../../src/lib/db/repos/combosRepo.js");
const { updateSettings } = await import("../../src/lib/db/repos/settingsRepo.js");
const { resetQuarantineMemory, AG_TOS_DISABLED_SENTENCE } = await import("../../open-sse/services/antigravityQuarantine.js");
const { getExecutor } = await import("../../open-sse/executors/index.js");
const { handleChat } = await import("../../src/sse/handlers/chat.js");
const { handleFusionChat } = await import("../../open-sse/services/combo.js");
const executor = getExecutor("antigravity");
const originalParseError = executor.parseError;
const models = ["ag/gemini-3.8-flash-high", "ag/gemini-3.8-flash-low"];
const log = { info() {}, warn() {}, error() {}, debug() {} };
const tick = () => new Promise(resolve => setImmediate(resolve));
function deferred() {
  let resolve;
  const promise = new Promise(r => { resolve = r; });
  return { promise, resolve };
}
function request(model) {
  return new Request("http://offline.invalid/v1/chat/completions", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model, stream: false, messages: [{ role: "user", content: "Explain a sorting algorithm." }] }),
  });
}
const tos = () => Response.json({ error: { message: AG_TOS_DISABLED_SENTENCE } }, { status: 403 });
const success = () => Response.json({ choices: [{ message: { role: "assistant", content: "offline answer" } }] });
async function account(name, priority) {
  return repo.createProviderConnection({ provider: "antigravity", authType: "oauth", name, priority,
    email: `${name}@example.invalid`, accessToken: `token-${name}`, refreshToken: `refresh-${name}`,
    projectId: `project-${name}`, expiresAt: new Date(Date.now() + 3600000).toISOString(), isActive: true });
}
async function fusion(models, tuning = {}) {
  const name = `offline-fusion-${crypto.randomUUID()}`;
  await createCombo({ name, models });
  await updateSettings({ comboStrategies: { [name]: { fallbackStrategy: "fusion", fusionTuning: tuning } } });
  return name;
}

describe("AG request stop state through real handleChat (offline)", () => {
  beforeEach(async () => {
    resetQuarantineMemory();
    repo.registerQuarantinePersistenceHandler();
    unexpectedFetches.length = 0;
    mockFetch = async url => { unexpectedFetches.push(String(url)); throw new Error(`Unexpected offline fetch: ${url}`); };
    for (const c of await repo.getProviderConnections()) await repo.deleteProviderConnection(c.id);
    for (const c of await getCombos()) await deleteCombo(c.id);
    await updateSettings({ requireApiKey: false, rtkEnabled: false, headroomEnabled: false,
      pxpipeEnabled: false, outboundProxyEnabled: false, comboStrategies: {},
      providerStrategies: { antigravity: { fallbackStrategy: "round-robin", stickyRoundRobinLimit: 1, earliestExpiryFirst: false } } });
  });
  afterEach(() => {
    executor.parseError = originalParseError;
    resetQuarantineMemory();
    assert.deepEqual(unexpectedFetches, [], "All fetches must be handled by offline stubs");
  });

  for (const status of [429, 401, 403]) {
    it(`fusion TOS stops another panel's ${status === 429 ? "executor retry" : status === 401 ? "OAuth refresh" : "account fallback"}`, async () => {
      await account("banned", 1);
      const healthy = await account("healthy", 2);
      await account("spare", 3);
      const combo = await fusion(models);
      const siblingStarted = deferred();
      const tosParsed = deferred();
      const attempts = [];
      let stopped = false;
      executor.parseError = function(response, text) {
        const result = originalParseError.call(this, response, text);
        if (text.includes(AG_TOS_DISABLED_SENTENCE)) tosParsed.resolve();
        return result;
      };
      mockFetch = async (url, options) => {
        const payload = JSON.parse(options.body);
        attempts.push({ url: String(url), token: options.headers.Authorization, model: payload.model, stopped });
        if (stopped) return new Response("unexpected send after TOS", { status: 403 });
        if (payload.model === models[0].slice(3)) {
          await siblingStarted.promise;
          return tos();
        }
        assert.equal(payload.model, models[1].slice(3));
        siblingStarted.resolve();
        await tosParsed.promise;
        // Drain the real TOS result back through handleSingleModelChat/fusion.
        await tick();
        stopped = true;
        return Response.json({ error: { message: "offline sibling failure" } }, {
          status, headers: { "retry-after": "0.001" },
        });
      };
      const response = await handleChat(request(combo));
      assert.equal(response.status, 403);
      assert.equal(response.isTosQuarantined, true);
      // Panels fan out concurrently, so arrival ORDER is not contractual —
      // pin what actually matters: each panel used its own account exactly once
      // and nobody kept fetching after the sibling TOS was observed.
      const tokens = attempts.map(a => a.token).sort();
      assert.deepEqual(tokens, ["Bearer token-banned", "Bearer token-healthy"].sort(),
        "Both panels made exactly one initial call, no duplicate account usage");
      assert.deepEqual(attempts.filter(a => a.stopped), [], "No new AG fetch (retry/refresh/fallback) after sibling TOS");
      const saved = await repo.getProviderConnectionById(healthy.id);
      assert.equal(saved.isActive, true);
      assert.equal(saved.quarantine, undefined, "Request-local stop must not quarantine a healthy sibling");
    });
  }

  it("a stopped request never selects an AG account or refreshes it", async () => {
    const conn = await account("expired", 1);
    await repo.updateProviderConnection(conn.id, { expiresAt: new Date(0).toISOString() });
    const stopped = tos();
    stopped.isTosQuarantined = true;
    const response = await handleChat(request(models[0]), null, { tosResponse: stopped });
    assert.equal(response, stopped);
    assert.equal((await repo.getProviderConnectionById(conn.id)).lastUsedAt, undefined);
  });

  for (const successfulPanels of [1, 2]) {
    it(`fusion passes the identical stop state to ${successfulPanels === 1 ? "replay" : "judge"}`, async () => {
      const states = [];
      const response = await handleFusionChat({ body: { stream: false, messages: [] }, models, log,
        handleSingleModel: async (_body, model, isPanel, state) => {
          states.push({ isPanel, state });
          if (isPanel && successfulPanels === 1 && model === models[1]) return new Response("failed", { status: 400 });
          return success();
        } });
      assert.equal(response.status, 200);
      assert.equal(states.length, 3);
      assert.ok(states[0].state);
      assert.equal(states[1].state, states[0].state);
      assert.ok(!states[2].isPanel);
      assert.equal(states[2].state, states[0].state);
    });
  }
});
