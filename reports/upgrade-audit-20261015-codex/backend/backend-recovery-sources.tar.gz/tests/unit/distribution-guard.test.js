import { beforeEach, describe, expect, it, vi } from "vitest";

// ───────────────────────────────────────────────────────────────────────────
// enforceDistribution — the call-path half of the allowlist.
//
// Hiding a model from /v1/models is not enough: a client that remembers the id
// must be refused too, or "不在名单里不能调用" is only cosmetic. This guard is
// called by every non-chat modality handler; chat-shaped protocols enforce the
// same rule inside handleChat.
// ───────────────────────────────────────────────────────────────────────────

const mocks = vi.hoisted(() => ({
  getModelInfo: vi.fn(),
  distribution: { mode: "all", models: [] },
}));

vi.mock("@/lib/distributionDb", () => ({
  getDistribution: vi.fn(async () => mocks.distribution),
  isDistributed: (id, state) => {
    const s = state || mocks.distribution;
    if (!s || s.mode !== "allowlist") return true;
    return typeof id === "string" && s.models.includes(id.trim());
  },
}));

vi.mock("../../src/sse/services/model.js", () => ({
  getModelInfo: mocks.getModelInfo,
  getComboModels: vi.fn(async () => null),
}));

const { enforceDistribution } = await import("../../src/sse/services/distributionGuard.js");

describe("enforceDistribution", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.distribution = { mode: "all", models: [] };
    mocks.getModelInfo.mockResolvedValue({ provider: "fw", model: "glm-5.3-flash" });
  });

  it("mode=all allows everything", async () => {
    expect(await enforceDistribution("fw/glm-5.3-flash")).toBeNull();
  });

  it("allowlist permits a published full route id", async () => {
    mocks.distribution = { mode: "allowlist", models: ["fw/glm-5.3-flash"] };
    expect(await enforceDistribution("fw/glm-5.3-flash")).toBeNull();
  });

  it("allowlist refuses an unpublished model with 404", async () => {
    mocks.distribution = { mode: "allowlist", models: ["fw/deepseek-v4.1-flash"] };
    const response = await enforceDistribution("fw/glm-5.3-flash");
    expect(response).not.toBeNull();
    expect(response.status).toBe(404);
    const body = await response.json();
    expect(body.error.message).toContain("glm-5.3-flash");
  });

  it("allowlist accepts the bare upstream id when the full route id is published", async () => {
    // A client may send "glm-5.3-flash"; the catalog published "fw/glm-5.3-flash".
    mocks.distribution = { mode: "allowlist", models: ["fw/glm-5.3-flash"] };
    expect(await enforceDistribution("glm-5.3-flash")).toBeNull();
  });

  it("an empty model string is not blocked (handled by each caller's own validation)", async () => {
    mocks.distribution = { mode: "allowlist", models: [] };
    expect(await enforceDistribution("")).toBeNull();
  });
});
