import { describe, expect, it } from "vitest";

import { createSSEStream } from "../../open-sse/utils/stream.js";
import { createStreamController, pipeWithDisconnect } from "../../open-sse/utils/streamHandler.js";
import { FORMATS } from "../../open-sse/translator/formats.js";

const sleep = (ms) => new Promise((s) => setTimeout(s, ms));

const BODY = { messages: [{ role: "user", content: "hi" }] };

// Upstream that yields `frames` then closes.
function sseResponse(frames) {
  return new Response(
    new ReadableStream({
      async start(c) {
        for (const f of frames) {
          c.enqueue(new TextEncoder().encode(f));
          await sleep(5);
        }
        c.close();
      },
    }),
    { headers: { "content-type": "text/event-stream" } }
  );
}

// Upstream that respects backpressure and errors once its signal aborts —
// this is what the real fetch body does when a disconnected client causes
// streamController to abort the request.
function abortableResponse(signal, chunkDelayMs = 200) {
  return new Response(
    new ReadableStream({
      async pull(c) {
        await sleep(chunkDelayMs);
        if (signal.aborted) {
          c.error(new Error("aborted"));
          return;
        }
        c.enqueue(new TextEncoder().encode('data: {"choices":[{"delta":{"content":"X"}}]}\n\n'));
      },
      cancel() { /* fetch body teardown */ },
    }),
    { headers: { "content-type": "text/event-stream" } }
  );
}

function makeStream(onStreamComplete) {
  return createSSEStream({
    targetFormat: FORMATS.OPENAI,
    sourceFormat: FORMATS.OPENAI,
    provider: "test",
    model: "kimi-k3",
    body: BODY,
    onStreamComplete,
  });
}

async function drain(stream) {
  const reader = stream.getReader();
  while (!(await reader.read()).done) { /* drain */ }
  return reader;
}

describe("stream usage on client abort", () => {
  it.each([['completed', undefined], ['failed', 'failed']])("preserves response.%s when the client closes before transport EOF", async (status, expectedStatus) => {
    let resolveComplete;
    const completed = new Promise(resolve => { resolveComplete = resolve; });
    const controller = createStreamController({ provider: "test", model: "test-model" });
    const upstream = new Response(new ReadableStream({
      start(stream) {
        const event = { type: `response.${status}`, response: { id: "resp_test", status, output: [], usage: { input_tokens: 11, output_tokens: 2 }, ...(status === "failed" && { error: { code: "upstream_error", message: "Test upstream failure" } }) } };
        stream.enqueue(new TextEncoder().encode(`event: response.${status}\ndata: ${JSON.stringify(event)}\n\n`));
      },
    }), { headers: { "content-type": "text/event-stream" } });
    const transform = createSSEStream({
      targetFormat: FORMATS.OPENAI_RESPONSES, sourceFormat: FORMATS.OPENAI_RESPONSES,
      provider: "test", model: "test-model", body: BODY,
      onStreamComplete: (content, usage) => resolveComplete({ content, usage }),
    });
    const reader = pipeWithDisconnect(upstream, transform, controller, null).getReader();
    let text = "";
    while (!text.includes(`"type":"response.${status}"`)) {
      const next = await reader.read();
      if (next.done) throw new Error("Missing completed event");
      text += new TextDecoder().decode(next.value);
    }
    await reader.cancel("ResponseAborted");
    const result = await completed;
    expect(result.content.status).toBe(expectedStatus);
    if (status === "completed") expect(result.usage.completion_tokens).toBe(2);
    else expect(result.content.error.message).toBe("Test upstream failure");
  });

  it("reports upstream usage when the stream completes normally", async () => {
    let seen = null;
    const controller = createStreamController({ provider: "test", model: "kimi-k3" });
    const out = pipeWithDisconnect(
      sseResponse([
        'data: {"choices":[{"delta":{"content":"hello"}}]}\n\n',
        'data: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":11,"completion_tokens":2}}\n\n',
        "data: [DONE]\n\n",
      ]),
      makeStream((content, usage) => { seen = usage; }),
      controller,
      null
    );

    await drain(out);
    await sleep(50);

    expect(seen).not.toBeNull();
    expect(seen.prompt_tokens).toBe(11);
    expect(seen.completion_tokens).toBe(2);
    // Real upstream numbers must survive, not a char-based estimate.
    expect(seen.estimated).toBeUndefined();
  });

  it("reports estimated usage when the client aborts mid-stream", async () => {
    let seen = null;
    let finalStatus;
    let calls = 0;
    const controller = createStreamController({ provider: "test", model: "kimi-k3" });
    const out = pipeWithDisconnect(
      abortableResponse(controller.signal),
      makeStream((content, usage) => { calls++; seen = usage; finalStatus = content.status; }),
      controller,
      null
    );

    const reader = out.getReader();
    await reader.read();
    await reader.cancel("ResponseAborted");
    await sleep(500);

    expect(calls).toBe(1);
    expect(seen).not.toBeNull();
    // The provider socket is aborted, so no usage frame ever arrives — the
    // fallback must still be a non-zero, explicitly-estimated row rather than
    // the 0/0 that made every aborted request look free.
    expect(seen.prompt_tokens).toBeGreaterThan(0);
    expect(seen.estimated).toBe(true);
    expect(finalStatus).toBe("failed");
  });

  it("never reports twice when flush and cancel both run", async () => {
    let calls = 0;
    const controller = createStreamController({ provider: "test", model: "kimi-k3" });
    const out = pipeWithDisconnect(
      sseResponse([
        'data: {"choices":[{"delta":{},"finish_reason":"stop"}],"usage":{"prompt_tokens":11,"completion_tokens":2}}\n\n',
        "data: [DONE]\n\n",
      ]),
      makeStream(() => { calls++; }),
      controller,
      null
    );

    const reader = await drain(out);
    await reader.cancel("late").catch(() => {});
    await sleep(100);

    expect(calls).toBe(1);
  });
});
