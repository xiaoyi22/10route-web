import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({ verifyPassword: vi.fn(), setCookie: vi.fn() }));
vi.mock("@/lib/auth/dashboardSession", () => ({
  verifyDashboardPassword: mocks.verifyPassword,
  setDashboardAuthCookie: mocks.setCookie,
}));
vi.mock("@/lib/auth/passwordReset", () => ({ applyPasswordResetFile: async () => {} }));
vi.mock("next/headers", () => ({ cookies: async () => ({}) }));

import { POST as verify } from "../../src/app/api/auth/verify-password/route.js";
import { POST as login } from "../../src/app/api/auth/login/route.js";
import { recordSuccess } from "@/lib/auth/loginLimiter";

const request = (password = "wrong") => new Request("http://localhost/api/auth/verify-password", {
  method: "POST", headers: { "content-type": "application/json", "x-forwarded-for": "spoofed-ip" },
  body: JSON.stringify({ password }),
});

beforeEach(() => {
  vi.useFakeTimers();
  vi.stubEnv("TRUST_PROXY", "false");
  vi.stubEnv("TENROUTER_PEER_TOKEN", "");
  recordSuccess("unknown");
  mocks.verifyPassword.mockReset().mockResolvedValue(false);
});

afterEach(() => {
  recordSuccess("unknown");
  vi.unstubAllEnvs();
  vi.useRealTimers();
});

describe("password verification shares login lockout", () => {
  it("locks after five wrong passwords and skips verification while locked", async () => {
    for (let i = 0; i < 5; i++) expect((await verify(request())).status).toBe(401);
    const blocked = await verify(request());
    expect(blocked.status).toBe(429);
    expect(blocked.headers.get("Retry-After")).toBe("30");
    expect(mocks.verifyPassword).toHaveBeenCalledTimes(5);
    vi.advanceTimersByTime(30_000);
    expect((await verify(request())).status).toBe(401);
  });

  it.each([[login, verify], [verify, login]])("shares failures across both endpoints", async (first, second) => {
    for (let i = 0; i < 5; i++) await first(request());
    expect((await second(request())).status).toBe(429);
    expect(mocks.verifyPassword).toHaveBeenCalledTimes(5);
  });

  it("clears earlier failures after successful verification", async () => {
    for (let i = 0; i < 4; i++) await verify(request());
    mocks.verifyPassword.mockResolvedValueOnce(true);
    expect((await verify(request("correct"))).status).toBe(200);
    for (let i = 0; i < 5; i++) expect((await verify(request())).status).toBe(401);
    expect((await verify(request())).status).toBe(429);
  });

  it("counts invalid JSON without disclosing internal errors", async () => {
    for (let i = 0; i < 5; i++) {
      const response = await verify(new Request("http://localhost/api/auth/verify-password", {
        method: "POST", body: "{invalid",
      }));
      expect(response.status).toBe(400);
      expect(await response.json()).toEqual({ ok: false, error: "Invalid request" });
    }
    expect((await verify(request())).status).toBe(429);
    expect(mocks.verifyPassword).not.toHaveBeenCalled();
  });
});
