// Locks forceStream resolution for compatible nodes: a gateway whose
// non-streaming path is broken (fengwind muse-spark answers an omitted-`stream`
// request with 503 after 30-100s) can be driven over SSE upstream while the
// client still receives a plain JSON body.
//
// Two layers must agree, so both are asserted here:
//   - resolveForceStream() decides whether the node is force-streamed
//   - DefaultExecutor.transformRequest() puts stream:true on the upstream body
import { describe, it, expect } from "vitest";
import { resolveForceStream } from "open-sse/services/provider.js";
import { DefaultExecutor } from "open-sse/executors/default.js";

const NODE = "openai-compatible-chat-843fd785-06f9-4403-9651-c621aee6de40";
const ANTHROPIC_NODE = "anthropic-compatible-4b47c772-e115-402e-831e-01a6b57f7423";
const PLAIN = "openai";
const MODEL = "muse-spark-1.3-contributor";

const creds = (psd) => ({ providerSpecificData: psd });

describe("resolveForceStream", () => {
  it("is off when the connection carries no forceStream flag", () => {
    expect(resolveForceStream(NODE, creds({ baseUrl: "https://x/v1" }), MODEL)).toBe(false);
    expect(resolveForceStream(NODE, null, MODEL)).toBe(false);
    expect(resolveForceStream(NODE, creds(undefined), MODEL)).toBe(false);
  });

  it("is on for a node-wide forceStream", () => {
    expect(resolveForceStream(NODE, creds({ forceStream: true }), MODEL)).toBe(true);
  });

  it("is on for a per-model forceStream key", () => {
    const psd = { [`forceStream_${MODEL}`]: true };
    expect(resolveForceStream(NODE, creds(psd), MODEL)).toBe(true);
    // ...and does not leak to sibling models on the same connection.
    expect(resolveForceStream(NODE, creds(psd), "kimi-k3")).toBe(false);
  });

  it("only treats an explicit boolean true as on", () => {
    expect(resolveForceStream(NODE, creds({ forceStream: "true" }), MODEL)).toBe(false);
    expect(resolveForceStream(NODE, creds({ forceStream: 1 }), MODEL)).toBe(false);
    expect(resolveForceStream(NODE, creds({ forceStream: false }), MODEL)).toBe(false);
  });

  it("applies to anthropic-compatible nodes too", () => {
    expect(resolveForceStream(ANTHROPIC_NODE, creds({ forceStream: true }), MODEL)).toBe(true);
  });

  it("never touches non-compatible providers (registry providers own their flag)", () => {
    expect(resolveForceStream(PLAIN, creds({ forceStream: true }), MODEL)).toBe(false);
  });
});

describe("DefaultExecutor.transformRequest forceStream wiring", () => {
  it("adds stream:true to the upstream body when the node is force-streamed", () => {
    const ex = new DefaultExecutor(NODE);
    const body = { model: MODEL, messages: [{ role: "user", content: "hi" }] };
    const out = ex.transformRequest(MODEL, body, false, creds({ forceStream: true }));
    expect(out.stream).toBe(true);
  });

  it("leaves the body alone without the flag", () => {
    const ex = new DefaultExecutor(NODE);
    const body = { model: MODEL, messages: [{ role: "user", content: "hi" }] };
    const out = ex.transformRequest(MODEL, body, false, creds({ baseUrl: "https://x/v1" }));
    expect(out.stream).toBeUndefined();
  });

  it("does not mutate the caller's body object", () => {
    const ex = new DefaultExecutor(NODE);
    const body = { model: MODEL, messages: [{ role: "user", content: "hi" }] };
    ex.transformRequest(MODEL, body, false, creds({ forceStream: true }));
    expect(body.stream).toBeUndefined();
  });
});
