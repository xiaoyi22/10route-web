import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

let testApi;
try { testApi = await import("vitest"); }
catch (error) {
  if (error.code !== "ERR_MODULE_NOT_FOUND") throw error;
  testApi = await import("node:test");
}
const { describe, it, beforeEach, afterEach } = testApi;
const repoRoot = fileURLToPath(new URL("../../", import.meta.url));
const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "10router-ag-fix1-"));
process.env.DATA_DIR = tempDir;
// proxyFetch must capture the stub, not Node's network implementation.
let mockFetch = async url => { throw new Error(`Unexpected offline fetch: ${url}`); };
globalThis.fetch = (...args) => mockFetch(...args);
const {
  persistQuarantine, quarantineConnection, resetQuarantineMemory,
  isAntigravityBlocked, getQuarantinedConnection, isConnectionQuarantined,
  classifyAntigravityError,
} = await import("../../open-sse/services/antigravityQuarantine.js");
const repo = await import("../../src/lib/db/repos/connectionsRepo.js");
const { getAdapter } = await import("../../src/lib/db/driver.js");
const { handleFusionChat } = await import("../../open-sse/services/combo.js");
const { handleChatCore } = await import("../../open-sse/handlers/chatCore.js");
const { AntigravityExecutor } = await import("../../open-sse/executors/antigravity.js");
const { getAllAccessTokens } = await import("../../open-sse/services/tokenRefresh.js");
const { fetchAntigravityUserQuotaSummaryCached } = await import("../../open-sse/services/usage/antigravityWeeklyQuota.js");
const { fetchWithTimeout } = await import("../../open-sse/services/usage/shared.js");
const { proxyAwareFetch } = await import("../../open-sse/utils/proxyFetch.js");
const log = { info() {}, warn() {}, error() {}, debug() {} };
const model = "gemini-3.8-flash-high";
const body = { model: `ag/${model}`, stream: false, messages: [{ role: "user", content: "offline" }] };
const success = () => Response.json({ choices: [{ message: { content: "offline answer" } }] });
const tos = () => new Response(JSON.stringify({ error: { message: "This service has been disabled in this account for violation of Terms of Service." } }), { status: 403 });
const proxy = { connectionProxyEnabled: true, connectionProxyUrl: "http://127.0.0.1:9", strictProxy: false };

async function account(name) {
  return repo.createProviderConnection({ provider: "antigravity", authType: "oauth", name,
    email: `${crypto.randomUUID()}@example.invalid`, accessToken: `token-${name}`,
    refreshToken: `refresh-${name}`, projectId: `project-${name}`, isActive: true });
}
function core(credentials, executor, provider = "antigravity") {
  return handleChatCore({ body: { ...body }, modelInfo: { provider, model: provider === "antigravity" ? model : "gpt-4o" },
    credentials: { ...credentials }, connectionId: credentials.id, _executorOverride: executor });
}
function remoteRelease(id) {
  const child = spawnSync(process.execPath, ["--import", "./tests/test-loader.mjs", "--input-type=module", "-e", `
    globalThis.fetch = async () => { throw new Error('Network forbidden'); };
    const { releaseAntigravityQuarantine } = await import('./src/lib/db/repos/connectionsRepo.js');
    if (!await releaseAntigravityQuarantine(${JSON.stringify(id)})) throw new Error('Release failed');
  `], { cwd: repoRoot, env: { ...process.env, DATA_DIR: tempDir }, encoding: "utf8", timeout: 15000 });
  assert.equal(child.status, 0, child.stdout + child.stderr);
}

describe("AG P0 fix1 report regressions (offline)", () => {
  beforeEach(async () => {
    resetQuarantineMemory();
    repo.registerQuarantinePersistenceHandler();
    mockFetch = async url => { throw new Error(`Unexpected offline fetch: ${url}`); };
    for (const c of await repo.getProviderConnections({ provider: "antigravity" })) await repo.deleteProviderConnection(c.id);
  });
  afterEach(() => resetQuarantineMemory());

  for (const successfulPanels of [2, 1, 0]) {
    it(`R1 stops fusion after TOS with ${successfulPanels} successful panels`, async () => {
      const stopped = tos();
      stopped.isTosQuarantined = true;
      const models = ["ag/banned", "ag/healthy", "other/panel"];
      const calls = [];
      const response = await handleFusionChat({ body, models, judgeModel: "ag/judge", log,
        handleSingleModel: async (_body, m) => {
          calls.push(m);
          if (m === models[0]) return stopped;
          return models.indexOf(m) <= successfulPanels ? success() : new Response("failed", { status: 500 });
        } });
      assert.deepEqual(calls, models, "No judge/replay may be newly scheduled after TOS");
      assert.equal(response, stopped, "Preserve the TOS stop for outer combos/account loops");
    });
  }

  it("R1 retains a TOS arriving after quorum while panel JSON is being consumed", async () => {
    let completeTos;
    let parsing;
    const parsingStarted = new Promise(resolve => { parsing = resolve; });
    let finishJson;
    const jsonReady = new Promise(resolve => { finishJson = resolve; });
    const stopped = tos();
    stopped.isTosQuarantined = true;
    const calls = [];
    const pending = handleFusionChat({ body, models: ["other/one", "other/two", "ag/late"], judgeModel: "ag/judge", log,
      tuning: { minPanel: 2, stragglerGraceMs: 1, panelHardTimeoutMs: 1000 },
      handleSingleModel: async (_body, m) => {
        calls.push(m);
        if (m === "ag/late") return new Promise(resolve => { completeTos = resolve; });
        const res = success();
        if (m === "other/one") res.clone = () => ({ json: async () => { parsing(); await jsonReady; return { choices: [{ message: { content: "one" } }] }; } });
        return res;
      } });
    await parsingStarted;
    completeTos(stopped);
    await new Promise(resolve => setImmediate(resolve));
    finishJson();
    assert.equal(await pending, stopped);
    assert.deepEqual(calls, ["other/one", "other/two", "ag/late"]);
  });

  it("R1 preserves healthy fusion judge scheduling", async () => {
    const calls = [];
    const result = await handleFusionChat({ body, models: ["other/one", "other/two"], judgeModel: "ag/judge", log,
      handleSingleModel: async (_body, m) => { calls.push(m); return success(); } });
    assert.equal(result.status, 200);
    assert.deepEqual(calls, ["other/one", "other/two", "ag/judge"]);
  });

  it("R2 AG quota transport does not fall back after concurrent quarantine", async () => {
    const conn = await account("transport-race");
    const attempts = [];
    mockFetch = async (_url, options) => {
      attempts.push({ proxy: !!options.dispatcher, blocked: isConnectionQuarantined(conn.id) });
      if (attempts.length === 1) {
        quarantineConnection(conn.id);
        throw new Error("offline proxy failure");
      }
      return Response.json({ groups: [] });
    };
    let error;
    try {
      await fetchAntigravityUserQuotaSummaryCached(conn.accessToken, conn.projectId, "https://quota.invalid/summary", "offline", proxy,
        { forceRefresh: true, credentials: conn });
    } catch (e) { error = e; }
    assert.deepEqual(attempts, [{ proxy: true, blocked: false }], "No direct send after isolation");
    assert.equal(error?.code, "AG_TOS_QUARANTINED");
  });

  it("R2 preserves non-AG proxy fallback and strictProxy", async () => {
    const attempts = [];
    mockFetch = async (_url, options) => {
      attempts.push(!!options.dispatcher);
      if (options.dispatcher) throw new Error("offline proxy failure");
      return success();
    };
    assert.equal((await fetchWithTimeout("https://non-ag.invalid/usage", {}, 1000, proxy)).status, 200);
    assert.deepEqual(attempts, [true, false]);
    attempts.length = 0;
    await assert.rejects(proxyAwareFetch("https://non-ag.invalid/usage", {}, { ...proxy, strictProxy: true }), /strictProxy=true/);
    assert.deepEqual(attempts, [true]);
  });

  for (const action of ["disable", "delete"]) {
    it(`R3 local ${action} blocks stale execute without inventing upstream TOS`, async () => {
      const conn = await account(`local-${action}`);
      if (action === "disable") await repo.updateProviderConnection(conn.id, { isActive: false });
      else await repo.deleteProviderConnection(conn.id);
      let networkCalls = 0;
      mockFetch = async () => { networkCalls++; return success(); };
      const executor = new AntigravityExecutor();
      const response = (await executor.execute({ model, body: {}, credentials: conn })).response;
      const result = await core(conn, executor);
      assert.equal(networkCalls, 0);
      assert.equal(result.status, 403);
      assert.notEqual(result.isTosQuarantined, true, "Local disable is not new upstream TOS evidence");
      assert.equal(classifyAntigravityError(response.status, await response.text()).isTos, false);
      assert.equal(isConnectionQuarantined(conn.id), false);
      const saved = await repo.getProviderConnectionById(conn.id);
      if (action === "disable") {
        assert.equal(saved.isActive, false);
        assert.equal(saved.quarantine, undefined);
        assert.notEqual(saved.testStatus, "quarantined");
      } else assert.equal(saved, null);
    });
  }

  it("R3 previously quarantined local refusal still propagates stop without creating a new event", async () => {
    const conn = await account("local-quarantine");
    await persistQuarantine(conn.id);
    const entry = getQuarantinedConnection(conn.id);
    const result = await core(conn, new AntigravityExecutor());
    assert.equal(result.status, 403);
    assert.equal(result.isTosQuarantined, true);
    assert.equal(getQuarantinedConnection(conn.id), entry, "Local refusal must not mint another upstream TOS event");
  });

  for (const failure of ["null", "throw"]) {
    it(`R4 AG 401 refresh ${failure} is attempted only once`, async () => {
      const conn = await account(`401-${failure}`);
      let refreshes = 0, generated = 0;
      const result = await core(conn, { noAuth: false,
        execute: async () => { generated++; return { response: new Response("unauthenticated", { status: 401 }), url: "https://offline.invalid" }; },
        refreshCredentials: async () => { refreshes++; if (failure === "throw") throw new Error("offline refresh failure"); return null; } });
      assert.equal(refreshes, 1);
      assert.equal(generated, 1);
      assert.equal(result.status, 401);
      assert.equal(isConnectionQuarantined(conn.id), false);
    });
  }

  it("R4 non-AG 401 retains three failed refresh attempts", async () => {
    let refreshes = 0;
    const result = await core({ id: "offline-openai", accessToken: "old" }, { noAuth: false,
      execute: async () => ({ response: new Response("unauthenticated", { status: 401 }), url: "https://offline.invalid" }),
      refreshCredentials: async () => { refreshes++; return null; } }, "openai");
    assert.equal(refreshes, 3);
    assert.equal(result.status, 401);
  });

  for (const ok of [false, true]) {
    it(`R4 concurrent real AG 401 recovery shares one ${ok ? "successful" : "failed"} refresh`, async () => {
      const conn = await account(`concurrent-${ok}`);
      let refreshes = 0, generated = 0;
      const releases = [];
      let reached;
      const bothRefreshing = new Promise(resolve => { reached = resolve; });
      const executor = new AntigravityExecutor();
      let entered = 0;
      const realRefresh = executor.refreshCredentials.bind(executor);
      executor.refreshCredentials = (...args) => {
        const result = realRefresh(...args);
        if (++entered === 2) reached();
        return result;
      };
      mockFetch = async (url, options) => {
        if (String(url).includes("oauth2")) {
          refreshes++;
          await new Promise(resolve => { releases.push(resolve); });
          return ok ? Response.json({ access_token: "new-token", expires_in: 3600 }) : new Response("offline refresh failure", { status: 400 });
        }
        generated++;
        return options.headers.Authorization === "Bearer new-token" ? success() : new Response("unauthenticated", { status: 401 });
      };
      const pending = Promise.all([core(conn, executor), core(conn, executor)]);
      await bothRefreshing;
      // Both callers have entered the real refresh method; let its async guards settle.
      await new Promise(resolve => setImmediate(resolve));
      // Release every in-flight mock without leaving the buggy baseline hanging.
      mockFetch = async (url, options) => {
        if (String(url).includes("oauth2")) { refreshes++; return new Response("offline failure", { status: 400 }); }
        generated++;
        return options.headers.Authorization === "Bearer new-token" ? success() : new Response("unauthenticated", { status: 401 });
      };
      for (const release of releases) release();
      const results = await pending;
      assert.equal(refreshes, 1);
      assert.equal(generated, ok ? 4 : 2);
      assert.ok(results.every(r => ok ? r.success : r.status === 401));
    });
  }

  it("R5 remote release survives late ordinary write before any guard runs", async () => {
    const conn = await account("remote-release-write");
    await persistQuarantine(conn.id);
    assert.equal(getQuarantinedConnection(conn.id).persisted, true);
    remoteRelease(conn.id);
    assert.equal((await repo.getProviderConnectionById(conn.id)).isActive, true);
    await repo.updateProviderConnection(conn.id, { accessToken: "late-token", quotaCheckedAt: new Date().toISOString(), testStatus: "active", lastError: null });
    const saved = await repo.getProviderConnectionById(conn.id);
    assert.equal(saved.isActive, true, "Late write must not resurrect already released memory event");
    assert.equal(saved.quarantine, undefined);
    assert.equal(saved.accessToken, "late-token");
    assert.equal(await isAntigravityBlocked(conn), false);
  });

  it("R5 remote release survives OAuth dedup write before any guard runs", async () => {
    const conn = await account("remote-release-oauth");
    await persistQuarantine(conn.id);
    remoteRelease(conn.id);
    const saved = await repo.createProviderConnection({ ...conn, accessToken: "relogin", testStatus: "active" });
    assert.equal(saved.id, conn.id);
    assert.equal(saved.isActive, true);
    assert.equal(saved.quarantine, undefined);
    assert.equal(await isAntigravityBlocked(conn), false);
  });

  it("R5 release does not discard a new unpersisted TOS event on ordinary write", async () => {
    const conn = await account("remote-release-new-event");
    await persistQuarantine(conn.id);
    remoteRelease(conn.id);
    const db = await getAdapter();
    db.exec(`CREATE TRIGGER ag_fix1_fail BEFORE UPDATE ON providerConnections WHEN OLD.id = '${conn.id}' BEGIN SELECT RAISE(ABORT, 'offline injected write failure'); END`);
    try { assert.equal((await persistQuarantine(conn.id)).persisted, false); }
    finally { db.exec("DROP TRIGGER ag_fix1_fail"); }
    const pendingEvent = getQuarantinedConnection(conn.id);
    assert.equal(pendingEvent.persisted, false);
    await repo.updateProviderConnection(conn.id, { isActive: true, testStatus: "active", quarantine: null, lastError: null });
    const saved = await repo.getProviderConnectionById(conn.id);
    assert.equal(saved.isActive, false);
    assert.equal(saved.quarantine.quarantinedAt, pendingEvent.quarantinedAt);
    assert.equal(await isAntigravityBlocked(conn), true);
  });

  it("R6 batch refresh rechecks stale active snapshot by connection identity", async () => {
    const conn = await account("batch-stale");
    await persistQuarantine(conn.id);
    resetQuarantineMemory(); // Must read persisted state, not just a process-local map.
    let networkCalls = 0;
    mockFetch = async () => { networkCalls++; return Response.json({ access_token: "should-not-refresh", expires_in: 3600 }); };
    const tokens = await getAllAccessTokens({ connections: [conn] });
    assert.equal(networkCalls, 0);
    assert.deepEqual(tokens, {});
  });

  it("R6 batch retains quarantine snapshot without an ID and healthy non-AG refresh", async () => {
    let networkCalls = 0;
    mockFetch = async () => { networkCalls++; return Response.json({ access_token: "healthy-token", expires_in: 3600 }); };
    const tokens = await getAllAccessTokens({ connections: [
      { provider: "antigravity", isActive: true, refreshToken: "offline-blocked", quarantine: { reason: "TOS_VIOLATION" } },
      { provider: "gemini-cli", isActive: true, refreshToken: "offline-healthy" },
    ] });
    assert.equal(networkCalls, 1);
    assert.equal(tokens.antigravity, undefined);
    assert.equal(tokens["gemini-cli"].accessToken, "healthy-token");
  });
});
