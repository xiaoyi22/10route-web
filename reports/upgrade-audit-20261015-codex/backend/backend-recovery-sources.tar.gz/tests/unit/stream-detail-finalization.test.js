import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";

const originalDataDir = process.env.DATA_DIR;
let tempDir;
let db;
let handleStreamingResponse;
let buildOnStreamComplete;
let buildRequestDetail;
let createStreamController;
let formats;
let getDetails;
let getAdapter;

beforeAll(async () => {
  tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "10router-stream-finalization-"));
  process.env.DATA_DIR = tempDir;
  vi.resetModules();
  db = await import("@/lib/db/index.js");
  await db.initDb();
  await db.updateSettings({ enableObservability: true, observabilityBatchSize: 1 });
  ({ handleStreamingResponse, buildOnStreamComplete } = await import("../../open-sse/handlers/chatCore/streamingHandler.js"));
  ({ buildRequestDetail } = await import("../../open-sse/handlers/chatCore/requestDetail.js"));
  ({ createStreamController } = await import("../../open-sse/utils/streamHandler.js"));
  ({ FORMATS: formats } = await import("../../open-sse/translator/formats.js"));
  ({ GET: getDetails } = await import("../../src/app/api/usage/request-details/route.js"));
  ({ getAdapter } = await import("@/lib/db/driver.js"));
});

afterAll(() => {
  if (tempDir) fs.rmSync(tempDir, { recursive: true, force: true });
  if (originalDataDir === undefined) delete process.env.DATA_DIR;
  else process.env.DATA_DIR = originalDataDir;
});

async function waitForDetail(id, predicate = () => true) {
  for (let attempt = 0; attempt < 100; attempt += 1) {
    const detail = await db.getRequestDetailById(id);
    if (detail && predicate(detail)) return detail;
    await new Promise(resolve => setTimeout(resolve, 10));
  }
  throw new Error("Request detail did not settle: " + id);
}

async function openStream({ terminal, usage = { prompt_tokens: 11, completion_tokens: 2 }, sourceFormat, waitForTerminal = true }) {
  let upstreamController;
  const upstream = new Response(new ReadableStream({
    start(controller) {
      upstreamController = controller;
      controller.enqueue(new TextEncoder().encode("data: " + JSON.stringify({
        id: "chat-test", object: "chat.completion.chunk", model: "test-model",
        choices: [{ index: 0, delta: { content: "hello" }, finish_reason: terminal ? "stop" : null }],
        ...(usage ? { usage } : {}),
      }) + "\n\n"));
    },
  }), { headers: { "content-type": "text/event-stream" } });
  const body = { model: "test-model", messages: [{ role: "user", content: "hi" }], stream: true };
  const args = { provider: "test-provider", model: "test-model", connectionId: "test-connection",
    requestStartTime: Date.now() - 20, body, stream: true, translatedBody: body,
    clientRawRequest: { endpoint: sourceFormat === formats.OPENAI ? "/v1/chat/completions" : sourceFormat === formats.CLAUDE ? "/v1/messages" : "/v1/responses", upstreamEndpoint: "/v1/chat/completions" },
  };
  const completion = buildOnStreamComplete(args);
  const result = await handleStreamingResponse({ ...args, ...completion, providerResponse: upstream,
    sourceFormat, targetFormat: formats.OPENAI, streamController: createStreamController({ provider: args.provider, model: args.model }),
  });
  const reader = result.response.body.getReader();
  let text = "";
  while (!text.includes(terminal && waitForTerminal && sourceFormat === formats.OPENAI_RESPONSES ? "response.completed" : "hello")) {
    const chunk = await reader.read();
    if (chunk.done) throw new Error("Expected streamed output");
    text += new TextDecoder().decode(chunk.value);
  }
  return { reader, upstreamController, id: completion.streamDetailId };
}

async function drain(reader) {
  let text = "";
  for (;;) {
    const chunk = await reader.read();
    if (chunk.done) return text;
    text += new TextDecoder().decode(chunk.value);
  }
}

describe("stream terminal detail and usage settlement", () => {
  it("keeps a Responses completion successful when upstream transport closes after its terminal event", async () => {
    const stream = await openStream({ terminal: true, sourceFormat: formats.OPENAI_RESPONSES });
    stream.upstreamController.error(new Error("socket hang up"));
    const tail = await drain(stream.reader);
    const detail = await waitForDetail(stream.id, row => row.status !== "streaming");
    await new Promise(resolve => setTimeout(resolve, 30));
    const settled = await db.getRequestDetailById(stream.id);
    expect(settled.status).toBe("success");
    expect(settled.tokens).toMatchObject({ prompt_tokens: 11, completion_tokens: 2 });
    expect(settled.latency.ttft).toBeGreaterThan(0);
    expect(settled.usageSource).toBe("upstream");
    expect(tail).not.toContain("upstream connection lost");
    expect(detail.id).toBe(stream.id);
  });

  it("keeps partial upstream usage and TTFT on a genuine interrupted Chat stream", async () => {
    const stream = await openStream({ terminal: false, sourceFormat: formats.OPENAI });
    stream.upstreamController.error(new Error("socket hang up"));
    await drain(stream.reader);
    await waitForDetail(stream.id, row => row.status !== "streaming");
    await new Promise(resolve => setTimeout(resolve, 30));
    const settled = await db.getRequestDetailById(stream.id);
    expect(["failed", "error"]).toContain(settled.status);
    expect(settled.tokens).toMatchObject({ prompt_tokens: 11, completion_tokens: 2 });
    expect(settled.latency.ttft).toBeGreaterThan(0);
    expect(settled.error.code).toBe("stream_disconnected");
    expect(settled.usageSource).toBe("upstream");
    const adapter = await getAdapter();
    const rows = adapter.all("SELECT status, tokens, meta FROM usageHistory");
    const usageRow = rows.find(row => JSON.parse(row.meta).requestId === stream.id);
    expect(usageRow.status).toBe("error");
    expect(JSON.parse(usageRow.tokens)).toMatchObject({ prompt_tokens: 11, completion_tokens: 2 });
    const failedResponse = await getDetails(new Request("http://localhost/api/usage/request-details?provider=test-provider&status=error&pageSize=100"));
    expect((await failedResponse.json()).details.some(row => row.id === stream.id)).toBe(true);
  });

  it("keeps a completed response successful when the client closes after its terminal event", async () => {
    const stream = await openStream({ terminal: true, sourceFormat: formats.OPENAI_RESPONSES });
    await stream.reader.cancel("ResponseAborted");
    const settled = await waitForDetail(stream.id, row => row.status !== "streaming");
    expect(settled.status).toBe("success");
    expect(settled.tokens).toMatchObject({ prompt_tokens: 11, completion_tokens: 2 });
  });

  it("settles normally from upstream tail usage rather than retaining the finish-chunk estimate", async () => {
    const stream = await openStream({ terminal: true, usage: null, sourceFormat: formats.OPENAI_RESPONSES, waitForTerminal: false });
    stream.upstreamController.enqueue(new TextEncoder().encode('data: {"choices":[],"usage":{"prompt_tokens":11,"completion_tokens":2,"prompt_tokens_details":{"cached_tokens":8}}}\n\ndata: [DONE]\n\n'));
    stream.upstreamController.close();
    await drain(stream.reader);
    const settled = await waitForDetail(stream.id, row => row.status !== "streaming");
    expect(settled.status).toBe("success");
    expect(settled.tokens).toMatchObject({ prompt_tokens: 11, completion_tokens: 2, cached_tokens: 8 });
    expect(settled.usageSource).toBe("upstream");
  });

  it.each([{ choices: [] }, { choices: [{ index: 0, delta: {}, finish_reason: null }] }])("keeps usage-only Chat tail chunks with choices $choices", async ({ choices }) => {
    const stream = await openStream({ terminal: true, usage: null, sourceFormat: formats.OPENAI });
    stream.upstreamController.enqueue(new TextEncoder().encode("data: " + JSON.stringify({ choices, usage: { prompt_tokens: 11, completion_tokens: 2, prompt_tokens_details: { cached_tokens: 8 } } }) + "\n\ndata: [DONE]\n\n"));
    stream.upstreamController.close();
    await drain(stream.reader);
    const settled = await waitForDetail(stream.id, row => row.status !== "streaming");
    expect(settled.status).toBe("success");
    expect(settled.tokens).toMatchObject({ prompt_tokens: 11, completion_tokens: 2, cached_tokens: 8 });
    expect(settled.usageSource).toBe("upstream");
  });

  it("does not replace measured usage when the finish chunk itself omits usage", async () => {
    const stream = await openStream({ terminal: false, sourceFormat: formats.OPENAI });
    stream.upstreamController.enqueue(new TextEncoder().encode('data: {"choices":[{"index":0,"delta":{},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n'));
    stream.upstreamController.close();
    await drain(stream.reader);
    const settled = await waitForDetail(stream.id, row => row.status !== "streaming");
    expect(settled.tokens).toMatchObject({ prompt_tokens: 11, completion_tokens: 2 });
    expect(settled.usageSource).toBe("upstream");
  });

  it("keeps partial usage when a Claude client receives a genuine interrupted Chat upstream", async () => {
    const stream = await openStream({ terminal: false, sourceFormat: formats.CLAUDE });
    stream.upstreamController.error(new Error("socket hang up"));
    await drain(stream.reader);
    const settled = await waitForDetail(stream.id, row => row.status !== "streaming");
    expect(["failed", "error"]).toContain(settled.status);
    expect(settled.tokens).toMatchObject({ input_tokens: 11, output_tokens: 2 });
    expect(settled.endpoint).toBe("/v1/messages");
  });

  it("records usage only once when completion is called repeatedly", async () => {
    const completion = buildOnStreamComplete({ provider: "test-provider", model: "duplicate-model", requestStartTime: Date.now() - 20, body: {}, stream: true });
    completion.onStreamComplete({ content: "hello" }, { prompt_tokens: 11, completion_tokens: 2 }, Date.now());
    completion.onStreamComplete({ content: "hello" }, { prompt_tokens: 11, completion_tokens: 2 }, Date.now());
    await waitForDetail(completion.streamDetailId);
    const adapter = await getAdapter();
    const rows = adapter.all("SELECT meta FROM usageHistory WHERE model = ?", ["duplicate-model"]);
    expect(rows).toHaveLength(1);
    expect(JSON.parse(rows[0].meta).requestId).toBe(completion.streamDetailId);
  });

  it("marks a partial-content estimate rather than presenting it as upstream usage", async () => {
    const stream = await openStream({ terminal: false, usage: null, sourceFormat: formats.OPENAI });
    stream.upstreamController.error(new Error("socket hang up"));
    await drain(stream.reader);
    await waitForDetail(stream.id, row => row.status !== "streaming");
    await new Promise(resolve => setTimeout(resolve, 30));
    const settled = await db.getRequestDetailById(stream.id);
    expect(settled.tokens.completion_tokens).toBeGreaterThan(0);
    expect(settled.usageSource).toBe("estimated");
    expect(["failed", "error"]).toContain(settled.status);
  });

  it("preserves a real upstream 429 reason through storage and conversation redaction", async () => {
    const detail = buildRequestDetail({ provider: "test-provider", model: "luna", status: "error",
      response: { status: 429, error: '{"error":{"code":"channel_daily_success_limit_exceeded","message":"channel_daily_success_limit_exceeded"}}{"error":{"message":"new_api_panic"}}' },
      request: { messages: [{ role: "user", content: "private prompt" }] },
    }, { id: "upstream-429" });
    await db.saveRequestDetail(detail);
    await waitForDetail(detail.id);
    const response = await getDetails(new Request("http://localhost/api/usage/request-details?provider=test-provider&pageSize=100"));
    const stored = (await response.json()).details.find(row => row.id === detail.id);
    expect(stored.status).toBe("error");
    expect(stored.error).toMatchObject({ status: 429, code: "channel_daily_success_limit_exceeded", message: "channel_daily_success_limit_exceeded" });
    expect(stored.tokens).toEqual({ prompt_tokens: 0, completion_tokens: 0 });
    expect(stored.usageSource).toBe("unavailable");
    expect(stored.request).toEqual({ redacted: true });
    expect(stored.response).toEqual({ redacted: true });
  });

  it("redacts credentials and query strings from persisted error metadata", async () => {
    await db.saveRequestDetail({ id: "redacted-error", provider: "test-provider", model: "redaction", status: "error",
      error: { status: 401, code: "invalid_api_key", message: "Bearer private-token sk-privatekey api_key=private-key https://user:password@example.com/v1/chat?token=private-query" },
    });
    const settled = await waitForDetail("redacted-error");
    expect(settled.error.message).not.toMatch(/private|password|user:|token=/);
    expect(settled.error.message).toContain("https://example.com/v1/chat");
    expect(settled.error.status).toBe(401);
  });
});
