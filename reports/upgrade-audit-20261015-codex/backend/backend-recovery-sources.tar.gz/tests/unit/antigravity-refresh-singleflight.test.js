import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

let testApi;
try { testApi = await import("vitest"); }
catch (error) {
  if (error.code !== "ERR_MODULE_NOT_FOUND") throw error;
  testApi = await import("node:test");
}
const { describe, it, beforeEach, afterEach } = testApi;

const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "10router-ag-singleflight-"));
process.env.DATA_DIR = tempDir;

const repo = await import("../../src/lib/db/repos/connectionsRepo.js");
const { updateSettings } = await import("../../src/lib/db/repos/settingsRepo.js");
const { persistQuarantine, resetQuarantineMemory } = await import("../../open-sse/services/antigravityQuarantine.js");
const ocm = await import("../../open-sse/services/oauthCredentialManager.js");
const tr = await import("../../open-sse/services/tokenRefresh.js");
const { AntigravityExecutor } = await import("../../open-sse/executors/antigravity.js");
const appRefresh = await import("../../src/sse/services/tokenRefresh.js");

const log = { info() {}, warn() {}, error() {}, debug() {} };
const TOK = "https://oauth2.googleapis.com/token";

let tokenFetches, inFlight, maxInFlight, failMode;
function installFetch(delayMs = 15) {
  tokenFetches = 0; inFlight = 0; maxInFlight = 0;
  globalThis.fetch = async (url) => {
    if (String(url).includes("oauth2.googleapis.com")) {
      tokenFetches++; inFlight++; maxInFlight = Math.max(maxInFlight, inFlight);
      await new Promise(r => setTimeout(r, delayMs));
      inFlight--;
      if (failMode) return new Response("boom", { status: 500 });
      return Response.json({ access_token: `fresh-${Date.now()}`, expires_in: 3600, refresh_token: "rotated-rt" });
    }
    throw new Error(`Unexpected offline fetch: ${url}`);
  };
}

async function account(name) {
  return repo.createProviderConnection({ provider: "antigravity", authType: "oauth", name,
    email: `${name}@example.invalid`, accessToken: "old", refreshToken: `rt-${name}`,
    expiresAt: new Date(Date.now() + 3600000).toISOString(), isActive: true });
}
const credsFor = c => ({ ...c, connectionId: c.id, provider: "antigravity" });

describe("AG P1-3 refresh singleflight across all entry points (offline)", () => {
  beforeEach(async () => {
    resetQuarantineMemory();
    repo.registerQuarantinePersistenceHandler();
    failMode = false;
    installFetch();
    for (const c of await repo.getProviderConnections()) await repo.deleteProviderConnection(c.id);
    await updateSettings({ requireApiKey: false });
  });
  afterEach(() => resetQuarantineMemory());

  it("concurrent refreshes through every AG entry point share ONE token HTTP call", async () => {
    const conn = await account("shared");
    const creds = credsFor(conn);
    const executor = new AntigravityExecutor();
    const jobs = [];
    for (let i = 0; i < 5; i++) jobs.push(ocm.refreshProviderCredentials("antigravity", { ...creds }));
    for (let i = 0; i < 5; i++) jobs.push(executor.refreshCredentials({ ...creds }, log));
    for (let i = 0; i < 5; i++) jobs.push(tr.getAccessToken("antigravity", { ...creds, refreshToken: conn.refreshToken }, log));
    for (let i = 0; i < 5; i++) jobs.push(appRefresh.checkAndRefreshToken("antigravity", { ...creds }, { force: true }));
    const settled = await Promise.race([
      Promise.allSettled(jobs),
      new Promise((_, rej) => setTimeout(() => rej(new Error("deadlock: concurrent refreshes never settle")), 5000)),
    ]).catch(e => { assert.fail(e.message); });
    assert.ok(settled.every(s => s.status === "fulfilled"), "every entry point settles without deadlock");
    assert.equal(tokenFetches, 1, `20 concurrent refreshes must collapse to 1 token HTTP, got ${tokenFetches}`);
  });

  it("different credentials refresh independently and in parallel", async () => {
    const c1 = await account("par-1");
    const c2 = await account("par-2");
    const [t1, t2] = await Promise.all([
      ocm.refreshProviderCredentials("antigravity", credsFor(c1)),
      tr.getAccessToken("antigravity", { ...credsFor(c2), refreshToken: c2.refreshToken }, log),
    ]);
    assert.ok(t1 && t2, "both refreshes produce results");
    assert.equal(tokenFetches, 2, "distinct identities get their own token HTTP");
    assert.ok(maxInFlight >= 2, "distinct identities are not serialized behind one lock");
  });

  it("failed refresh releases the lock so a later refresh can proceed", async () => {
    const conn = await account("retry");
    const creds = credsFor(conn);
    failMode = true;
    const first = await ocm.refreshProviderCredentials("antigravity", { ...creds });
    assert.equal(first, null, "failed refresh resolves to null");
    assert.equal(tokenFetches, 1);
    failMode = false;
    const second = await ocm.refreshProviderCredentials("antigravity", { ...creds });
    assert.ok(second?.accessToken, "retry after failure succeeds (lock not leaked)");
    assert.equal(tokenFetches, 2);
  });

  it("quarantined account: mixed concurrent entry points produce ZERO token HTTP", async () => {
    const conn = await account("banned");
    await persistQuarantine(conn.id, "TOS_VIOLATION", log);
    const creds = credsFor(conn);
    const executor = new AntigravityExecutor();
    await Promise.all([
      ocm.refreshProviderCredentials("antigravity", { ...creds }),
      executor.refreshCredentials({ ...creds }, log),
      tr.getAccessToken("antigravity", { ...creds, refreshToken: conn.refreshToken }, log),
      appRefresh.checkAndRefreshToken("antigravity", { ...creds }, { force: true }),
    ]);
    assert.equal(tokenFetches, 0, "quarantine blocks every refresh entry point");
  });
});
