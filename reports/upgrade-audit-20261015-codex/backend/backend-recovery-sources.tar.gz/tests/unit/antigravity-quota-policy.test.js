import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

let testApi;
try { testApi = await import("vitest"); }
catch (error) {
  if (error.code !== "ERR_MODULE_NOT_FOUND") throw error;
  testApi = await import("node:test");
}
const { describe, it, beforeEach } = testApi;

const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "10router-ag-quota-"));
process.env.DATA_DIR = tempDir;
globalThis.fetch = async () => { throw new Error("offline"); };

const repo = await import("../../src/lib/db/repos/connectionsRepo.js");
const { updateSettings } = await import("../../src/lib/db/repos/settingsRepo.js");
const { markAccountUnavailable } = await import("../../src/sse/services/auth.js");
const { MAX_RATE_LIMIT_COOLDOWN_MS } = await import("../../open-sse/config/errorConfig.js");

const logs = [];
const log = { info: (...a) => logs.push(["info", ...a]), warn: (...a) => logs.push(["warn", ...a]), error: (...a) => logs.push(["error", ...a]), debug: () => {} };
const LOCK = "modelLock_gemini-3.8-flash-high";

async function account(name) {
  return repo.createProviderConnection({ provider: "antigravity", authType: "oauth", name,
    email: `${name}@example.invalid`, accessToken: "t", refreshToken: "r", isActive: true });
}
const lockMs = conn => new Date(conn[LOCK]).getTime() - Date.now();

describe("AG P1-2 quota reset honored (no early probing)", () => {
  beforeEach(async () => {
    logs.length = 0;
    for (const c of await repo.getProviderConnections()) await repo.deleteProviderConnection(c.id);
    await updateSettings({ requireApiKey: false, rtkEnabled: false, headroomEnabled: false, pxpipeEnabled: false });
  });

  it("AG 429 with 3h reset locks the model ~3h, not the 30-minute cap", async () => {
    const conn = await account("q-3h");
    const r = await markAccountUnavailable(conn.id, 429, "Individual quota reached. Resets in 3h", "antigravity", "gemini-3.8-flash-high", Date.now() + 3 * 3600 * 1000);
    assert.equal(r.shouldFallback, true);
    assert.ok(r.cooldownMs > 2.9 * 3600 * 1000, `cooldown must be ~3h, got ${r.cooldownMs}`);
    assert.ok(r.cooldownMs <= 3 * 3600 * 1000);
    const saved = await repo.getProviderConnectionById(conn.id);
    const lm = lockMs(saved);
    assert.ok(lm > 2.9 * 3600 * 1000 && lm <= 3 * 3600 * 1000, `DB lock must be ~3h, got ${lm}ms`);
    assert.ok(!logs.some(l => l[0] === "warn" && /clamp/i.test(l[1] || "")), "no clamp warning for a trusted reset");
  });

  it("AG 429 with 5h window (typical) locks full window", async () => {
    const conn = await account("q-5h");
    const r = await markAccountUnavailable(conn.id, 429, "quota reset", "antigravity", "gemini-3.8-flash-high", Date.now() + 5 * 3600 * 1000);
    assert.ok(r.cooldownMs > 4.9 * 3600 * 1000);
  });

  it("absurd far-future AG reset (30d) is clamped to the generic cap and warns", async () => {
    const conn = await account("q-30d");
    // markAccountUnavailable logs through the module-level logger (console.warn),
    // not the caller's log object — capture the real sink.
    const warnings = [];
    const original = console.warn;
    console.warn = (...args) => warnings.push(args.join(" "));
    let r;
    try {
      r = await markAccountUnavailable(conn.id, 429, "weird body", "antigravity", "gemini-3.8-flash-high", Date.now() + 30 * 24 * 3600 * 1000);
    } finally { console.warn = original; }
    assert.equal(r.cooldownMs, MAX_RATE_LIMIT_COOLDOWN_MS, "bogus reset must not sleep 30 days");
    assert.ok(warnings.some(w => /clamp|exceed/i.test(w)), "must warn about clamping");
  });

  it("past reset falls back to generic backoff (no negative lock, no instant re-probe)", async () => {
    const conn = await account("q-past");
    const r = await markAccountUnavailable(conn.id, 429, "stale reset", "antigravity", "gemini-3.8-flash-high", Date.now() - 5000);
    assert.equal(r.shouldFallback, true);
    assert.ok(r.cooldownMs > 0, "backoff cooldown must be positive");
    const saved = await repo.getProviderConnectionById(conn.id);
    assert.ok(new Date(saved[LOCK]).getTime() > Date.now(), "lock must be in the future");
  });

  it("non-AG providers keep the 30-minute cap (baseline preserved)", async () => {
    const conn = repo.createProviderConnection;
    void conn;
    const codex = await repo.createProviderConnection({ provider: "codex", authType: "oauth", name: "cx",
      email: "cx@example.invalid", accessToken: "t", refreshToken: "r", isActive: true });
    const r = await markAccountUnavailable(codex.id, 429, "usage_limit_reached", "codex", "gpt-5.5", Date.now() + 3 * 3600 * 1000);
    assert.equal(r.cooldownMs, MAX_RATE_LIMIT_COOLDOWN_MS, "codex long reset stays capped as before");
  });
});
