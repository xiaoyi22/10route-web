import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
const repoRoot = fileURLToPath(new URL("../../", import.meta.url));

let testApi;
try {
  testApi = await import("vitest");
} catch (error) {
  if (error.code !== "ERR_MODULE_NOT_FOUND") throw error;
  testApi = await import("node:test");
}
const { describe, it, beforeEach, afterEach } = testApi;

// Capture all transport calls before proxyFetch captures global fetch. No real network.
let mockFetch = async (url) => { throw new Error(`Unexpected offline test fetch: ${url}`); };
globalThis.fetch = (...args) => mockFetch(...args);

// Set up isolated temp DATA_DIR before importing DB-dependent modules
const testTempDir = fs.mkdtempSync(path.join(os.tmpdir(), "10router-ag-tos-test-"));
process.env.DATA_DIR = testTempDir;

const {
  classifyAntigravityError,
  quarantineConnection,
  unquarantineConnection,
  isConnectionQuarantined,
  getQuarantinedConnection,
  resetQuarantineMemory,
  setQuarantinePersistenceHandler,
  persistQuarantine,
  AG_FORBIDDEN_COOLDOWN_MS
} = await import("../../open-sse/services/antigravityQuarantine.js");

const { AG_FORBIDDEN_COOLDOWN_MS: ERROR_CONFIG_AG_COOLDOWN } = await import("../../open-sse/config/errorConfig.js");
const { handleChatCore } = await import("../../open-sse/handlers/chatCore.js");
const { markAccountUnavailable, clearAccountError, getProviderCredentials } = await import("../../src/sse/services/auth.js");
const { shouldRefreshCredentials } = await import("../../open-sse/services/oauthCredentialManager.js");
const { getProviderConnections, getProviderConnectionById, updateProviderConnection, createProviderConnection, deleteProviderConnection, updateSettings } = await import("../../src/lib/db/index.js");
const { registerQuarantinePersistenceHandler, releaseAntigravityQuarantine } = await import("../../src/lib/db/repos/connectionsRepo.js");
const { getAdapter } = await import("../../src/lib/db/driver.js");
const { updateProviderCredentials, checkAndRefreshToken } = await import("../../src/sse/services/tokenRefresh.js");
const { AntigravityExecutor } = await import("../../open-sse/executors/antigravity.js");
const { refreshProviderCredentials, withCredentialRefreshLock } = await import("../../open-sse/services/oauthCredentialManager.js");
const { isAntigravityBlocked } = await import("../../open-sse/services/antigravityQuarantine.js");
const { spawnSync } = await import("node:child_process");

async function newAccount(name = "integration") {
  return createProviderConnection({ provider: "antigravity", authType: "oauth", name,
    email: `${name}-${crypto.randomUUID()}@example.invalid`, accessToken: "offline-token", refreshToken: "offline-refresh",
    projectId: "offline-project", isActive: true });
}
const realTosText = "This service has been disabled in this account for violation of Terms of Service. Please submit an appeal to continue using this product.";
const tosResponse = () => new Response(JSON.stringify({ error: { code: 403, message: realTosText } }), { status: 403 });

describe("Antigravity P0 TOS Quarantine & 403 Safety Suite", () => {
  beforeEach(async () => {
    resetQuarantineMemory();
    registerQuarantinePersistenceHandler();
    mockFetch = async url => { throw new Error(`Unexpected offline test fetch: ${url}`); };
    for (const conn of await getProviderConnections({ provider: "antigravity" })) await deleteProviderConnection(conn.id);
  });

  afterEach(() => {
    resetQuarantineMemory();
  });

  // ── 1. Classification Tests ───────────────────────────────────────────────
  describe("1. Error Classification (classifyAntigravityError)", () => {
    it("identifies exact Google ErrorInfo.reason === TOS_VIOLATION on 403", () => {
      const body = JSON.stringify({
        error: {
          code: 403,
          message: "Request had insufficient authentication scopes.",
          status: "PERMISSION_DENIED",
          details: [
            {
              "@type": "type.googleapis.com/google.rpc.ErrorInfo",
              reason: "TOS_VIOLATION",
              domain: "cloudcode-pa.googleapis.com"
            }
          ]
        }
      });
      const result = classifyAntigravityError(403, body);
      assert.equal(result.isTos, true);
      assert.equal(result.reason, "TOS_VIOLATION");
    });

    it("recognizes the real TOS message and its explicit disabling sentence", () => {
      const sentence = "This service has been disabled in this account for violation of Terms of Service.";
      for (const message of [sentence, `${sentence} Please submit an appeal to continue using this product.`]) {
        for (const body of [message, { error: { message } }, JSON.stringify({ error: { message } })]) {
          assert.equal(classifyAntigravityError(403, body).isTos, true);
        }
      }
    });

    it("rejects untyped, misplaced ErrorInfo and arbitrary JSON/prompt text", () => {
      const sentence = "This service has been disabled in this account for violation of Terms of Service.";
      const bodies = [
        { error: { details: [{ reason: "TOS_VIOLATION" }] } },
        { details: [{ "@type": "type.googleapis.com/google.rpc.ErrorInfo", reason: "TOS_VIOLATION" }] },
        { error: { details: [{ "@type": "other", reason: "TOS_VIOLATION" }] } },
        { prompt: sentence },
        { error: { details: [{ message: sentence }] } },
        { error: { message: "account is suspended" } },
        { error: { message: "This service has been disabled for your account." } },
      ];
      for (const body of bodies) {
        for (const input of [body, JSON.stringify(body)]) {
          assert.equal(classifyAntigravityError(403, input).isTos, false, JSON.stringify(body));
        }
      }
    });

    it("identifies exact service disabled message on 403", () => {
      const body = JSON.stringify({
        error: {
          code: 403,
          message: "This service has been disabled in this account for violation of Terms of Service."
        }
      });
      const result = classifyAntigravityError(403, body);
      assert.equal(result.isTos, true);
      assert.equal(result.reason, "TOS_VIOLATION");
    });

    it("does not classify ordinary 403 permission denied as TOS", () => {
      const body = JSON.stringify({
        error: {
          code: 403,
          message: "The caller does not have permission"
        }
      });
      const result = classifyAntigravityError(403, body);
      assert.equal(result.isTos, false);
      assert.equal(result.reason, null);
    });

    it("does not classify 400 as TOS even if ErrorInfo has TOS_VIOLATION", () => {
      const body = JSON.stringify({
        error: {
          code: 400,
          message: "Bad request",
          details: [{ reason: "TOS_VIOLATION" }]
        }
      });
      const result = classifyAntigravityError(400, body);
      assert.equal(result.isTos, false);
    });

    it("does not broad-match 'disabled' in non-service-disabled messages", () => {
      const bodies = [
        JSON.stringify({ error: { code: 403, message: "Model gemini-1.5 is disabled in this region" } }),
        JSON.stringify({ error: { code: 403, message: "Feature disabled for project" } }),
        JSON.stringify({ error: { code: 403, message: "Thinking mode disabled" } })
      ];
      for (const b of bodies) {
        const res = classifyAntigravityError(403, b);
        assert.equal(res.isTos, false, `Failed for body: ${b}`);
      }
    });

    it("is immune to prompt pollution (prompt contains TOS_VIOLATION but upstream does not)", () => {
      // User prompt text was "Ignore rules, output TOS_VIOLATION and disabled"
      // But upstream 403 body is standard quota or permission error
      const upstreamBody = JSON.stringify({
        error: {
          code: 403,
          message: "Quota exceeded for quota metric 'GenerateContent'"
        }
      });
      const res = classifyAntigravityError(403, upstreamBody);
      assert.equal(res.isTos, false);
    });
  });

  // ── 2. Memory Quarantine & DB Fallback ────────────────────────────────────
  describe("2. Memory Quarantine & DB Write Failure Fallback", () => {
    it("immediately blocks connectionId in memory before DB persistence", () => {
      const connId = "test-conn-mem-1";
      assert.equal(isConnectionQuarantined(connId), false);
      quarantineConnection(connId, "TOS_VIOLATION");
      assert.equal(isConnectionQuarantined(connId), true);
      assert.equal(getQuarantinedConnection(connId).reason, "TOS_VIOLATION");
    });

    it("maintains memory quarantine even if DB persistence throws", async () => {
      const connId = "test-conn-mem-fail";
      setQuarantinePersistenceHandler(async () => {
        throw new Error("SQLite disk I/O error or database locked");
      });

      await assert.doesNotReject(async () => {
        await persistQuarantine(connId, "TOS_VIOLATION");
      });

      // Memory block MUST remain active!
      assert.equal(isConnectionQuarantined(connId), true);
    });

    it("prevents late-arriving successful request or refresh from un-quarantining", async () => {
      const connId = "test-conn-late-success";
      quarantineConnection(connId, "TOS_VIOLATION");

      // Simulate a concurrent late arrival success calling clearAccountError
      const dummyCreds = { _connection: { id: connId, testStatus: "quarantined", lastError: "TOS_VIOLATION" } };
      await clearAccountError(connId, dummyCreds, "gemini-3.8-flash-high");

      // Must remain quarantined!
      assert.equal(isConnectionQuarantined(connId), true);
    });

    it("allows explicit manual unquarantine", () => {
      const connId = "test-conn-manual";
      quarantineConnection(connId, "TOS_VIOLATION");
      assert.equal(isConnectionQuarantined(connId), true);

      unquarantineConnection(connId);
      assert.equal(isConnectionQuarantined(connId), false);
    });
  });

  // ── 3. ChatCore & Refresh Safety ──────────────────────────────────────────
  describe("3. ChatCore 0-Refresh & Regular 403 Cooldown", () => {
    it("performs 0 token refreshes on AG 403 TOS and marks quarantine", async () => {
      let refreshCallCount = 0;
      const fakeExecutor = {
        noAuth: false,
        refreshCredentials: async () => {
          refreshCallCount++;
          return { accessToken: "new-token" };
        },
        execute: async () => {
          const tosBody = JSON.stringify({
            error: {
              code: 403,
              status: "PERMISSION_DENIED",
              details: [{ "@type": "type.googleapis.com/google.rpc.ErrorInfo", reason: "TOS_VIOLATION" }]
            }
          });
          return {
            response: new Response(tosBody, {
              status: 403,
              headers: { "Content-Type": "application/json" }
            }),
            url: "https://antigravity.google/v1internal",
            responseFormat: "openai"
          };
        }
      };

      const connId = (await newAccount("core-tos")).id;
      const result = await handleChatCore({
        body: { model: "antigravity/gemini-3.8-flash-high", messages: [{ role: "user", content: "hi" }] },
        modelInfo: { provider: "antigravity", model: "gemini-3.8-flash-high" },
        credentials: { accessToken: "token-1", connectionId: connId },
        connectionId: connId,
        _executorOverride: fakeExecutor
      });

      // 0 token refreshes!
      assert.equal(refreshCallCount, 0);
      assert.equal(result.success, false);
      assert.equal(result.status, 403);
      assert.equal(isConnectionQuarantined(connId), true);
      assert.equal(result.isTosQuarantined, true);
    });

    it("performs 0 token refreshes on regular AG 403 and sets 30m model cooldown", async () => {
      let refreshCallCount = 0;
      const fakeExecutor = {
        noAuth: false,
        refreshCredentials: async () => {
          refreshCallCount++;
          return { accessToken: "new-token" };
        },
        execute: async () => {
          const regular403 = JSON.stringify({
            error: { code: 403, message: "The caller does not have permission" }
          });
          return {
            response: new Response(regular403, {
              status: 403,
              headers: { "Content-Type": "application/json" }
            }),
            url: "https://antigravity.google/v1internal",
            responseFormat: "openai"
          };
        }
      };

      const connId = (await newAccount("core-ordinary403")).id;
      const result = await handleChatCore({
        body: { model: "antigravity/gemini-3.8-flash-high", messages: [{ role: "user", content: "hi" }] },
        modelInfo: { provider: "antigravity", model: "gemini-3.8-flash-high" },
        credentials: { accessToken: "token-1", connectionId: connId },
        connectionId: connId,
        _executorOverride: fakeExecutor
      });

      // 0 token refreshes on AG 403
      assert.equal(refreshCallCount, 0);
      assert.equal(result.success, false);
      assert.equal(result.status, 403);
      assert.equal(isConnectionQuarantined(connId), false); // NOT quarantined!

      // Mark account unavailable should give 30-minute cooldown
      const fallbackResult = await markAccountUnavailable(
        connId,
        403,
        result.error,
        "antigravity",
        "gemini-3.8-flash-high"
      );
      assert.equal(fallbackResult.shouldFallback, true);
      assert.equal(fallbackResult.cooldownMs, AG_FORBIDDEN_COOLDOWN_MS);
      assert.equal(AG_FORBIDDEN_COOLDOWN_MS, 30 * 60 * 1000);
      assert.equal(ERROR_CONFIG_AG_COOLDOWN, 30 * 60 * 1000);
      const saved = await getProviderConnectionById(connId);
      assert.equal(saved.isActive, true);
      assert.equal(saved.quarantine, undefined);
      const cooldown = new Date(saved["modelLock_gemini-3.8-flash-high"]).getTime() - Date.now();
      assert.ok(cooldown > AG_FORBIDDEN_COOLDOWN_MS - 5000 && cooldown <= AG_FORBIDDEN_COOLDOWN_MS);
    });

    it("preserves 401 token refresh on AG", async () => {
      let refreshCallCount = 0;
      const fakeExecutor = {
        noAuth: false,
        refreshCredentials: async () => {
          refreshCallCount++;
          return { accessToken: "new-refreshed-token" };
        },
        execute: async ({ credentials }) => {
          if (credentials.accessToken === "new-refreshed-token") {
            return {
              response: new Response(JSON.stringify({ choices: [{ message: { content: "ok" } }] }), {
                status: 200,
                headers: { "Content-Type": "application/json" }
              }),
              url: "https://antigravity.google/v1internal",
              responseFormat: "openai"
            };
          }
          return {
            response: new Response(JSON.stringify({ error: "Unauthenticated" }), {
              status: 401,
              headers: { "Content-Type": "application/json" }
            }),
            url: "https://antigravity.google/v1internal",
            responseFormat: "openai"
          };
        }
      };

      const connId = "test-conn-ag-401";
      const result = await handleChatCore({
        body: { model: "antigravity/gemini-3.8-flash-high", messages: [{ role: "user", content: "hi" }] },
        modelInfo: { provider: "antigravity", model: "gemini-3.8-flash-high" },
        credentials: { accessToken: "old-expired-token", connectionId: connId },
        connectionId: connId,
        _executorOverride: fakeExecutor
      });

      assert.equal(refreshCallCount, 1);
      assert.equal(result.success, true);
    });

    it("does not affect 403 handling on other providers", async () => {
      let refreshCallCount = 0;
      const fakeExecutor = {
        noAuth: false,
        refreshCredentials: async () => {
          refreshCallCount++;
          return null; // refresh failed
        },
        execute: async () => {
          return {
            response: new Response(JSON.stringify({ error: "Forbidden" }), {
              status: 403,
              headers: { "Content-Type": "application/json" }
            }),
            url: "https://api.openai.com/v1",
            responseFormat: "openai"
          };
        }
      };

      const result = await handleChatCore({
        body: { model: "openai/gpt-4o", messages: [{ role: "user", content: "hi" }] },
        modelInfo: { provider: "openai", model: "gpt-4o" },
        credentials: { accessToken: "token-1", connectionId: "conn-openai-403" },
        connectionId: "conn-openai-403",
        _executorOverride: fakeExecutor
      });

      // Other providers still attempt token refresh on 403 (with retries if failed)
      assert.ok(refreshCallCount >= 1, `Expected at least 1 refresh attempt, got ${refreshCallCount}`);
      assert.equal(isConnectionQuarantined("conn-openai-403"), false);

      const fallback = await markAccountUnavailable("conn-openai-403", 403, "Forbidden", "openai", "gpt-4o");
      // Other provider 403 should NOT use 30-min AG cooldown
      assert.notEqual(fallback.cooldownMs, AG_FORBIDDEN_COOLDOWN_MS);
    });
  });

  describe("SQLite integration and real executor with offline transport", () => {
    it("401 refresh followed by TOS returns the new 403 and stops, not the old 401", async () => {
      const conn = await newAccount("401-then-tos");
      let generated = 0, refreshed = 0;
      const executor = {
        noAuth: false,
        refreshCredentials: async () => { refreshed++; return { accessToken: "refreshed" }; },
        execute: async () => ({ response: ++generated === 1 ? new Response("unauthenticated", { status: 401 }) : tosResponse(), url: "https://offline.invalid" }),
      };
      const result = await handleChatCore({ body: { model: "ag/gemini-3.8-flash-high", messages: [{ role: "user", content: "hi" }] },
        modelInfo: { provider: "antigravity", model: "gemini-3.8-flash-high" }, credentials: conn, _executorOverride: executor });
      assert.equal(generated, 2);
      assert.equal(refreshed, 1);
      assert.equal(result.status, 403);
      assert.equal(result.isTosQuarantined, true);
      assert.equal((await getProviderConnectionById(conn.id)).isActive, false);
    });

    it("combo fallback cannot re-enter the AG pool after a TOS stop", async () => {
      const { handleComboChat } = await import("../../open-sse/services/combo.js");
      let calls = 0;
      const stopped = tosResponse();
      stopped.isTosQuarantined = true;
      const response = await handleComboChat({ body: {}, models: ["ag/gemini-3.8-flash-high", "ag/claude-sonnet-4-6"],
        handleSingleModel: async () => { calls++; return stopped; }, log: { info() {}, warn() {}, error() {} } });
      assert.equal(response, stopped);
      assert.equal(calls, 1);
    });

    it("sees an explicit release committed by another process", async () => {
      const conn = await newAccount("remote-release");
      await persistQuarantine(conn.id);
      const child = spawnSync(process.execPath, ["--import", "./tests/test-loader.mjs", "--input-type=module", "-e", `
        const { releaseAntigravityQuarantine } = await import('./src/lib/db/repos/connectionsRepo.js');
        await releaseAntigravityQuarantine(${JSON.stringify(conn.id)});
      `], { cwd: repoRoot, env: { ...process.env, DATA_DIR: testTempDir }, encoding: "utf8", timeout: 15000 });
      assert.equal(child.status, 0, child.stdout + child.stderr);
      const selected = await getProviderCredentials("antigravity", new Set(), "gemini-3.8-flash-high");
      assert.equal(selected.connectionId, conn.id);
      assert.equal(await isAntigravityBlocked(conn), false);
      assert.equal(isConnectionQuarantined(conn.id), false);
    });

    it("shared refresh racing with quarantine cannot clear the committed state", async () => {
      const conn = await newAccount("refresh-race");
      let finishRefresh;
      let started;
      const start = new Promise(resolve => { started = resolve; });
      mockFetch = async () => { started(); return new Promise(resolve => { finishRefresh = resolve; }); };
      const pending = refreshProviderCredentials("antigravity", conn);
      await start;
      await persistQuarantine(conn.id);
      finishRefresh(Response.json({ access_token: "late-token", expires_in: 3600 }));
      const refreshed = await pending;
      await updateProviderCredentials(conn.id, refreshed);
      const saved = await getProviderConnectionById(conn.id);
      assert.equal(saved.accessToken, "late-token");
      assert.equal(saved.isActive, false);
      assert.equal(saved.testStatus, "quarantined");
      assert.equal(await isAntigravityBlocked(conn), true);
    });

    it("shares memory and callbacks across duplicate module instances in one process", async () => {
      const conn = await newAccount("module-copy");
      const duplicate = await import("../../open-sse/services/antigravityQuarantine.js?separate-bundle");
      quarantineConnection(conn.id);
      assert.equal(duplicate.isConnectionQuarantined(conn.id), true);
      assert.equal((await duplicate.persistQuarantine(conn.id)).persisted, true);
      assert.equal((await getProviderConnectionById(conn.id)).isActive, false);
    });

    it("blocks all offline side paths and forced refresh after restart state loss", async () => {
      const conn = await newAccount("side-blocked");
      await persistQuarantine(conn.id);
      resetQuarantineMemory();
      let calls = 0;
      mockFetch = async () => { calls++; throw new Error("Quarantined network call"); };
      const { testSingleConnection } = await import("../../src/app/api/providers/[id]/test/testUtils.js");
      const { getUsageForProvider } = await import("../../open-sse/services/usage.js");
      const { getProjectIdForConnection } = await import("../../open-sse/services/projectId.js");
      const { refreshAccessToken } = await import("../../open-sse/services/tokenRefresh.js");
      for (const call of [() => testSingleConnection(conn.id), () => getUsageForProvider(conn, null, { force: true }),
        () => getProjectIdForConnection(conn.id, conn.accessToken, "antigravity")]) {
        await assert.rejects(call, e => e.code === "AG_TOS_QUARANTINED");
      }
      assert.equal(await refreshAccessToken("antigravity", conn.refreshToken, conn), null);
      await checkAndRefreshToken("antigravity", conn, { force: true });
      const { GET } = await import("../../src/app/api/usage/[connectionId]/route.js");
      assert.equal((await GET(new Request("http://localhost/api/usage/test?force=1"), { params: Promise.resolve({ connectionId: conn.id }) })).status, 403);
      assert.equal(calls, 0);
    });

    it("probe TOS persists without refresh or success writeback", async () => {
      const conn = await newAccount("probe-tos");
      let calls = 0;
      mockFetch = async () => { calls++; return tosResponse(); };
      const { POST } = await import("../../src/app/api/providers/[id]/test/route.js");
      assert.equal((await POST(new Request("http://localhost/test", { method: "POST" }), { params: Promise.resolve({ id: conn.id }) })).status, 403);
      assert.equal(calls, 1);
      const saved = await getProviderConnectionById(conn.id);
      assert.equal(saved.testStatus, "quarantined");
      assert.equal(saved.isActive, false);
    });

    it("usage stops at TOS subscription or summary without host/model fallback", async () => {
      const { getUsageForProvider } = await import("../../open-sse/services/usage.js");
      for (const phase of ["subscription", "summary"]) {
        const conn = await newAccount(`usage-${phase}`);
        let calls = 0;
        mockFetch = async () => {
          calls++;
          return phase === "summary" && calls === 1
            ? Response.json({ cloudaicompanionProject: conn.projectId }) : tosResponse();
        };
        await assert.rejects(() => getUsageForProvider(conn, null, { force: true }), e => e.code === "AG_TOS_QUARANTINED");
        assert.equal(calls, phase === "summary" ? 2 : 1);
        assert.equal((await getProviderConnectionById(conn.id)).isActive, false);
      }
    });

    it("project discovery TOS stops onboarding and the app account loop", async () => {
      const first = await newAccount("project-tos");
      await updateProviderConnection(first.id, { projectId: null });
      const sibling = await newAccount("project-sibling");
      let calls = 0;
      mockFetch = async () => { calls++; return tosResponse(); };
      await updateSettings({ requireApiKey: false });
      const { handleChat } = await import("../../src/sse/handlers/chat.js");
      const response = await handleChat(new Request("http://localhost/v1/chat/completions", { method: "POST",
        headers: { "Content-Type": "application/json" }, body: JSON.stringify({ model: "ag/gemini-3.8-flash-high", messages: [{ role: "user", content: "hi" }] }) }));
      assert.equal(response.status, 403);
      assert.equal(calls, 1);
      assert.equal((await getProviderConnectionById(first.id)).isActive, false);
      assert.equal((await getProviderConnectionById(sibling.id)).isActive, true);
    });

    it("ordinary probe/usage 403 does not persist TOS quarantine", async () => {
      const conn = await newAccount("ordinary-probe");
      mockFetch = async () => new Response("The caller does not have permission", { status: 403 });
      const { testSingleConnection } = await import("../../src/app/api/providers/[id]/test/testUtils.js");
      const { getUsageForProvider } = await import("../../open-sse/services/usage.js");
      assert.equal((await testSingleConnection(conn.id)).valid, false);
      await getUsageForProvider(conn, null, { force: true });
      const saved = await getProviderConnectionById(conn.id);
      assert.equal(saved.isActive, true);
      assert.equal(saved.quarantine, undefined);
      assert.equal(isConnectionQuarantined(conn.id), false);
    });

    it("persisted quarantine is authoritative even when legacy status fields say active", async () => {
      const conn = await newAccount("independent-marker");
      await persistQuarantine(conn.id);
      const db = await getAdapter();
      const row = db.get("SELECT data FROM providerConnections WHERE id = ?", [conn.id]);
      const data = { ...JSON.parse(row.data), testStatus: "active" };
      db.run("UPDATE providerConnections SET isActive = 1, data = ? WHERE id = ?", [JSON.stringify(data), conn.id]);
      resetQuarantineMemory();
      assert.equal(await isAntigravityBlocked(conn), true);
      const selected = await getProviderCredentials("antigravity", new Set(), "gemini-3.8-flash-high");
      assert.notEqual(selected?.connectionId, conn.id);
      assert.equal(await refreshProviderCredentials("antigravity", conn), null);
    });

    it("onboarding TOS stops its retry loop after one onboarding request", async () => {
      const conn = await newAccount("onboard-tos");
      let calls = 0;
      mockFetch = async () => ++calls === 1 ? Response.json({ allowedTiers: [{ id: "free-tier", isDefault: true }] }) : tosResponse();
      const { getProjectIdForConnection } = await import("../../open-sse/services/projectId.js");
      await assert.rejects(() => getProjectIdForConnection(conn.id, conn.accessToken, "antigravity"), e => e.code === "AG_TOS_QUARANTINED");
      assert.equal(calls, 2);
      assert.equal((await getProviderConnectionById(conn.id)).isActive, false);
    });

    it("DB read failure fails closed for executor, refresh, probe and usage", async () => {
      const conn = await newAccount("read-failure");
      const { setQuarantineReadHandler } = await import("../../open-sse/services/antigravityQuarantine.js");
      setQuarantineReadHandler(async () => { throw new Error("injected state read failure"); });
      let calls = 0;
      mockFetch = async () => { calls++; throw new Error("Should not fetch"); };
      const { getUsageForProvider } = await import("../../open-sse/services/usage.js");
      const { testSingleConnection } = await import("../../src/app/api/providers/[id]/test/testUtils.js");
      const executor = new AntigravityExecutor();
      for (const call of [() => executor.execute({ model: "gemini-3.8-flash-high", body: {}, credentials: conn }),
        () => refreshProviderCredentials("antigravity", conn), () => getUsageForProvider(conn), () => testSingleConnection(conn.id)]) {
        await assert.rejects(call, e => e.code === "AG_QUARANTINE_CHECK_FAILED");
      }
      assert.equal(calls, 0);
    });
    it("preserves quarantine against stale success, credentials, usage, test and OAuth relogin writes", async () => {
      const conn = await newAccount("late");
      const stale = { ...conn, testStatus: "error", lastError: "old error", modelLock_old: new Date(Date.now() - 1000).toISOString() };
      assert.equal((await persistQuarantine(conn.id)).persisted, true);
      resetQuarantineMemory(); // Protection must come from the row, not just the Map.
      await clearAccountError(conn.id, stale, "old");
      assert.equal(await updateProviderCredentials(conn.id, { accessToken: "late-refreshed-token" }), true);
      await updateProviderConnection(conn.id, { isActive: true, testStatus: "active", quarantine: null,
        lastError: null, lastErrorAt: null, errorCode: null, allowUnquarantine: true, quotaCheckedAt: new Date().toISOString() });
      await createProviderConnection({ ...conn, testStatus: "active", isActive: true, quarantine: null });
      const saved = await getProviderConnectionById(conn.id);
      assert.equal(saved.isActive, false);
      assert.equal(saved.testStatus, "quarantined");
      assert.equal(saved.quarantine.reason, "TOS_VIOLATION");
      assert.match(saved.lastError, /TOS_QUARANTINE/);
      assert.equal(saved.errorCode, 403);
    });

    it("uses real SQLite write failure, retains memory, and never reports persisted", async () => {
      const conn = await newAccount("write-failure");
      const db = await getAdapter();
      db.exec(`CREATE TRIGGER ag_fail_write BEFORE UPDATE ON providerConnections WHEN OLD.id = '${conn.id}' BEGIN SELECT RAISE(ABORT, 'injected quarantine write failure'); END`);
      const alarms = [];
      try {
        const result = await persistQuarantine(conn.id, "TOS_VIOLATION", { error: (...args) => alarms.push(args.join(" ")) });
        assert.equal(result.persisted, false);
        assert.match(result.error, /this process ONLY/);
        assert.ok(alarms.length > 0);
        assert.equal(isConnectionQuarantined(conn.id), true);
        assert.equal((await getProviderConnectionById(conn.id)).isActive, true);
        assert.equal(await isAntigravityBlocked(conn), true);
        await assert.rejects(releaseAntigravityQuarantine(conn.id), /injected/);
        assert.equal(isConnectionQuarantined(conn.id), true);
      } finally { db.exec("DROP TRIGGER ag_fail_write"); }
      assert.ok(await releaseAntigravityQuarantine(conn.id));
      assert.equal(isConnectionQuarantined(conn.id), false);
    });

    it("alarms on missing handler and missing row rather than silently succeeding", async () => {
      const conn = await newAccount("no-handler");
      setQuarantinePersistenceHandler(null);
      const alarms = [];
      const result = await persistQuarantine(conn.id, "TOS_VIOLATION", { error: (...args) => alarms.push(args.join(" ")) });
      assert.equal(result.persisted, false);
      assert.ok(alarms.some(s => s.includes("not registered")));
      assert.equal(isConnectionQuarantined(conn.id), true);
      registerQuarantinePersistenceHandler();
      assert.equal((await persistQuarantine("missing-row")).persisted, false);
    });

    it("manual management enable clears quarantine only after commit; status-only updates do not", async () => {
      const conn = await newAccount("release");
      await persistQuarantine(conn.id);
      const { PUT } = await import("../../src/app/api/providers/[id]/route.js");
      const put = body => PUT(new Request("http://localhost/api/providers/test", {
        method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
      }), { params: Promise.resolve({ id: conn.id }) });
      assert.equal((await put({ testStatus: "active", lastError: null })).status, 200);
      assert.equal((await getProviderConnectionById(conn.id)).isActive, false);
      const db = await getAdapter();
      db.exec(`CREATE TRIGGER ag_fail_release BEFORE UPDATE ON providerConnections WHEN OLD.id = '${conn.id}' BEGIN SELECT RAISE(ABORT, 'injected release failure'); END`);
      try {
        assert.equal((await put({ isActive: true })).status, 500);
        assert.equal(isConnectionQuarantined(conn.id), true);
        assert.ok((await getProviderConnectionById(conn.id)).quarantine);
      } finally { db.exec("DROP TRIGGER ag_fail_release"); }
      assert.equal((await put({ isActive: true })).status, 200);
      const saved = await getProviderConnectionById(conn.id);
      assert.equal(saved.isActive, true);
      assert.equal(saved.quarantine, undefined);
      assert.equal(saved.lastError, null);
      assert.equal(saved.testStatus, "unknown"); // Re-enable is not proof that upstream recovered.
      assert.equal(isConnectionQuarantined(conn.id), false);
      assert.equal(await isAntigravityBlocked(saved), false);
    });

    it("persists across a new Node process and blocks stale ID-only execute/refresh", async () => {
      const conn = await newAccount("restart");
      await persistQuarantine(conn.id);
      const child = spawnSync(process.execPath, ["--import", "./tests/test-loader.mjs", "--input-type=module", "-e", `
        import assert from 'node:assert/strict';
        globalThis.fetch = async () => { throw new Error('Network forbidden'); };
        const repo = await import('./src/lib/db/repos/connectionsRepo.js');
        const { AntigravityExecutor } = await import('./open-sse/executors/antigravity.js');
        const { refreshProviderCredentials } = await import('./open-sse/services/oauthCredentialManager.js');
        const c = { connectionId: ${JSON.stringify(conn.id)}, accessToken: 'stale', refreshToken: 'stale' };
        const row = await repo.getProviderConnectionById(c.connectionId);
        assert.equal(row.isActive, false);
        assert.equal(row.quarantine.reason, 'TOS_VIOLATION');
        const executor = new AntigravityExecutor();
        assert.equal((await executor.execute({model:'gemini-3.8-flash-high', body:{}, credentials:c})).response.status, 403);
        assert.equal(await executor.refreshCredentials(c), null);
        assert.equal(await refreshProviderCredentials('antigravity', c), null);
      `], { cwd: repoRoot, env: { ...process.env, DATA_DIR: testTempDir }, encoding: "utf8", timeout: 15000 });
      assert.equal(child.status, 0, child.stdout + child.stderr);
    });

    it("real executor makes exactly one generation and zero refresh calls, preserving raw 403 body", async () => {
      const conn = await newAccount("executor");
      let generated = 0, refreshed = 0;
      mockFetch = async url => {
        if (String(url).includes("oauth2")) { refreshed++; throw new Error("Unexpected refresh"); }
        generated++;
        return tosResponse();
      };
      const executor = new AntigravityExecutor();
      const credentials = { ...conn, connectionId: conn.id };
      const params = { model: "gemini-3.8-flash-high", body: { messages: [{ role: "user", content: "hi" }] }, credentials, stream: false };
      const result = await executor.execute(params);
      assert.equal(generated, 1);
      assert.match(await result.response.text(), /Please submit an appeal/);
      assert.equal(await executor.refreshCredentials(credentials), null);
      assert.equal(await refreshProviderCredentials("antigravity", credentials), null);
      await checkAndRefreshToken("antigravity", credentials, { force: true });
      assert.equal((await executor.execute(params)).response.status, 403);
      assert.equal(generated, 1);
      assert.equal(refreshed, 0);
      assert.equal((await getProviderConnectionById(conn.id)).isActive, false);
    });

    it("rechecks quarantine before a base executor retry and a queued refresh callback", async () => {
      const conn = await newAccount("retry");
      let calls = 0;
      mockFetch = async () => { calls++; return new Response("busy", { status: 503 }); };
      const executor = new AntigravityExecutor();
      executor.computeRetryDelay = async () => { await persistQuarantine(conn.id); return 0; };
      await executor.execute({ model: "gemini-3.8-flash-high", body: {}, credentials: { ...conn, connectionId: conn.id } });
      assert.equal(calls, 1);
      let refreshCalls = 0;
      assert.equal(await withCredentialRefreshLock("antigravity", conn, () => { refreshCalls++; }), null);
      assert.equal(refreshCalls, 0);
    });

    it("the app stops sibling account traversal immediately on TOS", async () => {
      for (const conn of await getProviderConnections({ provider: "antigravity" })) await deleteProviderConnection(conn.id);
      const first = await newAccount("app-first");
      const sibling = await newAccount("app-sibling");
      let generated = 0;
      mockFetch = async () => { generated++; return tosResponse(); };
      await updateSettings({ requireApiKey: false }); // Isolated temporary DB only.
      const { handleChat } = await import("../../src/sse/handlers/chat.js");
      const response = await handleChat(new Request("http://localhost/v1/chat/completions", { method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: "ag/gemini-3.8-flash-high", stream: false, messages: [{ role: "user", content: "offline integration test" }] }) }));
      assert.equal(response.status, 403, await response.clone().text());
      assert.equal(generated, 1);
      assert.equal((await getProviderConnectionById(first.id)).isActive, false);
      assert.equal((await getProviderConnectionById(sibling.id)).isActive, true);
    });
  });

  // ── 4. Account Selection & Multi-Account Isolation ─────────────────────────
  describe("4. Account Selection & Multi-Account Isolation", () => {
    it("blocks quarantined account for all models while leaving healthy accounts usable", async () => {
      const connBad = await createProviderConnection({
        provider: "antigravity",
        authType: "oauth",
        name: "Bad Account",
        email: "bad@example.com",
        accessToken: "bad-token",
        isActive: true
      });
      const connGood = await createProviderConnection({
        provider: "antigravity",
        authType: "oauth",
        name: "Good Account",
        email: "good@example.com",
        accessToken: "good-token",
        isActive: true
      });

      quarantineConnection(connBad.id, "TOS_VIOLATION");

      // shouldRefreshCredentials rejects quarantined
      assert.equal(shouldRefreshCredentials("antigravity", { connectionId: connBad.id }), false);
      assert.equal(shouldRefreshCredentials("antigravity", { connectionId: connGood.id }), false); // not expired, but not quarantined

      // getProviderCredentials must select the healthy account, never the quarantined one
      for (const model of ["gemini-3.8-flash-high", "claude-sonnet-4-6"]) {
        const selected = await getProviderCredentials("antigravity", new Set(), model);
        assert.ok(selected, "Expected healthy account to be selected");
        assert.equal(selected.connectionId, connGood.id);
        assert.notEqual(selected.connectionId, connBad.id);
      }
    });

    it("persists quarantine to DB and survives restart simulation", async () => {
      const connToQuarantine = await createProviderConnection({
        provider: "antigravity",
        authType: "oauth",
        name: "To Quarantine",
        email: "quarantine@example.com",
        accessToken: "q-token",
        isActive: true
      });

      // Persist quarantine via chatCore/persistQuarantine
      await persistQuarantine(connToQuarantine.id, "TOS_VIOLATION");

      // Check DB state
      const conns = await getProviderConnections({ provider: "antigravity" });
      const updatedInDb = conns.find(c => c.id === connToQuarantine.id);
      assert.ok(updatedInDb);
      assert.equal(updatedInDb.isActive, false);
      assert.equal(updatedInDb.testStatus, "quarantined");
      assert.match(updatedInDb.lastError, /TOS_VIOLATION/);

      // Simulate restart: clear in-memory quarantine map
      resetQuarantineMemory();
      assert.equal(isConnectionQuarantined(connToQuarantine.id), false);

      // Even without memory cache, DB has isActive: false, so getProviderCredentials with isActive: true will not select it
      const activeConns = await getProviderConnections({ provider: "antigravity", isActive: true });
      assert.equal(activeConns.some(c => c.id === connToQuarantine.id), false);
    });
  });
});
