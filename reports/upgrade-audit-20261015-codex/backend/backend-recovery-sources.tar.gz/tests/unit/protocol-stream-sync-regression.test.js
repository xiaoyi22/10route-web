import http from "node:http";
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import { handleChatCore } from "open-sse/handlers/chatCore.js";
import { FORMATS } from "open-sse/translator/formats.js";
import { saveRequestDetail } from "@/lib/usageDb.js";

vi.mock("@/lib/usageDb.js", () => ({
  appendRequestLog: vi.fn(async () => {}), trackPendingRequest: vi.fn(),
  saveRequestDetail: vi.fn(async () => {}), saveRequestUsage: vi.fn(async () => {})
}));

const frame = data => `data: ${JSON.stringify(data)}\n\n`;
const event = (type, data) => `event: ${type}\ndata: ${JSON.stringify({ type, ...data })}\n\n`;
const chunk = (delta, finish_reason = null) => ({
  id: "chatcmpl-reaudit", object: "chat.completion.chunk", created: 1, model: "audit-model",
  choices: [{ index: 0, delta, finish_reason }]
});
const finalChat = (message, finish_reason = "stop") => ({
  id: "chatcmpl-reaudit", object: "chat.completion", model: "audit-model",
  choices: [{ index: 0, message: { role: "assistant", ...message }, finish_reason }],
  usage: { prompt_tokens: 10, completion_tokens: 2, total_tokens: 12 }
});
const responsesObject = {
  id: "resp_reaudit", object: "response", model: "audit-model", status: "completed",
  output: [{ type: "message", role: "assistant", content: [{ type: "output_text", text: "CACHE_OK" }] }],
  usage: { input_tokens: 100, input_tokens_details: { cached_tokens: 80 }, output_tokens: 10, total_tokens: 110 }
};
let upstream, gateway, upstreamUrl, gatewayUrl, fixture;
const onSuccess = vi.fn(async () => {});
const upstreamRequests = [];
const listen = async server => {
  await new Promise(resolve => server.listen(0, "127.0.0.1", resolve));
  return `http://127.0.0.1:${server.address().port}`;
};
const readJson = async request => {
  const chunks = [];
  for await (const part of request) chunks.push(part);
  return JSON.parse(Buffer.concat(chunks).toString());
};

beforeAll(async () => {
  upstream = http.createServer(async (request, response) => {
    const body = await readJson(request);
    upstreamRequests.push({ body, path: request.url });
    const finish = frame(chunk({}, "stop")) + "data: [DONE]\n\n";
    response.setHeader("content-type", "text/event-stream");
    if (fixture === "multiline") {
      response.end('data: {"id":"chatcmpl-reaudit","choices":[\n'
        + 'data: {"index":0,"delta":{"content":"MULTILINE_OK"},"finish_reason":null}]}\n\n' + finish);
    } else if (fixture === "corrupted") {
      response.end(frame(chunk({ content: "prefix" })) + 'data: {"choices":BROKEN}\n\n' + finish);
    } else if (fixture === "responses-done-only") {
      response.end(event("response.created", { response: { id: "resp_reaudit", status: "in_progress" } })
        + event("response.output_text.delta", { delta: "partial", output_index: 0 }) + "data: [DONE]\n\n");
    } else if (fixture.startsWith("tool-")) {
      const finishReason = fixture.slice(5);
      const tool = { id: "call_reaudit", type: "function", function: { name: "audit_tool", arguments: '{"x":' } };
      const incompleteResponse = {
        id: "resp_reaudit", object: "response", model: "audit-model", status: "incomplete",
        incomplete_details: { reason: "max_output_tokens" },
        output: [{ type: "function_call", call_id: tool.id, name: tool.function.name, arguments: tool.function.arguments }],
        usage: { input_tokens: 10, output_tokens: 2, total_tokens: 12 }
      };
      if (body.stream) response.end(request.url.includes("responses")
        ? event("response.incomplete", { response: incompleteResponse })
        : frame(chunk({ tool_calls: [{ ...tool, index: 0 }] })) + frame(chunk({}, "length")) + "data: [DONE]\n\n");
      else {
        response.setHeader("content-type", "application/json");
        response.end(JSON.stringify(request.url.includes("responses") ? incompleteResponse
          : finalChat({ content: null, tool_calls: [tool] }, finishReason)));
      }
    } else if (fixture.startsWith("responses-cache")) {
      const reply = fixture === "responses-cache-legacy" ? {
        ...responsesObject, usage: { input_tokens: 100, cache_read_input_tokens: 80, output_tokens: 10 }
      } : responsesObject;
      if (body.stream) response.end(event("response.completed", { response: reply }));
      else {
        response.setHeader("content-type", "application/json");
        response.end(JSON.stringify(reply));
      }
    } else if (fixture === "bad-json") {
      response.setHeader("content-type", "application/json");
      response.end("{broken");
    } else if (fixture === "error-json") {
      response.setHeader("content-type", "application/json");
      response.end(JSON.stringify({ error: { message: "upstream failed" } }));
    } else if (fixture === "empty-sse") {
      response.end();
    } else if (fixture === "wrapped-json") {
      response.setHeader("content-type", "application/json");
      response.end(JSON.stringify({ success: true, data: finalChat({ content: "WRAPPED_OK" }),
        usage: { prompt_tokens: 2000, completion_tokens: 0, total_tokens: 2000 }
      }));
    } else if (fixture === "wrapped-sse") {
      response.end(frame({ success: true, data: chunk({ content: "WRAPPED_OK" }) })
        + frame({ success: true, data: chunk({}, "stop") })
        + frame({ success: true, data: { usage: { prompt_tokens: 10, completion_tokens: 2, total_tokens: 12 } } })
        + "data: [DONE]\n\n");
    } else {
      response.end(frame(chunk({ content: "CONTROL_OK" })) + finish);
    }
  });
  upstreamUrl = await listen(upstream);
  gateway = http.createServer(async (request, response) => {
    try {
      const body = await readJson(request);
      const sourceFormatOverride = request.url === "/v1/messages" ? FORMATS.CLAUDE
        : request.url === "/v1/responses" ? FORMATS.OPENAI_RESPONSES : FORMATS.OPENAI;
      const isResponses = request.headers["x-target"] === "responses";
      const provider = isResponses ? "openai-compatible-responses-reaudit" : "openai-compatible-chat-reaudit";
      const result = await handleChatCore({
        body, modelInfo: { provider, model: "audit-model" }, sourceFormatOverride,
        credentials: { apiKey: "local-fixture", providerSpecificData: {
          baseUrl: `${upstreamUrl}/v1`, apiType: isResponses ? "responses" : "chat", forceStream: request.headers["x-force"] === "true"
        } },
        clientRawRequest: { endpoint: request.url, headers: { accept: "*/*" } },
        log: {}, userAgent: "reaudit", onRequestSuccess: onSuccess
      });
      response.writeHead(result.response.status, Object.fromEntries(result.response.headers));
      for await (const bytes of result.response.body) response.write(bytes);
      response.end();
    } catch (error) {
      if (!response.headersSent) response.writeHead(500, { "content-type": "application/json" });
      response.end(JSON.stringify({ error: error.message }));
    }
  });
  gatewayUrl = await listen(gateway);
});
afterAll(async () => {
  for (const server of [gateway, upstream]) {
    server?.closeAllConnections();
    if (server) await new Promise(resolve => server.close(resolve));
  }
});
beforeEach(() => { vi.clearAllMocks(); fixture = "control"; upstreamRequests.length = 0; });

async function call({ stream = true, source = "chat", target = "chat", force = false } = {}) {
  const path = source === "claude" ? "/v1/messages" : source === "responses" ? "/v1/responses" : "/v1/chat/completions";
  const response = await fetch(`${gatewayUrl}${path}`, {
    method: "POST", headers: { "content-type": "application/json", "x-target": target, "x-force": String(force) },
    body: JSON.stringify({ model: "audit-model", max_tokens: 30, stream,
      ...(source === "responses" ? { input: "hi" } : { messages: [{ role: "user", content: "hi" }] }) })
  });
  const result = { status: response.status, text: await response.text() };
  return result;
}

describe("streaming and synchronous HTTP regression contracts", () => {
  it("control: complete stream works", async () => {
    expect((await call()).text).toContain("CONTROL_OK");
  });
  it("control: synchronous aggregation supports valid multiline SSE", async () => {
    fixture = "multiline";
    expect((await call({ stream: false, force: true })).text).toContain("MULTILINE_OK");
  });
  it.each([
    ["wrapped-json", false, "chat"], ["wrapped-json", false, "claude"],
    ["wrapped-sse", false, "chat"], ["wrapped-sse", true, "chat"],
    ["wrapped-sse", true, "claude"], ["wrapped-sse", true, "responses"]
  ])("unwraps %s over HTTP with force=%s for %s", async (kind, force, source) => {
    fixture = kind;
    const result = await call({ stream: false, force, source });
    expect(result.status).toBe(200);
    const json = JSON.parse(result.text);
    const content = source === "claude" ? json.content[0].text
      : source === "responses" ? json.output.find(item => item.type === "message").content[0].text
        : json.choices[0].message.content;
    expect(content).toBe("WRAPPED_OK");
    expect(onSuccess).toHaveBeenCalledTimes(1);
    expect(saveRequestDetail.mock.calls.at(-1)[0]).toMatchObject({ status: "success", responseMode: "non-streaming" });
  });
  it.each(["chat", "claude"])("valid multiline SSE must preserve content for %s streaming client", async source => {
    fixture = "multiline";
    expect((await call({ source })).text).toContain("MULTILINE_OK");
  });
  it("control: synchronous aggregation rejects corrupted event", async () => {
    fixture = "corrupted";
    expect((await call({ stream: false, force: true })).status).toBe(502);
  });
  it.each(["chat", "claude"])("corrupted event must fail %s streaming client even with later finish", async source => {
    fixture = "corrupted";
    const output = await call({ source });
    expect(output.text).toMatch(/"error"|response\.failed/);
    expect(onSuccess).not.toHaveBeenCalled();
    expect(saveRequestDetail.mock.calls.at(-1)[0].status).toBe("error");
  });
  it("Responses missing terminal with DONE must not record success", async () => {
    fixture = "responses-done-only";
    const result = await call({ source: "responses", target: "responses" });
    expect(result.text).toContain("response.failed");
    expect.soft(onSuccess).not.toHaveBeenCalled();
    expect.soft(saveRequestDetail.mock.calls.at(-1)[0].status).toBe("error");
  });
  it("control: forced streaming preserves truncated tool finish", async () => {
    fixture = "tool-length";
    const result = await call({ stream: false, force: true });
    expect(JSON.parse(result.text).choices[0].finish_reason).toBe("length");
  });
  it("native synchronous reply must preserve truncated tool finish", async () => {
    fixture = "tool-length";
    const result = await call({ stream: false });
    expect(JSON.parse(result.text).choices[0].finish_reason).toBe("length");
  });
  it("native Responses incomplete tool reply must remain length after full handling", async () => {
    fixture = "tool-length";
    const result = await call({ stream: false, target: "responses" });
    expect(JSON.parse(result.text).choices[0].finish_reason).toBe("length");
  });
  it.each([["content_filter", "content_filter"], ["other", "tool_calls"], ["stop", "tool_calls"]])(
    "preserves exceptional tool finish and normalizes legacy finish: %s", async (reason, expected) => {
      fixture = `tool-${reason}`;
      const result = await call({ stream: false });
      expect(JSON.parse(result.text).choices[0].finish_reason).toBe(expected);
    }
  );
  it("regular synchronous handling preserves Responses cache details for Chat", async () => {
    fixture = "responses-cache";
    const result = await call({ stream: false, target: "responses" });
    expect(JSON.parse(result.text).usage.prompt_tokens_details.cached_tokens).toBe(80);
  });
  it("forced Responses SSE aggregation must preserve cache details for Chat", async () => {
    fixture = "responses-cache";
    const result = await call({ stream: false, force: true, target: "responses" });
    const usage = JSON.parse(result.text).usage;
    expect(usage.prompt_tokens_details?.cached_tokens).toBe(80);
    expect(usage.prompt_tokens).toBe(100);
    expect(usage.total_tokens).toBe(110);
    expect(upstreamRequests.at(-1).body.stream).toBe(true);
    expect(saveRequestDetail.mock.calls.at(-1)[0].tokens.prompt_tokens).toBe(100);
  });
  it("keeps legacy flat cache counters in forced Responses aggregation", async () => {
    fixture = "responses-cache-legacy";
    const result = await call({ stream: false, force: true, target: "responses" });
    const usage = JSON.parse(result.text).usage;
    expect(usage.prompt_tokens_details.cached_tokens).toBe(80);
    expect(usage.prompt_tokens).toBe(180);
    expect(saveRequestDetail.mock.calls.at(-1)[0].tokens.prompt_tokens).toBe(180);
  });
  it.each(["bad-json", "error-json", "empty-sse", "corrupted"])("synchronous failure saves one error detail: %s", async kind => {
    fixture = kind;
    expect((await call({ stream: false })).status).toBe(502);
    expect(onSuccess).not.toHaveBeenCalled();
    expect(saveRequestDetail).toHaveBeenCalledTimes(1);
    expect(saveRequestDetail).toHaveBeenCalledWith(expect.objectContaining({ status: "error", responseMode: "non-streaming" }));
  });
});
