import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({ getChannelBalances: vi.fn(), setChannelBalanceEnabled: vi.fn() }));
vi.mock("@/lib/channelBalances.js", () => ({ getChannelBalances: mocks.getChannelBalances }));
vi.mock("@/lib/localDb", () => ({ setChannelBalanceEnabled: mocks.setChannelBalanceEnabled }));

describe("channel balances route", () => {
  beforeEach(() => vi.clearAllMocks());

  it("provides query-free metadata for the channel controls", async () => {
    mocks.getChannelBalances.mockResolvedValue({ channels: [], channelOptions: [] });
    const { GET } = await import("../../src/app/api/channel-balances/route.js");
    const response = await GET(new Request("http://localhost/api/channel-balances?preferences=1"));
    expect(response.status).toBe(200); expect(mocks.getChannelBalances).toHaveBeenCalledWith({ query: false });
  });

  it("saves a single channel toggle and returns metadata without balance requests", async () => {
    mocks.getChannelBalances.mockResolvedValue({ channels: [], channelOptions: [{ id: "one", enabled: true }] });
    const { PATCH } = await import("../../src/app/api/channel-balances/route.js");
    const response = await PATCH(new Request("http://localhost/api/channel-balances", { method: "PATCH", body: JSON.stringify({ channelId: "one", enabled: false }) }));
    expect(response.status).toBe(200); expect(response.headers.get("Cache-Control")).toBe("private, no-store");
    expect(mocks.setChannelBalanceEnabled).toHaveBeenCalledWith("one", false);
    expect(mocks.getChannelBalances.mock.calls.every(([options]) => options.query === false)).toBe(true);
    expect(await response.json()).not.toHaveProperty("settings");
  });

  it("rejects malformed bodies, invalid types and settings mass assignment", async () => {
    const { PATCH } = await import("../../src/app/api/channel-balances/route.js");
    for (const body of ["{", "null", "[]", JSON.stringify({ channelId: "one", enabled: "false" }), JSON.stringify({ channelId: "one", enabled: false, requireLogin: false }), JSON.stringify({ channelId: "", enabled: false })]) {
      const response = await PATCH(new Request("http://localhost/api/channel-balances", { method: "PATCH", body }));
      expect(response.status).toBe(400);
    }
    expect(mocks.setChannelBalanceEnabled).not.toHaveBeenCalled();
  });

  it("rejects an unknown channel and redacts storage errors", async () => {
    mocks.getChannelBalances.mockResolvedValue({ channels: [], channelOptions: [] });
    const { PATCH } = await import("../../src/app/api/channel-balances/route.js");
    const makeRequest = () => new Request("http://localhost/api/channel-balances", { method: "PATCH", body: JSON.stringify({ channelId: "one", enabled: false }) });
    expect((await PATCH(makeRequest())).status).toBe(404); expect(mocks.setChannelBalanceEnabled).not.toHaveBeenCalled();
    mocks.getChannelBalances.mockRejectedValue(new Error("database /home/secret sk-credential"));
    const response = await PATCH(makeRequest());
    expect(response.status).toBe(500); expect(JSON.stringify(await response.json())).not.toMatch(/home|credential/);
  });

  it("returns a private non-cacheable snapshot and forwards forced refresh", async () => {
    mocks.getChannelBalances.mockResolvedValue({ generatedAt: "2026-09-30T06:00:00Z", channels: [] });
    const { GET } = await import("../../src/app/api/channel-balances/route.js");
    const response = await GET(new Request("http://localhost/api/channel-balances?force=1"));
    expect(response.status).toBe(200); expect(response.headers.get("Cache-Control")).toBe("private, no-store");
    expect(mocks.getChannelBalances).toHaveBeenCalledWith({ force: true });
    expect((await response.json()).channels).toEqual([]);
  });

  it("does not leak database or credential errors", async () => {
    mocks.getChannelBalances.mockRejectedValue(new Error("database /home/secret sk-credential"));
    const { GET } = await import("../../src/app/api/channel-balances/route.js");
    const response = await GET(new Request("http://localhost/api/channel-balances"));
    expect(response.status).toBe(500); expect(JSON.stringify(await response.json())).not.toMatch(/home|sk-credential/);
  });
});
