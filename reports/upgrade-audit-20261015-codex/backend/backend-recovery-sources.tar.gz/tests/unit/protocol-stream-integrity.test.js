import { describe, expect, it, vi } from "vitest";
import { createSSEStream } from "open-sse/utils/stream.js";
import { handleStreamingResponse } from "open-sse/handlers/chatCore/streamingHandler.js";
import { createStreamController } from "open-sse/utils/streamHandler.js";
import { FORMATS } from "open-sse/translator/formats.js";
import { translateRequest } from "open-sse/translator/index.js";

vi.mock("@/lib/usageDb.js", () => ({
  appendRequestLog: vi.fn(async () => {}),
  trackPendingRequest: vi.fn(),
  saveRequestDetail: vi.fn(async () => {}),
  saveRequestUsage: vi.fn(async () => {})
}));

const frame = (data, event = null) => `${event ? `event: ${event}\n` : ""}data: ${JSON.stringify(data)}\n\n`;
const chat = (delta, finish = null, extra = {}) => ({
  id: "chatcmpl-audit", object: "chat.completion.chunk", created: 1, model: "audit-model",
  choices: [{ index: 0, delta, finish_reason: finish }], ...extra
});
const body = { messages: [{ role: "user", content: "hi" }] };

async function transform(wire, targetFormat, sourceFormat, mode = "translate") {
  const complete = vi.fn();
  const stream = createSSEStream({ mode, targetFormat, sourceFormat, body, onStreamComplete: complete });
  const output = await new Response(new Response(wire).body.pipeThrough(stream)).text();
  return { output, complete };
}

async function route(wire, provider, sourceFormat, targetFormat) {
  const complete = vi.fn();
  const result = await handleStreamingResponse({
    providerResponse: new Response(wire, { headers: { "content-type": "text/event-stream" } }),
    provider, sourceFormat, targetFormat, model: "audit-model", body, stream: true,
    requestStartTime: Date.now(), streamController: createStreamController(),
    onStreamComplete: complete
  });
  return { output: await result.response.text(), complete };
}

function dataEvents(wire) {
  return wire.split("\n").filter(line => line.startsWith("data:") && !line.includes("[DONE]"))
    .map(line => JSON.parse(line.slice(5)));
}

describe("new audit streaming contracts", () => {
  it("Claude upstream errors survive conversion to OpenAI", async () => {
    const wire = frame({ type: "error", error: { type: "overloaded_error", message: "AUDIT_OVERLOAD" } }, "error");
    const { output } = await transform(wire, FORMATS.CLAUDE, FORMATS.OPENAI);
    expect(output).toContain("AUDIT_OVERLOAD");
  });

  it("OpenAI upstream errors survive conversion to Claude", async () => {
    const wire = frame({ error: { type: "server_error", message: "AUDIT_SERVER_ERROR" } });
    const { output } = await transform(wire, FORMATS.OPENAI, FORMATS.CLAUDE);
    expect(output).toContain("AUDIT_SERVER_ERROR");
  });

  it("native OpenAI emits the DONE sentinel once", async () => {
    const wire = frame(chat({ content: "hello" })) + frame(chat({}, "stop")) + "data: [DONE]\n\n";
    const { output } = await transform(wire, FORMATS.OPENAI, FORMATS.OPENAI, "passthrough");
    expect(output.match(/\[DONE\]/g)?.length).toBe(1);
  });

  it("native OpenAI does not silently turn a truncated stream into success", async () => {
    const { output } = await transform(frame(chat({ content: "partial" })), FORMATS.OPENAI, FORMATS.OPENAI, "passthrough");
    expect(output).toMatch(/error|failed/);
  });

  it("registered Responses accepts incomplete as a terminal state", async () => {
    const wire = frame({ type: "response.incomplete", response: {
      id: "resp_audit", status: "incomplete", incomplete_details: { reason: "max_output_tokens" }
    } }, "response.incomplete");
    const { output } = await route(wire, "codex", FORMATS.OPENAI_RESPONSES, FORMATS.OPENAI_RESPONSES);
    expect(output).not.toContain("response.failed");
  });

  it("compatible Responses routing detects missing terminal events", async () => {
    const wire = frame({ type: "response.created", response: { id: "resp_audit", status: "in_progress" } }, "response.created");
    const { output } = await route(wire, "openai-compatible-responses-audit", FORMATS.OPENAI_RESPONSES, FORMATS.OPENAI_RESPONSES);
    expect(output).toContain("response.failed");
  });

  it("translated Claude usage includes the final OpenAI usage-only chunk", async () => {
    const wire = frame(chat({ content: "hi" })) + frame(chat({}, "stop"))
      + frame({ ...chat({}), choices: [], usage: { prompt_tokens: 123, completion_tokens: 45, total_tokens: 168 } })
      + "data: [DONE]\n\n";
    const { output } = await transform(wire, FORMATS.OPENAI, FORMATS.CLAUDE);
    const finalUsage = dataEvents(output).filter(event => event.type === "message_delta").at(-1)?.usage;
    expect(finalUsage?.output_tokens).toBe(45);
  });

  it("native OpenAI retains a nonempty secondary choice", async () => {
    const wire = frame({ ...chat({}), choices: [
      { index: 0, delta: {}, finish_reason: null },
      { index: 1, delta: { content: "AUDIT_SECOND_CHOICE" }, finish_reason: null }
    ] }) + "data: [DONE]\n\n";
    const { output } = await transform(wire, FORMATS.OPENAI, FORMATS.OPENAI, "passthrough");
    expect(output).toContain("AUDIT_SECOND_CHOICE");
  });

  it("Chat to Responses does not complete a truncated reply", async () => {
    const { output } = await transform(frame(chat({ content: "partial" })), FORMATS.OPENAI, FORMATS.OPENAI_RESPONSES);
    expect(output).not.toContain('"status":"completed"');
    expect(output).toMatch(/error|failed/);
  });

  it("Chat length becomes Responses incomplete rather than completed", async () => {
    const wire = frame(chat({ content: "partial" })) + frame(chat({}, "length")) + "data: [DONE]\n\n";
    const { output } = await transform(wire, FORMATS.OPENAI, FORMATS.OPENAI_RESPONSES);
    expect(output).toContain('"status":"incomplete"');
  });

  it("Responses upstream failure is an error, not normal assistant text", async () => {
    const wire = frame({ type: "response.failed", response: {
      id: "resp_audit", status: "failed", error: { code: "server_error", message: "AUDIT_RESPONSE_FAILURE" }
    } }, "response.failed");
    const { output } = await transform(wire, FORMATS.OPENAI_RESPONSES, FORMATS.OPENAI);
    expect(dataEvents(output).some(event => event.error)).toBe(true);
  });

  it("OpenAI none still forbids tools after Claude request conversion", () => {
    const request = {
      messages: [{ role: "user", content: "hi" }], tool_choice: "none",
      tools: [{ type: "function", function: { name: "audit_tool", parameters: { type: "object", properties: {} } } }]
    };
    const converted = translateRequest(FORMATS.OPENAI, FORMATS.CLAUDE, "audit-model", request, true);
    expect(converted.tool_choice?.type).toBe("none");
  });

  it("Claude none still forbids tools after OpenAI request conversion", () => {
    const request = {
      messages: [{ role: "user", content: "hi" }], tool_choice: { type: "none" },
      tools: [{ name: "audit_tool", input_schema: { type: "object", properties: {} } }]
    };
    const converted = translateRequest(FORMATS.CLAUDE, FORMATS.OPENAI, "audit-model", request, true);
    expect(converted.tool_choice).toBe("none");
  });

  it("OpenAI sequential-tool constraint survives Claude request conversion", () => {
    const request = {
      messages: [{ role: "user", content: "hi" }], tool_choice: "auto", parallel_tool_calls: false,
      tools: [{ type: "function", function: { name: "audit_tool", parameters: { type: "object", properties: {} } } }]
    };
    const converted = translateRequest(FORMATS.OPENAI, FORMATS.CLAUDE, "audit-model", request, true);
    expect(converted.tool_choice?.disable_parallel_tool_use).toBe(true);
  });

  it("Claude sequential-tool constraint survives OpenAI request conversion", () => {
    const request = {
      messages: [{ role: "user", content: "hi" }], tool_choice: { type: "auto", disable_parallel_tool_use: true },
      tools: [{ name: "audit_tool", input_schema: { type: "object", properties: {} } }]
    };
    const converted = translateRequest(FORMATS.CLAUDE, FORMATS.OPENAI, "audit-model", request, true);
    expect(converted.parallel_tool_calls).toBe(false);
  });

  it("handles a final error line without a newline", async () => {
    const { output, complete } = await transform('data: {"error":{"message":"TAIL_ERROR"}}', FORMATS.OPENAI, FORMATS.CLAUDE);
    expect(output).toContain("TAIL_ERROR");
    expect(complete.mock.calls[0][0].status).toBe("failed");
  });

  it("handles final DONE without a newline without duplicating it", async () => {
    const { output } = await transform(frame(chat({ content: "hello" }, "stop")) + "data: [DONE]", FORMATS.OPENAI, FORMATS.OPENAI, "passthrough");
    expect(output.match(/\[DONE\]/g)).toHaveLength(1);
  });

  it("rejects truncated Responses upstream when converted to Chat", async () => {
    const { output, complete } = await transform(frame({ type: "response.output_text.delta", delta: "partial" }), FORMATS.OPENAI_RESPONSES, FORMATS.OPENAI);
    expect(output).toContain("stream_disconnected");
    expect(output).not.toContain('"finish_reason":"stop"');
    expect(complete.mock.calls[0][0].status).toBe("failed");
  });

  it("does not clear account errors for failed upstream SSE", async () => {
    const success = vi.fn();
    const result = await handleStreamingResponse({
      providerResponse: new Response(frame({ error: { message: "UPSTREAM_FAILURE" } }), { headers: { "content-type": "text/event-stream" } }),
      provider: "openai-compatible-chat-audit", sourceFormat: FORMATS.OPENAI, targetFormat: FORMATS.OPENAI,
      body, model: "audit-model", requestStartTime: Date.now(), streamController: createStreamController(),
      onRequestSuccess: success
    });
    expect(await result.response.text()).toContain("UPSTREAM_FAILURE");
    expect(success).not.toHaveBeenCalled();
  });
});

describe("passing controls", () => {
  it("native OpenAI preserves CRLF and byte-split Unicode", async () => {
    const bytes = new TextEncoder().encode((frame(chat({ content: "\u4e2d\u6587" })) + "data: [DONE]\n\n").replaceAll("\n", "\r\n"));
    const upstream = new ReadableStream({ start(controller) {
      for (const byte of bytes) controller.enqueue(new Uint8Array([byte]));
      controller.close();
    } });
    const output = await new Response(upstream.pipeThrough(createSSEStream({ mode: "passthrough", body }))).text();
    expect(output).toContain("\u4e2d\u6587");
    expect(output).not.toContain("\ufffd");
  });

  it("native Claude preserves signed thinking deltas", async () => {
    const wire = frame({ type: "content_block_delta", index: 0, delta: { type: "signature_delta", signature: "AUDIT_SIGNATURE" } }, "content_block_delta")
      + frame({ type: "message_stop" }, "message_stop");
    const { output } = await route(wire, "anthropic-compatible-audit", FORMATS.CLAUDE, FORMATS.CLAUDE);
    expect(output).toContain("AUDIT_SIGNATURE");
  });

  it("parallel tool argument fragments survive conversion after finish", async () => {
    const wire = frame(chat({ tool_calls: [
      { index: 0, id: "call_a", type: "function", function: { name: "tool_a", arguments: '{"value":' } },
      { index: 1, id: "call_b", type: "function", function: { name: "tool_b", arguments: '{"value":' } }
    ] })) + frame(chat({ tool_calls: [
      { index: 0, function: { arguments: "1}" } },
      { index: 1, function: { arguments: "2}" } }
    ] })) + frame(chat({}, "tool_calls")) + "data: [DONE]\n\n";
    const { output } = await transform(wire, FORMATS.OPENAI, FORMATS.CLAUDE);
    const argumentsValues = dataEvents(output).filter(event => event.delta?.type === "input_json_delta")
      .map(event => JSON.parse(event.delta.partial_json).value);
    expect(argumentsValues).toEqual([1, 2]);
  });
});
