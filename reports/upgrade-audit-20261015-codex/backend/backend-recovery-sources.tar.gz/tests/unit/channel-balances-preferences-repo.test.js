import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";

const originalDataDir = process.env.DATA_DIR;
let tempDir;
let db;

beforeAll(async () => {
  tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "10router-balance-preferences-"));
  process.env.DATA_DIR = tempDir; vi.resetModules();
  db = await import("@/lib/db/index.js"); await db.initDb();
});

afterAll(() => {
  if (tempDir && path.dirname(path.resolve(tempDir)) === path.resolve(os.tmpdir()) && path.basename(tempDir).startsWith("10router-balance-preferences-")) {
    try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch {}
  }
  if (originalDataDir === undefined) delete process.env.DATA_DIR;
  else process.env.DATA_DIR = originalDataDir;
});

describe("channel balance preferences in the real settings store", () => {
  it("exports the helper through the database and localDb boundaries", async () => {
    const shim = await import("@/lib/localDb");
    expect(typeof shim.setChannelBalanceEnabled).toBe("function");
    expect((await db.getSettings()).channelBalanceDisabledIds).toEqual([]);
  });

  it("persists hide and show without changing routing, credentials or other settings", async () => {
    await db.updateSettings({ providerStrategies: { bx: "round-robin" }, customMarker: "keep" });
    await db.setChannelBalanceEnabled("bx-node", false);
    expect((await db.getSettings()).channelBalanceDisabledIds).toContain("bx-node");
    await db.setChannelBalanceEnabled("bx-node", false);
    expect((await db.getSettings()).channelBalanceDisabledIds.filter(value => value === "bx-node")).toHaveLength(1);
    await db.setChannelBalanceEnabled("bx-node", true);
    expect(await db.getSettings()).toMatchObject({ channelBalanceDisabledIds: [], providerStrategies: { bx: "round-robin" }, customMarker: "keep" });
  });

  it("preserves concurrent toggles of different channels and unrelated settings", async () => {
    await Promise.all([db.setChannelBalanceEnabled("first", false), db.setChannelBalanceEnabled("second", false), db.updateSettings({ customMarker: "latest" })]);
    expect(await db.getSettings()).toMatchObject({ channelBalanceDisabledIds: ["first", "second"], customMarker: "latest" });
    await Promise.all([db.setChannelBalanceEnabled("first", true), db.setChannelBalanceEnabled("third", false)]);
    expect((await db.getSettings()).channelBalanceDisabledIds).toEqual(["second", "third"]);
  });

  it("rejects invalid input without writing preferences", async () => {
    const previous = (await db.getSettings()).channelBalanceDisabledIds;
    for (const [identifier, enabled] of [["", false], ["a".repeat(129), false], ["one", "false"], [null, true]]) {
      await expect(db.setChannelBalanceEnabled(identifier, enabled)).rejects.toThrow();
    }
    expect((await db.getSettings()).channelBalanceDisabledIds).toEqual(previous);
  });
});
