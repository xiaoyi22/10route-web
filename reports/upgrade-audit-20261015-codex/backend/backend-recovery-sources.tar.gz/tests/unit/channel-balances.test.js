import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  getProviderConnections: vi.fn(), getProviderNodes: vi.fn(), getSettings: vi.fn(),
  resolveConnectionProxyConfig: vi.fn(), proxyAwareFetch: vi.fn(),
}));
vi.mock("@/lib/localDb", () => ({ getProviderConnections: mocks.getProviderConnections, getProviderNodes: mocks.getProviderNodes, getSettings: mocks.getSettings }));
vi.mock("@/lib/network/connectionProxy", () => ({ resolveConnectionProxyConfig: mocks.resolveConnectionProxyConfig }));
vi.mock("open-sse/utils/proxyFetch.js", () => ({ proxyAwareFetch: mocks.proxyAwareFetch }));

const nexa = { id: "node-nexa", type: "openai-compatible", name: "NexaVlinks", prefix: "nexa", baseUrl: "https://www.nexavlinks.com/v1" };
const aiapi = { id: "node-aiapi", type: "openai-compatible", name: "aiapi", prefix: "aiapi", baseUrl: "https://aiapi.codes/v1" };
const relayfor = { id: "node-relayfor", type: "openai-compatible", name: "RelayFor", prefix: "rf", baseUrl: "https://relayfor.xyz/v1" };
const connection = { id: "key-one", provider: nexa.id, name: "Wallet key", authType: "apikey", apiKey: "sk-SECRET", isActive: true };
const usage = { isValid: true, planName: "钱包余额", balance: 19.6, remaining: 19.6, unit: "USD" };
const subscriptions = { object: "list", data: [{ subscription: { id: 42, plan_name: "Lite", expires_at: "2026-10-16T12:00:00Z" }, progress: { weekly: { limit_usd: 27.95, used_usd: 25.37, remaining_usd: 2.58, resets_at: "2026-10-02T16:34:00Z" } } }] };
const aiUsage = { ok: true, data: { currency: "CNY", key: { secret: "DO-NOT-EXPOSE" }, available: { amount: 83.07, source: "subscription" }, today: { cost: 2.55, calls: 243, tokens: 26000 }, limits: { daily: { limit: null, used: 2.55, remaining: null }, weekly: { limit: 100, used: 16.93, remaining: 83.07 } } } };
let service;

beforeEach(async () => {
  vi.resetModules(); vi.clearAllMocks();
  mocks.getSettings.mockResolvedValue({});
  mocks.getProviderNodes.mockResolvedValue([nexa, aiapi]);
  mocks.getProviderConnections.mockResolvedValue([connection]);
  mocks.resolveConnectionProxyConfig.mockResolvedValue({ connectionProxyEnabled: true, connectionProxyUrl: "http://127.0.0.1:7892", strictProxy: true });
  mocks.proxyAwareFetch.mockImplementation(async (url) => Response.json(url.includes("subscriptions") ? subscriptions : usage));
  service = await import("../../src/lib/channelBalances.js");
});
afterEach(() => vi.useRealTimers());

describe("channel balance normalization", () => {
  it("identifies only known HTTPS compatible nodes without trusting their names", () => {
    expect(service.getChannelBalanceAdapter(nexa)).toBe("nexavlinks");
    expect(service.getChannelBalanceAdapter(aiapi)).toBe("aiapi");
    expect(service.getChannelBalanceAdapter(relayfor)).toBe("relayfor");
    expect(service.getChannelBalanceAdapter({ ...relayfor, baseUrl: "https://relayfor.xyz.evil.test/v1" })).toBeNull();
    for (const baseUrl of ["http://aiapi.codes/v1", "https://aiapi.codes.evil.test/v1", "https://evil.test/v1", "https://user@aiapi.codes/v1", "https://aiapi.codes:8443/v1", "https://aiapi.codes/prefix/v1"]) {
      expect(service.getChannelBalanceAdapter({ ...aiapi, baseUrl })).toBeNull();
    }
    expect(service.getChannelBalanceAdapter({ ...aiapi, type: "oauth" })).toBeNull();
  });

  it("separates a USD wallet from every subscription and reset time", () => {
    const result = service.parseNexaBalance(usage, subscriptions);
    expect(result.wallet).toEqual({ amount: 19.6, currency: "USD" });
    expect(result.subscriptions[0]).toMatchObject({ id: "42", name: "Lite", expiresAt: "2026-10-16T12:00:00Z" });
    expect(result.subscriptions[0].windows[0]).toEqual({ period: "weekly", currency: "USD", limit: 27.95, used: 25.37, remaining: 2.58, resetsAt: "2026-10-02T16:34:00Z" });
  });

  it("does not call a subscription key's remaining amount a wallet balance", () => {
    const result = service.parseNexaBalance({ isValid: true, remaining: 2.58, unit: "USD", subscription: {} }, subscriptions);
    expect(result.wallet).toBeNull();
    expect(result.available).toEqual({ amount: 2.58, currency: "USD", source: "subscription" });
  });

  it("preserves missing balances and missing weekly limits as unknown", () => {
    const result = service.parseNexaBalance({ isValid: true, unit: "USD" }, { object: "list", data: [{ subscription: { id: 3 }, progress: {} }] });
    expect(result.wallet).toBeNull(); expect(result.available).toBeNull();
    expect(result.subscriptions[0].windows).toEqual([]);
  });

  it("keeps genuine zero balances and zero limits", () => {
    const result = service.parseNexaBalance({ ...usage, balance: 0, remaining: 0 }, { object: "list", data: [{ subscription: { id: 1 }, progress: { weekly: { limit_usd: 0, used_usd: 0, remaining_usd: 0 } } }] });
    expect(result.wallet.amount).toBe(0); expect(result.subscriptions[0].windows[0].limit).toBe(0);
  });

  it("keeps multiple subscriptions and all returned time windows", () => {
    const result = service.parseNexaBalance(usage, { object: "list", data: [...subscriptions.data, { subscription: { id: 43, plan_name: "Second" }, progress: { daily: { limit_usd: 3, remaining_usd: 2 }, monthly: { limit_usd: 40, remaining_usd: 30 } } }] });
    expect(result.subscriptions).toHaveLength(2);
    expect(result.subscriptions[1].windows.map((window) => window.period)).toEqual(["daily", "monthly"]);
  });

  it("labels aiapi subscription funding and preserves CNY without inventing wallet data", () => {
    const result = service.parseAiapiBalance(aiUsage);
    expect(result.wallet).toBeNull();
    expect(result.walletUnavailable).toBe(true);
    expect(result.balanceUrl).toBe("https://aiapi.codes/dashboard");
    expect(result.notice).toContain("website login");
    expect(result.available).toEqual({ amount: 83.07, currency: "CNY", source: "subscription" });
    expect(result.limits).toEqual([{ period: "weekly", currency: "CNY", limit: 100, used: 16.93, remaining: 83.07, resetsAt: null }]);
    expect(JSON.stringify(result)).not.toContain("DO-NOT-EXPOSE");
  });

  it("does not call mixed funding a wallet and does not coerce null into zero", () => {
    const result = service.parseAiapiBalance({ ...aiUsage, data: { ...aiUsage.data, available: { amount: null, source: "subscription_then_balance" } } });
    expect(result.available).toEqual({ amount: null, currency: "CNY", source: "subscription_then_balance" });
    expect(result.wallet).toBeNull();
  });

  it("rejects invalid upstream JSON shapes and currency values", () => {
    expect(() => service.parseAiapiBalance({ ok: false })).toThrow();
    expect(() => service.parseAiapiBalance({ ...aiUsage, data: { ...aiUsage.data, currency: null } })).toThrow();
    expect(() => service.parseNexaBalance({ isValid: false }, subscriptions)).toThrow();
    expect(() => service.parseNexaBalance(usage, {})).toThrow();
  });
});

describe("channel balance requests", () => {
  it("keeps RelayFor visible with its verified login restriction without sending model keys to session endpoints", async () => {
    mocks.getProviderNodes.mockResolvedValue([relayfor]);
    mocks.getProviderConnections.mockResolvedValue([{ ...connection, provider: relayfor.id }]);
    const result = await service.getChannelBalances();
    expect(result.channels[0]).toMatchObject({ name: "RelayFor", prefix: "rf", adapter: "relayfor" });
    expect(result.channels[0].connections[0]).toMatchObject({ status: "login_required", wallet: null, available: null, walletUnavailable: true, checkedAt: null, balanceUrl: "https://relayfor.xyz/console/" });
    expect(mocks.proxyAwareFetch).not.toHaveBeenCalled();
    expect(mocks.resolveConnectionProxyConfig).not.toHaveBeenCalled();
    expect(JSON.stringify(result)).not.toContain("sk-SECRET");
    mocks.getSettings.mockResolvedValue({ channelBalanceDisabledIds: [relayfor.id] });
    expect((await service.getChannelBalances()).channels).toEqual([]);
  });

  it("does not display inactive RelayFor connections as needing website login", async () => {
    mocks.getProviderNodes.mockResolvedValue([relayfor]);
    mocks.getProviderConnections.mockResolvedValue([{ ...connection, provider: relayfor.id, isActive: false }]);
    expect((await service.getChannelBalances()).channels).toEqual([]);
    expect(mocks.proxyAwareFetch).not.toHaveBeenCalled();
  });

  it("makes only authenticated GET requests with a timeout, no redirects, and strict proxy configuration", async () => {
    await service.getChannelBalances();
    expect(mocks.proxyAwareFetch).toHaveBeenCalledTimes(2);
    for (const [url, options, proxy] of mocks.proxyAwareFetch.mock.calls) {
      expect(url).toMatch(/^https:\/\/www\.nexavlinks\.com\/v1\/(usage\?days=7|subscriptions)$/);
      expect(options).toMatchObject({ method: "GET", redirect: "manual", headers: { Authorization: "Bearer sk-SECRET" } });
      expect(options.signal).toBeInstanceOf(AbortSignal); expect(proxy.strictProxy).toBe(true);
    }
  });

  it("uses aiapi's real /v1/usage endpoint instead of generic New API paths", async () => {
    mocks.getProviderConnections.mockResolvedValue([{ ...connection, provider: aiapi.id }]);
    mocks.proxyAwareFetch.mockResolvedValue(Response.json(aiUsage));
    const result = await service.getChannelBalances();
    expect(mocks.proxyAwareFetch.mock.calls[0][0]).toBe("https://aiapi.codes/v1/usage");
    expect(result.channels[0].connections[0].available.source).toBe("subscription");
  });

  it("shares in-flight queries and caches requests with a forced refresh floor", async () => {
    vi.useFakeTimers({ toFake: ["Date"] });
    await Promise.all([service.getChannelBalances(), service.getChannelBalances()]);
    expect(mocks.proxyAwareFetch).toHaveBeenCalledTimes(2);
    await service.getChannelBalances({ force: true });
    expect(mocks.proxyAwareFetch).toHaveBeenCalledTimes(2);
    vi.setSystemTime(Date.now() + 30001);
    await service.getChannelBalances({ force: true });
    expect(mocks.proxyAwareFetch).toHaveBeenCalledTimes(4);
  });

  it("invalidates cached amounts when a connection's API key changes", async () => {
    await service.getChannelBalances();
    mocks.getProviderConnections.mockResolvedValue([{ ...connection, apiKey: "sk-REPLACED" }]);
    await service.getChannelBalances();
    expect(mocks.proxyAwareFetch).toHaveBeenCalledTimes(4);
  });

  it("keeps the last successful balance and its timestamp when refresh fails", async () => {
    vi.useFakeTimers({ toFake: ["Date"] });
    const first = await service.getChannelBalances();
    const checkedAt = first.channels[0].connections[0].checkedAt;
    mocks.proxyAwareFetch.mockRejectedValue(new Error("network unavailable"));
    vi.setSystemTime(Date.now() + 30001);
    const failed = await service.getChannelBalances({ force: true });
    expect(failed.channels[0].connections[0]).toMatchObject({
      status: "partial", stale: true, checkedAt,
      wallet: { amount: 19.6, currency: "USD" }, error: "Network error querying balance",
    });
    expect(failed.channels[0].subscriptions[0].windows[0].remaining).toBe(2.58);
    expect(failed.errors).toEqual([expect.objectContaining({ channelId: nexa.id, connectionId: connection.id, error: "Network error querying balance" })]);
    const cached = await service.getChannelBalances();
    expect(cached.channels[0].connections[0]).toMatchObject({ stale: true, checkedAt, cached: true });
    vi.setSystemTime(Date.now() + 30001);
    mocks.proxyAwareFetch.mockImplementation(async (url) => Response.json(url.includes("subscriptions") ? subscriptions : { ...usage, balance: 12 }));
    const recovered = await service.getChannelBalances({ force: true });
    expect(recovered.channels[0].connections[0]).toMatchObject({ status: "ok", wallet: { amount: 12 }, error: null });
    expect(recovered.channels[0].connections[0].stale).not.toBe(true);
    expect(recovered.errors).toEqual([]);
  });

  it("does not reuse an old balance after the key changes and exposes the failure", async () => {
    await service.getChannelBalances();
    mocks.getProviderConnections.mockResolvedValue([{ ...connection, apiKey: "sk-REPLACED" }]);
    mocks.proxyAwareFetch.mockResolvedValue(Response.json({}, { status: 401 }));
    const result = await service.getChannelBalances();
    expect(result.channels).toEqual([]);
    expect(result.errors).toEqual([expect.objectContaining({ error: "Balance query returned HTTP 401" })]);
    expect(JSON.stringify(result)).not.toMatch(/19\.6|sk-REPLACED/);
  });

  it("never sends a key to unsupported nodes, disabled connections, or unrelated providers", async () => {
    mocks.getProviderNodes.mockResolvedValue([nexa, { ...aiapi, baseUrl: "https://unknown.test/v1" }]);
    mocks.getProviderConnections.mockResolvedValue([{ ...connection, isActive: false }, { ...connection, id: "other", provider: aiapi.id }, { ...connection, id: "oauth", provider: "codex" }]);
    const result = await service.getChannelBalances();
    expect(mocks.proxyAwareFetch).not.toHaveBeenCalled();
    expect(result.channels).toEqual([]);
    expect(result.channelOptions).toHaveLength(2);
  });

  it("deduplicates shared subscriptions across Nexa keys without summing wallets or currencies", async () => {
    mocks.getProviderConnections.mockResolvedValue([connection, { ...connection, id: "second", name: "Subscription key" }]);
    const result = await service.getChannelBalances();
    expect(result.channels[0].subscriptions).toHaveLength(1);
    expect(result.channels[0].subscriptions[0].connectionIds).toEqual(["key-one", "second"]);
    expect(result.channels[0]).not.toHaveProperty("totalBalance");
  });

  it("preserves a wallet result when subscription querying is disabled", async () => {
    mocks.proxyAwareFetch.mockImplementation(async (url) => url.includes("subscriptions") ? Response.json({ error: { type: "SUBSCRIPTION_QUERY_DISABLED" } }, { status: 403 }) : Response.json(usage));
    const result = await service.getChannelBalances();
    const entry = result.channels[0].connections[0];
    expect(entry.status).toBe("partial"); expect(entry.wallet.amount).toBe(19.6);
    expect(entry.error).toContain("subscription queries are disabled");
  });

  it("preserves subscription remaining data when the wallet query fails", async () => {
    mocks.proxyAwareFetch.mockImplementation(async (url) => url.includes("subscriptions") ? Response.json(subscriptions) : Response.json({}, { status: 503 }));
    const result = await service.getChannelBalances();
    expect(result.channels[0].connections[0]).toMatchObject({ status: "partial", wallet: null });
    expect(result.channels[0].subscriptions[0].windows[0].remaining).toBe(2.58);
  });

  it("hides valid responses with no wallet, remaining amount or subscription balance", async () => {
    mocks.proxyAwareFetch.mockImplementation(async (url) => Response.json(url.includes("subscriptions") ? { object: "list", data: [] } : { isValid: true, unit: "USD" }));
    expect((await service.getChannelBalances()).channels).toEqual([]);
  });

  it("hides unavailable amounts rather than showing false zeros on HTTP errors", async () => {
    mocks.proxyAwareFetch.mockResolvedValue(Response.json({ message: "secret echo sk-SECRET" }, { status: 401 }));
    const result = await service.getChannelBalances();
    expect(result.channels).toEqual([]);
    expect(result.channelOptions).toHaveLength(1);
    expect(JSON.stringify(result)).not.toMatch(/sk-SECRET|secret echo/);
  });

  it("does not return credentials, proxy secrets, or provider-specific fields", async () => {
    mocks.getProviderConnections.mockResolvedValue([{ ...connection, name: "sk-SECRET", accessToken: "HIDDEN-ACCESS", providerSpecificData: { password: "HIDDEN-PASSWORD" } }]);
    const result = await service.getChannelBalances();
    expect(JSON.stringify(result)).not.toMatch(/sk-SECRET|HIDDEN-ACCESS|HIDDEN-PASSWORD|7892/);
  });
});
