import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({ nodes: vi.fn(), connections: vi.fn(), settings: vi.fn(), proxy: vi.fn(), fetch: vi.fn() }));
vi.mock("@/lib/localDb", () => ({ getProviderNodes: mocks.nodes, getProviderConnections: mocks.connections, getSettings: mocks.settings }));
vi.mock("@/lib/network/connectionProxy", () => ({ resolveConnectionProxyConfig: mocks.proxy }));
vi.mock("open-sse/utils/proxyFetch.js", () => ({ proxyAwareFetch: mocks.fetch }));

const node = { id: "public-node", name: "BX", type: "openai-compatible", category: "publicWelfare", prefix: "bx", baseUrl: "https://api.bxacc.xyz/v1" };
const connection = { id: "public-key", provider: node.id, authType: "apikey", name: "Main", apiKey: "sk-PRIVATE", isActive: true };
const newapi = { code: true, data: { object: "token_usage", name: "sk-PRIVATE", total_granted: 0, total_used: 399584, total_available: -399584, unlimited_quota: true, expires_at: 0 } };
const modern = {
  object: "sub2api.key_usage", schema_version: 1,
  key: { status: "active", expires_at: "2026-10-10T00:00:00Z", quota: { limit: 100, used: 20, remaining: 80, unit: "USD" }, rate_limits: [{ window: "5h", limit: 10, used: 2, remaining: 8, reset_at: "2026-10-01T00:00:00Z" }] },
  wallet: { balance: 12.5, unit: "USD" },
  channels: [{ channel_id: 7, status: "available", name: "Plan", funding: "subscription", unit: "USD", subscription: { status: "active", expires_at: "2026-10-16T00:00:00Z" }, windows: [{ window: "7d", limit: 30, used: 10, remaining: 20, reset_at: "2026-10-02T00:00:00Z" }] }, { channel_id: 8, status: "unavailable" }],
  usage: { today: { actual_cost: 1.5, requests: 3, total_tokens: 123 } },
  internal: { apiKey: "sk-PRIVATE", password: "SECRET-PASSWORD" },
};
let service;

beforeEach(async () => {
  vi.resetModules(); vi.clearAllMocks();
  mocks.settings.mockResolvedValue({});
  mocks.nodes.mockResolvedValue([node]); mocks.connections.mockResolvedValue([connection]);
  mocks.proxy.mockResolvedValue({ connectionProxyEnabled: true, connectionProxyUrl: "http://127.0.0.1:7892", strictProxy: true });
  mocks.fetch.mockImplementation(async () => Response.json(newapi));
  service = await import("../../src/lib/channelBalances.js");
});

describe("public welfare channel balances", () => {
  it("does not mistake object prototype names for allowlisted upstream hosts", async () => {
    mocks.nodes.mockResolvedValue([{ ...node, baseUrl: "https://constructor/v1" }]);
    expect(service.getChannelBalanceAdapter({ ...node, baseUrl: "https://constructor/v1" })).toBeNull();
    const result = await service.getChannelBalances();
    expect(result.channels).toEqual([]); expect(mocks.fetch).not.toHaveBeenCalled();
  });

  it.each([
    ["api.bxacc.xyz", "newapi"], ["pmcat.top", "newapi"], ["api.feixingwawa.cn", "newapi"], ["grok-heavy.878.indevs.in", "newapi"],
    ["x-api.cfd", "sub2api"], ["api.xn--xwr.site", "sub2api"], ["api.fengwind.com", "fengwind"], ["anyrouter.top", "legacy"],
  ])("recognizes the audited %s host without trusting the display name", (host, adapter) => {
    expect(service.getChannelBalanceAdapter({ ...node, name: "Not a brand", baseUrl: `https://${host}/v1` })).toBe(adapter);
    expect(service.getChannelBalanceAdapter({ ...node, baseUrl: `https://${host}.evil.test/v1` })).toBeNull();
  });

  it("keeps unlimited NewAPI keys separate from wallets and suppresses negative remaining", () => {
    const result = service.parseNewapiBalance(newapi);
    expect(result.wallet).toBeNull(); expect(result.available).toBeNull();
    expect(result.keyQuota).toEqual({ unit: "quota", unlimited: true, limit: null, used: 399584, remaining: null });
    expect(result.keyExpiresAt).toBeNull(); expect(JSON.stringify(result)).not.toContain("sk-PRIVATE");
  });

  it("preserves finite NewAPI raw quota and expiry without converting it to money", () => {
    const result = service.parseNewapiBalance({ success: true, data: { ...newapi.data, unlimited_quota: false, total_granted: 1000, total_available: 600, total_used: 400, expires_at: 1791504000 } });
    expect(result.keyQuota).toEqual({ unit: "quota", unlimited: false, limit: 1000, used: 400, remaining: 600 });
    expect(result.keyExpiresAt).toBe(new Date(1791504000000).toISOString()); expect(result.wallet).toBeNull();
  });

  it("rejects fake NewAPI success shapes and invalid unlimited flags", () => {
    expect(() => service.parseNewapiBalance({ code: true, data: {} })).toThrow();
    expect(() => service.parseNewapiBalance({ ...newapi, data: { ...newapi.data, unlimited_quota: "true" } })).toThrow();
    expect(() => service.parseNewapiBalance({ code: false, data: newapi.data })).toThrow();
  });

  it("uses the trailing-slash NewAPI endpoint and existing strict proxy", async () => {
    const result = await service.getChannelBalances();
    expect(mocks.fetch).toHaveBeenCalledTimes(1);
    expect(mocks.fetch.mock.calls[0]).toMatchObject(["https://api.bxacc.xyz/api/usage/token/", { method: "GET", redirect: "manual" }, { strictProxy: true }]);
    expect(result.channels[0]).toMatchObject({ category: "publicWelfare", adapter: "newapi" });
    expect(result.channels[0].connections[0].keyQuota.unlimited).toBe(true);
  });

  it("uses Sub2API usage for XWR without inventing a wallet or querying models", async () => {
    mocks.nodes.mockResolvedValue([{ ...node, name: "XWR", prefix: "xwr", baseUrl: "https://api.xn--xwr.site/v1" }]);
    mocks.fetch.mockImplementation(async () => Response.json({ isValid: true, unit: "USD", remaining: 0.64 }));
    const result = await service.getChannelBalances();
    expect(mocks.fetch).toHaveBeenCalledTimes(1); expect(mocks.fetch.mock.calls[0][0]).toBe("https://api.xn--xwr.site/v1/usage");
    expect(result.channels[0]).toMatchObject({ name: "哲のAPI（XWR）", prefix: "xwr" });
    expect(result.channels[0].connections[0]).toMatchObject({ wallet: null, available: { amount: 0.64, source: "unknown" } });
  });

  it("normalizes modern Fengwind wallet, key limits and upstream channels independently", () => {
    const result = service.parseFengwindBalance(modern);
    expect(result.wallet).toEqual({ amount: 12.5, currency: "USD" }); expect(result.available).toBeNull();
    expect(result.limits.map(window => window.period)).toEqual(["total", "rolling5h"]);
    expect(result.channelFunding[0]).toMatchObject({ id: "7", source: "subscription", status: "available", expiresAt: "2026-10-16T00:00:00Z" });
    expect(result.channelFunding[0].windows[0]).toMatchObject({ period: "weekly", remaining: 20, resetsAt: "2026-10-02T00:00:00Z" });
    expect(result.channelFunding[1]).toMatchObject({ status: "unavailable", windows: [] });
    expect(result.today).toEqual({ currency: "USD", cost: 1.5, calls: 3, tokens: 123 });
    expect(JSON.stringify(result)).not.toMatch(/PRIVATE|SECRET-PASSWORD|internal/);
  });

  it("rejects unsupported Fengwind schema versions or missing wallet units", () => {
    expect(() => service.parseFengwindBalance({ ...modern, schema_version: 2 })).toThrow();
    expect(() => service.parseFengwindBalance({ ...modern, wallet: { balance: 3 } })).toThrow();
  });

  it("hides Fengwind upstream 503 without inventing a zero balance", async () => {
    mocks.nodes.mockResolvedValue([{ ...node, name: "Fengwind", baseUrl: "https://api.fengwind.com/v1" }]);
    mocks.fetch.mockImplementation(async () => Response.json({ error: { message: "sk-PRIVATE internal trace" } }, { status: 503 }));
    const result = await service.getChannelBalances();
    expect(result.channels).toEqual([]);
    expect(JSON.stringify(result)).not.toMatch(/PRIVATE|trace/);
  });

  it("does not treat the legacy hundred-million billing cap as an actual wallet", async () => {
    mocks.nodes.mockResolvedValue([{ ...node, name: "anyRoute", baseUrl: "https://anyrouter.top/v1" }]);
    mocks.fetch.mockImplementation(async () => Response.json({ object: "billing_subscription", hard_limit_usd: 100000000 }));
    const result = await service.getChannelBalances();
    expect(result.channels).toEqual([]);
    expect(JSON.stringify(result)).not.toContain("100000000");
  });

  it("hides unsupported and disabled nodes without sending keys", async () => {
    mocks.nodes.mockResolvedValue([{ ...node, baseUrl: "https://www.xmapi.cc/v1" }, { ...node, id: "unknown", baseUrl: "https://unknown.test/v1" }]);
    mocks.connections.mockResolvedValue([{ ...connection, isActive: false }, { ...connection, id: "unknown-key", provider: "unknown" }]);
    const result = await service.getChannelBalances();
    expect(result.channels).toEqual([]); expect(mocks.fetch).not.toHaveBeenCalled();
    expect(result.channelOptions).toHaveLength(2);
  });
});
