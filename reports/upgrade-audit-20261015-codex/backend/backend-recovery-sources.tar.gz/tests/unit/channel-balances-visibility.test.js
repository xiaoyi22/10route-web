import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({ nodes: vi.fn(), connections: vi.fn(), settings: vi.fn(), proxy: vi.fn(), fetch: vi.fn() }));
vi.mock("@/lib/localDb", () => ({ getProviderNodes: mocks.nodes, getProviderConnections: mocks.connections, getSettings: mocks.settings }));
vi.mock("@/lib/network/connectionProxy", () => ({ resolveConnectionProxyConfig: mocks.proxy }));
vi.mock("open-sse/utils/proxyFetch.js", () => ({ proxyAwareFetch: mocks.fetch }));

const nodes = [
  { id: "one", name: "BX", prefix: "bx", category: "publicWelfare", type: "openai-compatible", baseUrl: "https://api.bxacc.xyz/v1" },
  { id: "two", name: "PMCat", prefix: "pmcat", category: "publicWelfare", type: "openai-compatible", baseUrl: "https://pmcat.top/v1" },
];
const connections = nodes.map(node => ({ id: `${node.id}-key`, provider: node.id, authType: "apikey", isActive: true, name: "Main", apiKey: "sk-SECRET" }));
const quota = { code: true, data: { object: "token_usage", total_used: 3, total_available: 7, total_granted: 10, unlimited_quota: false } };
let service;

beforeEach(async () => {
  vi.resetModules(); vi.clearAllMocks();
  mocks.nodes.mockResolvedValue(nodes); mocks.connections.mockResolvedValue(connections); mocks.settings.mockResolvedValue({});
  mocks.proxy.mockResolvedValue({ strictProxy: true }); mocks.fetch.mockImplementation(async () => Response.json(quota));
  service = await import("../../src/lib/channelBalances.js");
});

afterEach(() => vi.useRealTimers());

describe("channel balance display and query preferences", () => {
  it("preserves the current default and returns safe selectable metadata", async () => {
    const result = await service.getChannelBalances();
    expect(result.channels).toHaveLength(2);
    expect(result.channelOptions).toEqual(nodes.map(node => ({ id: node.id, name: node.name, prefix: node.prefix, enabled: true, connectionCount: 1 })));
    expect(JSON.stringify(result.channelOptions)).not.toMatch(/apiKey|SECRET|baseUrl/);
  });

  it("omits a hidden channel before proxy resolution, upstream GET or cache access", async () => {
    mocks.settings.mockResolvedValue({ channelBalanceDisabledIds: ["one"] });
    const result = await service.getChannelBalances({ force: true });
    expect(result.channels.map(channel => channel.id)).toEqual(["two"]);
    expect(result.channelOptions[0]).toMatchObject({ id: "one", enabled: false });
    expect(mocks.fetch).toHaveBeenCalledTimes(1); expect(mocks.fetch.mock.calls[0][0]).toContain("pmcat.top");
    expect(mocks.proxy).toHaveBeenCalledTimes(1);
  });

  it("makes no requests when all channels are hidden and still permits re-enabling", async () => {
    mocks.settings.mockResolvedValue({ channelBalanceDisabledIds: ["one", "two"] });
    const result = await service.getChannelBalances({ force: true });
    expect(result.channels).toEqual([]); expect(result.channelOptions).toHaveLength(2);
    expect(result.channelOptions.every(option => !option.enabled)).toBe(true);
    expect(mocks.fetch).not.toHaveBeenCalled(); expect(mocks.proxy).not.toHaveBeenCalled();
  });

  it("metadata-only reads used for saving never query any upstream", async () => {
    const result = await service.getChannelBalances({ query: false });
    expect(result.channels).toEqual([]); expect(result.channelOptions).toHaveLength(2);
    expect(mocks.fetch).not.toHaveBeenCalled(); expect(mocks.proxy).not.toHaveBeenCalled();
  });

  it("does not return a hidden channel's previously cached amount", async () => {
    await service.getChannelBalances(); mocks.fetch.mockClear(); mocks.proxy.mockClear();
    mocks.settings.mockResolvedValue({ channelBalanceDisabledIds: ["one", "two"] });
    const result = await service.getChannelBalances();
    expect(result.channels).toEqual([]); expect(JSON.stringify(result)).not.toContain("keyQuota");
    expect(mocks.fetch).not.toHaveBeenCalled(); expect(mocks.proxy).not.toHaveBeenCalled();
  });

  it("treats stale node IDs and malformed saved lists safely without hiding new nodes", async () => {
    mocks.settings.mockResolvedValue({ channelBalanceDisabledIds: ["deleted-node", null, 1] });
    expect((await service.getChannelBalances()).channels).toHaveLength(2);
    mocks.settings.mockResolvedValue({ channelBalanceDisabledIds: "one" });
    expect((await service.getChannelBalances()).channelOptions.every(option => option.enabled)).toBe(true);
  });

  it("fails closed before querying when preferences cannot be read", async () => {
    mocks.settings.mockRejectedValue(new Error("settings DB unavailable"));
    await expect(service.getChannelBalances()).rejects.toThrow(); expect(mocks.fetch).not.toHaveBeenCalled();
  });

  it("hides failed connections while preserving successful keys in the same channel", async () => {
    mocks.connections.mockResolvedValue([...connections, { ...connections[0], id: "failed-key", apiKey: "sk-FAILED" }]);
    mocks.fetch.mockImplementation(async (url, options) => {
      if (options.headers.Authorization === "Bearer sk-FAILED") throw new Error("network unavailable");
      return url.includes("pmcat.top") ? Response.json({}, { status: 401 }) : Response.json(quota);
    });
    const result = await service.getChannelBalances();
    expect(result.channels.map(channel => channel.id)).toEqual(["one"]);
    expect(result.channels[0].connections.map(connection => connection.id)).toEqual(["one-key"]);
    expect(result.channelOptions).toHaveLength(2);
  });

  it("hides successful responses that contain no remaining balance or quota", async () => {
    mocks.fetch.mockImplementation(async () => Response.json({ code: true, data: { object: "token_usage", unlimited_quota: false } }));
    expect((await service.getChannelBalances()).channels).toEqual([]);
  });

  it.each([0, -3])("preserves a real remaining quota of %s", async (remaining) => {
    mocks.fetch.mockImplementation(async () => Response.json({ ...quota, data: { ...quota.data, total_available: remaining } }));
    const result = await service.getChannelBalances();
    expect(result.channels).toHaveLength(2);
    expect(result.channels[0].connections[0].keyQuota.remaining).toBe(remaining);
  });

  it("automatically restores a failed channel after a successful refresh", async () => {
    vi.useFakeTimers({ toFake: ["Date"] });
    mocks.fetch.mockImplementation(async () => Response.json({}, { status: 503 }));
    expect((await service.getChannelBalances()).channels).toEqual([]);
    mocks.fetch.mockImplementation(async () => Response.json(quota));
    vi.setSystemTime(Date.now() + 30001);
    expect((await service.getChannelBalances({ force: true })).channels).toHaveLength(2);
  });
});
