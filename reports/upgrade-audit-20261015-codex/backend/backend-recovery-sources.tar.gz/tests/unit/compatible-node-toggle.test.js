import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  getProviderConnections: vi.fn(),
  getProviderNodes: vi.fn(),
  getCombos: vi.fn(),
  getCustomModels: vi.fn(),
  getModelAliases: vi.fn(),
  getDisabledModels: vi.fn(),
}));

vi.mock("@/lib/localDb", () => ({
  getProviderConnections: mocks.getProviderConnections,
  getProviderNodes: mocks.getProviderNodes,
  getCombos: mocks.getCombos,
  getCustomModels: mocks.getCustomModels,
  getModelAliases: mocks.getModelAliases,
}));

vi.mock("@/lib/disabledModelsDb", () => ({
  getDisabledModels: mocks.getDisabledModels,
}));

const { buildModelsList } = await import("../../src/app/api/v1/models/route.js");

const LLM_KIND = "llm";
const NODE_ID = "openai-compatible-chat-843fd785-06f9-4403-9651-c621aee6de40";

describe("buildModelsList — compatible-node dashboard toggle must subtract (Fengwind regression)", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.getProviderNodes.mockResolvedValue([
      { id: NODE_ID, type: "openai-compatible", name: "Fengwind" },
    ]);
    mocks.getCombos.mockResolvedValue([]);
    mocks.getModelAliases.mockResolvedValue({});
    mocks.getDisabledModels.mockResolvedValue({});
    mocks.getProviderConnections.mockResolvedValue([
      {
        id: "conn-fw",
        provider: NODE_ID,
        authType: "apikey",
        isActive: true,
        apiKey: "sk-test",
        providerSpecificData: { baseUrl: "https://api.fengwind.com/v1", prefix: "fw", apiType: "chat" },
      },
    ]);
  });

  // The dashboard toggle writes customModels.enabled=false. The compatible
  // node's list comes from the upstream /models feed, which still reports the
  // disabled models — the engine must subtract the toggled-off rows or the
  // toggle is decorative and users cannot control what clients see.
  it("hides upstream models the user toggled off in the dashboard, keeps toggled-on ones", async () => {
    // Upstream reports all 6 models regardless of local toggles.
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ data: [
        { id: "deepseek-v4.1-flash" },
        { id: "glm-5.3-flash" },
        { id: "laguna-s-2.1" },
        { id: "muse-spark-1.3-contributor" },
        { id: "solar-pro4" },
        { id: "kimi-k3" },
      ] }), { status: 200 })
    );
    mocks.getCustomModels.mockResolvedValue([
      { providerAlias: NODE_ID, id: "deepseek-v4.1-flash", type: "llm", name: "deepseek-v4.1-flash", enabled: true },
      { providerAlias: NODE_ID, id: "glm-5.3-flash", type: "llm", name: "glm-5.3-flash", enabled: true },
      { providerAlias: NODE_ID, id: "muse-spark-1.3-contributor", type: "llm", name: "muse-spark-1.3-contributor", enabled: true },
      { providerAlias: NODE_ID, id: "kimi-k3", type: "llm", name: "kimi-k3", enabled: true },
      { providerAlias: NODE_ID, id: "laguna-s-2.1", type: "llm", name: "laguna-s-2.1", enabled: false },
      { providerAlias: NODE_ID, id: "solar-pro4", type: "llm", name: "solar-pro4", enabled: false },
    ]);

    const ids = (await buildModelsList([LLM_KIND])).map((m) => m.id);

    expect(ids).toContain("fw/deepseek-v4.1-flash");
    expect(ids).toContain("fw/glm-5.3-flash");
    expect(ids).toContain("fw/muse-spark-1.3-contributor");
    expect(ids).toContain("fw/kimi-k3");
    expect(ids).not.toContain("fw/laguna-s-2.1");
    expect(ids).not.toContain("fw/solar-pro4");
  });

  it("leaves upstream models untouched when the node has no custom model rows at all", async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ data: [{ id: "a" }, { id: "b" }] }), { status: 200 })
    );
    mocks.getCustomModels.mockResolvedValue([]);

    const ids = (await buildModelsList([LLM_KIND])).map((m) => m.id);
    expect(ids).toContain("fw/a");
    expect(ids).toContain("fw/b");
  });

  it("treats legacy rows without an explicit enabled flag as enabled", async () => {
    global.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ data: [{ id: "a" }] }), { status: 200 })
    );
    mocks.getCustomModels.mockResolvedValue([
      { providerAlias: NODE_ID, id: "a", type: "llm", name: "a" },
    ]);

    const ids = (await buildModelsList([LLM_KIND])).map((m) => m.id);
    expect(ids).toContain("fw/a");
  });

  it("fetches compatible provider catalogs concurrently", async () => {
    const secondNodeId = "openai-compatible-chat-test-node";
    mocks.getProviderNodes.mockResolvedValue([
      { id: NODE_ID, type: "openai-compatible", name: "Fengwind" },
      { id: secondNodeId, type: "openai-compatible", name: "Second" },
    ]);
    mocks.getProviderConnections.mockResolvedValue([
      {
        id: "conn-fw",
        provider: NODE_ID,
        authType: "apikey",
        isActive: true,
        apiKey: "sk-test",
        providerSpecificData: { baseUrl: "https://api.fengwind.com/v1", prefix: "fw", apiType: "chat" },
      },
      {
        id: "conn-second",
        provider: secondNodeId,
        authType: "apikey",
        isActive: true,
        apiKey: "sk-test-second",
        providerSpecificData: { baseUrl: "https://second.example/v1", prefix: "second", apiType: "chat" },
      },
    ]);
    mocks.getCustomModels.mockResolvedValue([]);

    let activeRequests = 0;
    let maxConcurrentRequests = 0;
    global.fetch = vi.fn((input) => {
      activeRequests += 1;
      maxConcurrentRequests = Math.max(maxConcurrentRequests, activeRequests);
      const modelId = String(input).includes("second.example") ? "second-model" : "first-model";
      return new Promise((resolve) => {
        setTimeout(() => {
          activeRequests -= 1;
          resolve(new Response(JSON.stringify({ data: [{ id: modelId }] }), { status: 200 }));
        }, 20);
      });
    });

    const ids = (await buildModelsList([LLM_KIND])).map((model) => model.id);

    expect(maxConcurrentRequests).toBe(2);
    expect(ids).toEqual(expect.arrayContaining(["fw/first-model", "second/second-model"]));
  });
});
