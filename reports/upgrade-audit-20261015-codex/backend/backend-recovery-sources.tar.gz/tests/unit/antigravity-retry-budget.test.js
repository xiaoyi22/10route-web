import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

let testApi;
try { testApi = await import("vitest"); }
catch (error) {
  if (error.code !== "ERR_MODULE_NOT_FOUND") throw error;
  testApi = await import("node:test");
}
const { describe, it, beforeEach, afterEach } = testApi;

// Offline isolation BEFORE importing the real entry/DB (same pattern as antigravity-p0-fix1).
const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "10router-ag-budget-"));
process.env.DATA_DIR = tempDir;
let fetchLog = [];
let mockFetch = async url => { throw new Error(`Unexpected offline fetch: ${url}`); };
globalThis.fetch = (...args) => mockFetch(...args);

const repo = await import("../../src/lib/db/repos/connectionsRepo.js");
const { updateSettings } = await import("../../src/lib/db/repos/settingsRepo.js");
const { resetQuarantineMemory } = await import("../../open-sse/services/antigravityQuarantine.js");
const { handleChat } = await import("../../src/sse/handlers/chat.js");
const { handleChatCore } = await import("../../open-sse/handlers/chatCore.js");
const { BaseExecutor } = await import("../../open-sse/executors/base.js");
const { AntigravityExecutor } = await import("../../open-sse/executors/antigravity.js");
const budgetMod = await import("../../open-sse/utils/agRequestBudget.js");
const { createAgRequestBudget, isAgRequestBudgetExhausted } = budgetMod;

const MODEL = "gemini-3.8-flash-high";
const log = { info() {}, warn() {}, error() {}, debug() {} };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const genResponse = (status, message) => Response.json({ error: { message } }, { status });
function request(model) {
  return new Request("http://offline.invalid/v1/chat/completions", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model, stream: false, messages: [{ role: "user", content: "offline retry budget" }] }),
  });
}
async function account(name, priority) {
  return repo.createProviderConnection({ provider: "antigravity", authType: "oauth", name, priority,
    email: `${name}@example.invalid`, accessToken: `token-${name}`, refreshToken: `refresh-${name}`,
    projectId: `project-${name}`, expiresAt: new Date(Date.now() + 3600000).toISOString(), isActive: true });
}
const isOauth = entry => entry.url.includes("oauth2");
const genCalls = () => fetchLog.filter(e => !isOauth(e));

// a) and d) exercise the real backoff sleep (capped at 15s by design), so the
// 5s vitest default is structurally too small — pin this file at 30s per test.
describe("AG P1-1 unified request retry budget (offline)", { timeout: 30000 }, () => {
  beforeEach(async () => {
    resetQuarantineMemory();
    repo.registerQuarantinePersistenceHandler();
    fetchLog = [];
    mockFetch = async url => { throw new Error(`Unexpected offline fetch: ${url}`); };
    for (const c of await repo.getProviderConnections()) await repo.deleteProviderConnection(c.id);
    await updateSettings({ requireApiKey: false, rtkEnabled: false, headroomEnabled: false,
      pxpipeEnabled: false, outboundProxyEnabled: false, comboStrategies: {},
      providerStrategies: { antigravity: { fallbackStrategy: "round-robin", stickyRoundRobinLimit: 1, earliestExpiryFirst: false } } });
  });
  afterEach(() => resetQuarantineMemory());

  // a) Three 429s on account #1 consume the generation cap; account fallback then
  //    pays the credential cap and the executor refuses its HTTP entirely.
  it("a: generation cap halts cross-account sequence with zero HTTP on refused account", async () => {
    await account("a1", 1);
    await account("a2", 2);
    const queue = [
      () => genResponse(429, "quota exhausted"),
      () => genResponse(429, "quota exhausted"),
      () => genResponse(429, "quota exhausted"),
      () => { throw new Error(`Budget must refuse a 4th generation HTTP call`); },
    ];
    mockFetch = async (url, options) => {
      const entry = { url: String(url), auth: options?.headers?.Authorization };
      fetchLog.push(entry);
      if (isOauth(entry)) return Response.json({ access_token: "token-a2-refreshed", expires_in: 1 });
      const next = queue.shift();
      if (!next) throw new Error("Unexpected extra generation call beyond the scripted sequence");
      return next();
    };
    const response = await handleChat(request(`ag/${MODEL}`));
    assert.equal(response.status, 503);
    const body = await response.json();
    assert.match(body.error.message, /budget exhausted/i);
    assert.match(body.error.message, /retry/i);
    // a1's 429 retry loop (registry attempts:3) is gated by the generation cap
    // INSIDE the executor: attempt #4 is refused with zero HTTP, chatCore marks
    // the result budgetExhausted, and the account loop halts before a2 is ever
    // selected — no refresh, no second credential. One logical request can
    // never exceed 3 upstream generations, retries included.
    assert.equal(body.error.budget.generationAttempts, 3, "Exactly 3 upstream generation HTTP calls");
    assert.equal(body.error.budget.refreshAttempts, 0, "halt happens before any refresh");
    assert.equal(body.error.budget.credentialsTried, 1, "second account never selected");
    const gens = genCalls();
    assert.equal(gens.length, 3);
    assert.ok(gens.every(g => g.url.includes("/v1internal:generateContent")));
    assert.deepEqual(gens.map(g => g.auth), ["Bearer token-a1", "Bearer token-a1", "Bearer token-a1"]);
    assert.ok(!gens.some(g => g.auth === "Bearer token-a2"), "a2 generation refused: no HTTP with the second credential");
    assert.equal(fetchLog.filter(isOauth).length, 0);
    await sleep(50);
    assert.equal(fetchLog.length, 3, "No trailing HTTP after the budget error returned");
  });

  // b) Once the budget is exhausted, an execute() attempt must send zero HTTP.
  it("b: exhausted budget refuses generation with zero HTTP and a budget body", async () => {
    const conn = await account("b1", 1);
    const budget = createAgRequestBudget();
    for (let i = 0; i < 3; i++) assert.equal(budget.countGeneration(), true);
    assert.equal(budget.countGeneration(), false);
    fetchLog = [];
    mockFetch = async (url) => { fetchLog.push({ url: String(url) }); return genResponse(200, "should-not-run"); };
    const executor = new AntigravityExecutor();
    const { response } = await executor.execute({ model: MODEL, body: {}, stream: false,
      credentials: { ...conn }, signal: undefined, log, agRequestBudget: budget });
    assert.equal(fetchLog.length, 0, "Budget-exhausted execute must not touch the network");
    assert.equal(response.status, 503);
    assert.equal(response.budgetExhausted, true);
    const body = await response.json();
    assert.match(body.error.message, /budget exhausted/i);
    assert.equal(body.error.budget.generationAttempts, 3);
    await sleep(50);
    assert.equal(fetchLog.length, 0, "Fetch count must stay frozen after exhaustion");
  });

  // c) Two accounts in one request: the budget accumulates across account switches,
  //    it does not reset per account, and the third credential is never tried.
  it("c: budget accumulates across account switches (no per-account reset, no 3rd credential)", async () => {
    await account("c1", 1);
    await account("c2", 2);
    await account("c3", 3);
    // A plain AG 403 (non-TOS) returns immediately without executor retries, so
    // each credential costs exactly one generation attempt: the credential cap
    // (2) must stop the pool walk before c3 is ever selected.
    mockFetch = async (url, options) => {
      fetchLog.push({ url: String(url), auth: options?.headers?.Authorization });
      return genResponse(403, "permission denied");
    };
    const response = await handleChat(request(`ag/${MODEL}`));
    assert.equal(response.status, 503);
    const body = await response.json();
    assert.match(body.error.message, /budget exhausted/i);
    assert.equal(body.error.budget.credentialsTried, 2);
    assert.equal(genCalls().length, 2, "Both accounts share one budget: exactly 2 generation calls total");
    assert.ok(!genCalls().some(g => g.auth === "Bearer token-c3"), "Third credential must never be contacted");
    assert.ok(!fetchLog.some(e => isOauth(e)), "plain 403 must not trigger refresh");
  });

  // d) Client abort during a budgeted backoff wait: terminate immediately,
  //    freeze counts, no further fetches.
  it("d: abort during budget backoff sleep stops immediately and freezes counters", async () => {
    const conn = await account("d1", 1);
    const budget = createAgRequestBudget();
    const ac = new AbortController();
    mockFetch = async (url, options) => {
      fetchLog.push({ url: String(url), auth: options?.headers?.Authorization });
      return genResponse(500, "upstream high traffic");
    };
    const executor = new AntigravityExecutor();
    const t0 = Date.now();
    setTimeout(() => ac.abort(), 150);
    const pending = executor.execute({ model: MODEL, body: {}, stream: false,
      credentials: { ...conn }, signal: ac.signal, log, agRequestBudget: budget });
    await assert.rejects(pending, (err) => err.name === "AbortError", "AbortError must propagate out of the wait");
    const elapsed = Date.now() - t0;
    assert.ok(elapsed < 1000, `Must not sleep out the 2000ms backoff after abort (took ${elapsed}ms)`);
    await sleep(2200);
    assert.equal(genCalls().length, 1, "No generation after the aborted wait");
    assert.equal(budget.snapshot().generationAttempts, 1, "Generation counter frozen");
    assert.equal(budget.snapshot().waitMs, 0, "Interrupted wait is not charged to the budget");
  });

  // e) Non-AG path with a budget object present must behave exactly like baseline:
  //    openai 403 keeps 3 refresh attempts; base executor keeps 502 retries even
  //    against an exhausted wait budget; the budget object itself stays untouched.
  it("e: non-AG (openai) ignores the budget and matches baseline exactly", async () => {
    const budget = createAgRequestBudget();
    let refreshes = 0;
    const result = await handleChatCore({
      body: { model: "openai/gpt-4o", stream: false, messages: [{ role: "user", content: "offline" }] },
      modelInfo: { provider: "openai", model: "gpt-4o" },
      credentials: { id: "offline-openai", accessToken: "old" },
      connectionId: "offline-openai",
      _executorOverride: { noAuth: false,
        execute: async () => ({ response: new Response("forbidden", { status: 403 }), url: "https://offline.invalid" }),
        refreshCredentials: async () => { refreshes++; return null; } },
      agRequestBudget: budget,
    });
    assert.equal(refreshes, 3, "openai 403 keeps the baseline 3 refresh attempts");
    assert.equal(result.status, 403);
    assert.notEqual(result.budgetExhausted, true);
    assert.deepEqual(budget.snapshot(), { generationAttempts: 0, refreshAttempts: 0, waitMs: 0, credentialsTried: 0, exhaustedReason: null });

    // Executor level: non-AG transient retries must not be gated by an exhausted wait budget.
    let baseFetches = 0;
    mockFetch = async () => { baseFetches++; throw new Error("offline network failure"); };
    const plain = new BaseExecutor("openai", { baseUrls: ["https://openai-offline.invalid/v1"], retry: { 502: { attempts: 2, delayMs: 5 } } });
    const starved = createAgRequestBudget({ maxTotalWaitMs: 1 });
    starved.spendWait(1);
    await assert.rejects(plain.execute({ model: "gpt-4o", body: {}, stream: false,
      credentials: { accessToken: "x" }, signal: undefined, log, agRequestBudget: starved }));
    assert.equal(baseFetches, 3, "Baseline 1+2 attempts preserved for non-AG without an environment proxy");
    assert.equal(starved.snapshot().generationAttempts, 0, "Budget counters untouched on non-AG execution");
  });

  // f) Once the response body (stream) has started flowing, a mid-stream failure
  //    terminates only: no replay, no extra generation calls.
  it("f: mid-stream failure after first byte never replays or adds generation calls", async () => {
    const conn = await account("f1", 1);
    const budget = createAgRequestBudget();
    mockFetch = async (url) => {
      fetchLog.push({ url: String(url) });
      const stream = new ReadableStream({
        start(controller) {
          controller.enqueue(new TextEncoder().encode('data: {"candidates":[{"content":{"parts":[{"text":"hi"}],"role":"model"},"finishReason":"STOP"}]}\n\n'));
          setTimeout(() => controller.error(new Error("torn mid-stream")), 10);
        },
      });
      return new Response(stream, { status: 200, headers: { "content-type": "text/event-stream" } });
    };
    const executor = new AntigravityExecutor();
    const { response } = await executor.execute({ model: MODEL, body: {}, stream: true,
      credentials: { ...conn }, signal: undefined, log, agRequestBudget: budget });
    assert.equal(response.status, 200);
    const reader = response.body.getReader();
    const first = await reader.read();
    assert.equal(first.done, false, "First byte must have been emitted");
    assert.ok(new TextDecoder().decode(first.value).includes("hi"));
    await assert.rejects(reader.read(), /torn mid-stream/i);
    await sleep(50);
    assert.equal(genCalls().length, 1, "No replay fetch after output started");
    assert.equal(budget.snapshot().generationAttempts, 1, "Generation counter frozen at the started call");
    assert.equal(isAgRequestBudgetExhausted(budget), false);
  });
});
