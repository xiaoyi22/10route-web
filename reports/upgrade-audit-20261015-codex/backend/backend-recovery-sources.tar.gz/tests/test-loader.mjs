import { register } from "node:module";
import { pathToFileURL } from "node:url";
import path from "node:path";

const hookUrl = pathToFileURL(path.resolve("tests/test-hooks.mjs")).href;
register(hookUrl, import.meta.url);
