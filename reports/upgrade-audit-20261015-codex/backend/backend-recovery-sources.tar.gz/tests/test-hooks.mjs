import path from "node:path";
import fs from "node:fs";
import { pathToFileURL } from "node:url";

const rootDir = process.cwd();

function tryAppendExt(filePath) {
  if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) return filePath;
  if (fs.existsSync(filePath + ".js") && fs.statSync(filePath + ".js").isFile()) return filePath + ".js";
  if (fs.existsSync(path.join(filePath, "index.js")) && fs.statSync(path.join(filePath, "index.js")).isFile()) {
    return path.join(filePath, "index.js");
  }
  return filePath;
}

export async function resolve(specifier, context, nextResolve) {
  if (specifier === "next/server") return nextResolve("next/server.js", context);
  if (specifier.startsWith("@/")) {
    const subpath = specifier.slice(2);
    const resolvedPath = tryAppendExt(path.join(rootDir, "src", subpath));
    return nextResolve(pathToFileURL(resolvedPath).href, context);
  }
  if (specifier === "open-sse") {
    const resolvedPath = path.join(rootDir, "open-sse", "index.js");
    return nextResolve(pathToFileURL(resolvedPath).href, context);
  }
  if (specifier.startsWith("open-sse/")) {
    const subpath = specifier.slice(9);
    const resolvedPath = tryAppendExt(path.join(rootDir, "open-sse", subpath));
    return nextResolve(pathToFileURL(resolvedPath).href, context);
  }
  if (specifier.startsWith("./") || specifier.startsWith("../")) {
    if (context.parentURL && context.parentURL.startsWith("file://")) {
      const parentDir = path.dirname(new URL(context.parentURL).pathname);
      const targetPath = path.resolve(parentDir, specifier);
      const withExt = tryAppendExt(targetPath);
      if (withExt !== targetPath) {
        return nextResolve(pathToFileURL(withExt).href, context);
      }
    }
  }
  return nextResolve(specifier, context);
}
