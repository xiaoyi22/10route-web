import { getModelInfo } from "./model.js";
import { getDistribution, isDistributed } from "@/lib/distributionDb";
import { errorResponse } from "open-sse/utils/error.js";
import { HTTP_STATUS } from "open-sse/config/runtimeConfig.js";

/**
 * Enforce the downstream distribution allowlist for a non-chat modality
 * (image / video / audio / search / web …).
 *
 * `handleChat` enforces the same rule for every chat-shaped protocol. The
 * separate modality handlers do not route through it, so they call this instead
 * — otherwise a model the operator unpublished would still be callable by id
 * from an image or video request.
 *
 * Returns a Response to send back when the model is NOT published, or null when
 * the request may proceed (including the default "all" mode).
 */
export async function enforceDistribution(modelStr, tag = "DIST") {
  const distribution = await getDistribution();
  if (distribution.mode !== "allowlist") return null;
  if (typeof modelStr !== "string" || modelStr.trim() === "") return null;

  if (isDistributed(modelStr, distribution)) return null;

  // Accept the bare upstream id spelling as well as the full "<alias>/<model>"
  // route id /v1/models publishes, so both forms resolve to the same entry.
  try {
    const info = await getModelInfo(modelStr, { inferFallback: false });
    if (info?.provider && info?.model) {
      if (isDistributed(`${info.provider}/${info.model}`, distribution)) return null;
      if (isDistributed(`${modelStr.split("/")[0]}/${info.model}`, distribution)) return null;
    }
  } catch {
    /* fall through to the refusal below */
  }

  return errorResponse(
    HTTP_STATUS.NOT_FOUND,
    `Model "${modelStr}" is not available. The gateway publishes a restricted model list; see the dashboard's 下游分发 settings.`
  );
}
