import { getChannelBalances } from "@/lib/channelBalances.js";
import { setChannelBalanceEnabled } from "@/lib/localDb";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request) {
  const headers = { "Cache-Control": "private, no-store" };
  try {
    const parameters = new URL(request.url).searchParams;
    if (parameters.get("preferences") === "1") return Response.json(await getChannelBalances({ query: false }), { headers });
    const force = parameters.get("force") === "1";
    return Response.json(await getChannelBalances({ force }), { headers });
  } catch {
    return Response.json({ error: "Unable to load channel balances" }, { status: 500, headers });
  }
}

export async function PATCH(request) {
  const headers = { "Cache-Control": "private, no-store" };
  let body;
  try { body = await request.json(); } catch {
    return Response.json({ error: "Invalid channel balance preference" }, { status: 400, headers });
  }
  if (!body || Array.isArray(body) || typeof body !== "object" || Object.keys(body).some(key => !["channelId", "enabled"].includes(key)) || typeof body.channelId !== "string" || !body.channelId.trim() || body.channelId.length > 128 || typeof body.enabled !== "boolean") {
    return Response.json({ error: "Invalid channel balance preference" }, { status: 400, headers });
  }
  try {
    const current = await getChannelBalances({ query: false });
    if (!current.channelOptions.some(channel => channel.id === body.channelId)) return Response.json({ error: "Channel not found" }, { status: 404, headers });
    await setChannelBalanceEnabled(body.channelId, body.enabled);
    return Response.json(await getChannelBalances({ query: false }), { headers });
  } catch {
    return Response.json({ error: "Unable to save channel visibility" }, { status: 500, headers });
  }
}
