import { NextResponse } from "next/server";
import { verifyDashboardPassword } from "@/lib/auth/dashboardSession";
import { checkLock, recordFail, recordSuccess, getClientIp } from "@/lib/auth/loginLimiter";

/**
 * POST /api/auth/verify-password
 * Lightweight dashboard-password check for UI flows that gate on it BEFORE
 * the real action (e.g. the OAuth transfer export confirm step) — so a wrong
 * password errors in the dialog where it was typed, not two steps later.
 * Same exposure class as /api/auth/login; the response leaks nothing but ok.
 */
export async function POST(request) {
  const ip = getClientIp(request);
  const lock = checkLock(ip);
  if (lock.locked) {
    return NextResponse.json(
      { ok: false, error: `Too many failed attempts. Try again in ${lock.retryAfter}s.` },
      { status: 429, headers: { "Retry-After": String(lock.retryAfter) } },
    );
  }

  try {
    const { password } = await request.json();
    const ok = await verifyDashboardPassword(typeof password === "string" ? password : null);
    if (!ok) {
      recordFail(ip);
      return NextResponse.json({ ok: false, error: "Invalid password" }, { status: 401 });
    }
    recordSuccess(ip);
    return NextResponse.json({ ok: true });
  } catch {
    recordFail(ip);
    return NextResponse.json({ ok: false, error: "Invalid request" }, { status: 400 });
  }
}
