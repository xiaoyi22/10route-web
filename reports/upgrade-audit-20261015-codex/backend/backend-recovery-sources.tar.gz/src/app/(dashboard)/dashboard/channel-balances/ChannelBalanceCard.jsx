"use client";

import React from "react";
import Card from "@/shared/components/Card";
import { translate } from "@/i18n/runtime";

const periodLabels = { hourly: "Hourly", daily: "Daily", weekly: "Weekly", monthly: "Monthly", rolling5h: "5-hour window", total: "Key total limit" };
const statusLabels = { ok: "Available", partial: "Partial data", error: "Query failed", disabled: "Disabled", unverified: "Balance unconfirmed", unsupported: "Not yet supported", login_required: "Website login required" };
const sourceLabels = {
  balance: "Available wallet balance",
  subscription: "Subscription available",
  subscription_then_balance: "Subscription and wallet available",
  balance_then_subscription: "Wallet and subscription available",
  none: "No available funding",
  unknown: "Available amount",
};

export function formatChannelMoney(amount, currency) {
  if (typeof amount !== "number" || !Number.isFinite(amount)) return "—";
  return `${new Intl.NumberFormat(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(amount)} ${currency}`;
}

function dateTime(value) {
  return value && Number.isFinite(Date.parse(value)) ? new Date(value).toLocaleString() : "—";
}

export function formatChannelBalanceError(message) {
  return String(message || "").split("; ").map((part) => {
    const match = /^Balance query returned HTTP (\d{3})$/.exec(part);
    return match ? `${translate("Balance query returned HTTP")} ${match[1]}` : translate(part);
  }).join("; ");
}

function formatRawQuota(amount) {
  return typeof amount === "number" && Number.isFinite(amount) ? `${new Intl.NumberFormat(undefined, { maximumFractionDigits: 6 }).format(amount)} ${translate("quota units")}` : "—";
}

function KeyQuota({ quota }) {
  return (
    <div className="space-y-1.5">
      <p className="text-xs text-text-muted">{translate("Key quota")}</p>
      <p className="text-xl font-semibold tabular-nums text-text-main">{quota.unlimited ? translate("Unlimited key quota") : formatRawQuota(quota.remaining)}</p>
      <p className="text-xs text-text-muted">{translate("Used")}: {formatRawQuota(quota.used)}{!quota.unlimited ? ` · ${translate("Total")}: ${formatRawQuota(quota.limit)}` : ""}</p>
      <p className="text-xs text-text-muted">{translate("Key quota is not wallet balance; site-level limits may still apply")}</p>
    </div>
  );
}

function WindowRow({ window, keyLimit = false }) {
  const percentage = window.limit > 0 && typeof window.remaining === "number" ? Math.min(100, Math.max(0, window.remaining / window.limit * 100)) : null;
  return (
    <div className="space-y-1.5 rounded-lg bg-bg-alt/50 p-3">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <span className="text-xs font-medium text-text-muted">{keyLimit ? `${translate("Key limit")} · ` : ""}{translate(periodLabels[window.period] || window.period)}</span>
        <span className="text-sm font-semibold tabular-nums text-text-main">{formatChannelMoney(window.remaining, window.currency)}</span>
      </div>
      <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-text-muted">
        <span>{translate("Used")}: {formatChannelMoney(window.used, window.currency)}</span>
        <span>{translate("Total")}: {formatChannelMoney(window.limit, window.currency)}</span>
      </div>
      {percentage !== null && <progress aria-label={translate("Remaining")} value={percentage} max="100" className="h-1.5 w-full accent-primary" />}
      {window.resetsAt && <p className="text-xs text-text-muted">{translate("Resets at")}: <time dateTime={window.resetsAt}>{dateTime(window.resetsAt)}</time></p>}
    </div>
  );
}

export default function ChannelBalanceCard({ channel }) {
  return (
    <Card padding="sm" className="min-w-0 space-y-4 self-start">
      <div className="flex min-w-0 items-center justify-between gap-3 border-b border-border pb-3">
        <div className="min-w-0">
          <h2 className="truncate text-base font-semibold text-text-main">{channel.name}</h2>
          <p className="text-xs text-text-muted">{translate("Channel balances")}{channel.prefix ? ` · ${channel.prefix}/` : ""}</p>
          {["publicWelfare", "relay"].includes(channel.category) && <p className="mt-1 text-[11px] text-text-muted">{translate(channel.category === "publicWelfare" ? "Public welfare" : "Relay")}</p>}
        </div>
        <span className="material-symbols-outlined text-primary" aria-hidden="true">account_balance_wallet</span>
      </div>

      <div className="space-y-3">
        {channel.connections.map((connection) => (
          <section key={connection.id} className="min-w-0 rounded-xl border border-border p-3" aria-label={connection.name}>
            <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
              <h3 className="min-w-0 break-words text-sm font-medium text-text-main">{connection.name}</h3>
              <span className={`text-xs ${["error", "partial", "unverified", "unsupported", "login_required"].includes(connection.status) ? "text-amber-700 dark:text-amber-400" : "text-text-muted"}`}>{translate(statusLabels[connection.status] || "Not yet supported")}</span>
            </div>
            {connection.status === "disabled" && <p className="text-xs text-text-muted">{translate("Disabled connections are not queried")}</p>}
            {connection.status !== "disabled" && (
              <>
                {connection.keyQuota ? <KeyQuota quota={connection.keyQuota} /> : <>
                  <p className="text-xs text-text-muted">{translate(connection.wallet || connection.walletUnavailable ? "Wallet balance" : sourceLabels[connection.available?.source] || "Available amount")}</p>
                  {!connection.wallet && connection.walletUnavailable ? <>
                    <p className="mt-1 text-sm font-medium text-text-muted">{translate("Not returned by the API")}</p>
                    {connection.available && <div className="mt-3 space-y-1">
                      <p className="text-xs text-text-muted">{translate(sourceLabels[connection.available.source] || "Available amount")}</p>
                      <p className="text-xl font-semibold tabular-nums text-text-main">{formatChannelMoney(connection.available.amount, connection.available.currency)}</p>
                    </div>}
                  </> : <p className="mt-1 text-2xl font-semibold tabular-nums text-text-main">{formatChannelMoney(connection.wallet?.amount ?? connection.available?.amount, connection.wallet?.currency || connection.available?.currency)}</p>}
                </>}
                {!connection.wallet && connection.available?.source === "subscription" && <p className="mt-1 text-xs text-text-muted">{translate("Subscription credit, not wallet balance")}</p>}
                {connection.today && <p className="mt-2 text-xs text-text-muted">{translate("Today's key usage")}: {formatChannelMoney(connection.today.cost, connection.today.currency)}{connection.today.calls !== null ? ` · ${connection.today.calls} ${translate("requests")}` : ""}</p>}
                {connection.limits?.length > 0 && <div className="mt-3 space-y-2">{connection.limits.map((window) => <WindowRow key={window.period} window={window} keyLimit />)}</div>}
                {connection.channelFunding?.length > 0 && <div className="mt-3 space-y-3 border-t border-border pt-3">
                  <h4 className="text-xs font-semibold text-text-main">{translate("Upstream channel funding")}</h4>
                  {connection.channelFunding.map(funding => <div key={funding.id} className="space-y-2">
                    <p className="break-words text-xs text-text-muted">{funding.name || `${translate("Upstream channel funding")} #${funding.id}`} · {translate(funding.status === "unavailable" ? "Upstream channel unavailable" : sourceLabels[funding.source] || "Available amount")}</p>
                    {funding.windows.map(window => <WindowRow key={window.period} window={window} />)}
                    {funding.expiresAt && <p className="text-xs text-text-muted">{translate("Subscription expires")}: <time dateTime={funding.expiresAt}>{dateTime(funding.expiresAt)}</time></p>}
                  </div>)}
                </div>}
                {connection.keyExpiresAt && <p className="mt-2 text-xs text-text-muted">{translate("Key expires")}: <time dateTime={connection.keyExpiresAt}>{dateTime(connection.keyExpiresAt)}</time></p>}
                {connection.notice && !connection.keyQuota && <p className="mt-2 text-xs text-text-muted">{translate(connection.notice)}</p>}
                {connection.balanceUrl && <a href={connection.balanceUrl} target="_blank" rel="noopener noreferrer" className="mt-2 inline-flex items-center gap-1 text-xs text-primary hover:underline">{translate("View account balance")}<span className="material-symbols-outlined text-sm" aria-hidden="true">open_in_new</span></a>}
                {connection.stale && <p role="status" className="mt-2 text-xs text-amber-700 dark:text-amber-400">{translate("Showing the previous snapshot; amounts may be stale")}</p>}
                {connection.error && <p role="status" className="mt-2 break-words rounded-lg bg-amber-500/10 px-2 py-1.5 text-xs text-amber-700 dark:text-amber-400">{formatChannelBalanceError(connection.error)}</p>}
                {connection.checkedAt && <p className="mt-2 text-[11px] text-text-muted">{translate("Checked at")}: <time dateTime={connection.checkedAt}>{dateTime(connection.checkedAt)}</time>{connection.cached ? ` · ${translate("Cached")}` : ""}</p>}
              </>
            )}
          </section>
        ))}
      </div>

      {channel.subscriptions?.length > 0 && (
        <section className="space-y-3 border-t border-border pt-3" aria-label={translate("Channel subscriptions")}>
          <h3 className="text-sm font-semibold text-text-main">{translate("Channel subscriptions")}</h3>
          {channel.subscriptions.map((subscription, index) => (
            <div key={subscription.id || index} className="space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <span className="font-medium text-text-main">{subscription.name || translate("Subscription")}</span>
                {subscription.connectionIds.length > 1 && <span className="text-text-muted">{translate("Shared across")} {subscription.connectionIds.length} {translate("connections")}</span>}
              </div>
              {subscription.windows.length ? subscription.windows.map((window) => <WindowRow key={window.period} window={window} />) : <p className="text-xs text-text-muted">{translate("No period limits returned; this does not mean zero or unlimited")}</p>}
              {subscription.expiresAt && <p className="text-xs text-text-muted">{translate("Subscription expires")}: <time dateTime={subscription.expiresAt}>{dateTime(subscription.expiresAt)}</time></p>}
            </div>
          ))}
        </section>
      )}
    </Card>
  );
}
