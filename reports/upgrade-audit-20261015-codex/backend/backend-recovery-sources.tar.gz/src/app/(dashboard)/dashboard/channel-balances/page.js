"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Button from "@/shared/components/Button";
import Card from "@/shared/components/Card";
import { translate } from "@/i18n/runtime";
import ChannelBalanceCard, { formatChannelBalanceError } from "./ChannelBalanceCard";
import ChannelBalanceControls, { applyChannelOptions } from "./ChannelBalanceControls";

export default function ChannelBalancesPage() {
  const [snapshot, setSnapshot] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const pending = useRef(null);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState(null);
  const savePending = useRef(null);

  const refresh = useCallback(async (force = false) => {
    if (pending.current || savePending.current) return;
    const controller = new AbortController();
    pending.current = controller;
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(`/api/channel-balances${force ? "?force=1" : ""}`, { cache: "no-store", signal: controller.signal });
      if (!response.ok) throw new Error(response.status === 401 ? "Sign in to view channel balances" : "Unable to load channel balances");
      const data = await response.json();
      if (!Array.isArray(data.channels) || !Array.isArray(data.channelOptions)) throw new Error("Unable to load channel balances");
      if (!controller.signal.aborted) setSnapshot(data);
    } catch (failure) {
      if (!controller.signal.aborted) setError(failure.message);
    } finally {
      if (pending.current === controller) {
        pending.current = null;
        if (!controller.signal.aborted) setLoading(false);
      }
    }
  }, []);

  const changeVisibility = useCallback(async (channelId, enabled) => {
    if (savePending.current) return;
    pending.current?.abort();
    pending.current = null;
    const controller = new AbortController();
    savePending.current = controller;
    setSaving(true);
    setLoading(false);
    setSaveError(null);
    let saved = false;
    try {
      const response = await fetch("/api/channel-balances", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ channelId, enabled }), signal: controller.signal });
      if (!response.ok) throw new Error(response.status === 401 ? "Sign in to view channel balances" : "Unable to save channel visibility");
      const data = await response.json();
      if (!Array.isArray(data.channelOptions)) throw new Error("Unable to save channel visibility");
      if (!controller.signal.aborted) {
        setSnapshot(current => applyChannelOptions(current, data.channelOptions));
        saved = true;
      }
    } catch (failure) {
      if (!controller.signal.aborted) setSaveError(failure.message);
    } finally {
      if (savePending.current === controller) {
        savePending.current = null;
        if (!controller.signal.aborted) setSaving(false);
      }
    }
    if (saved && enabled) await refresh();
  }, [refresh]);

  useEffect(() => {
    const initial = setTimeout(() => refresh(), 0);
    const timer = setInterval(() => { if (document.visibilityState === "visible") refresh(); }, 5 * 60 * 1000);
    return () => { clearTimeout(initial); clearInterval(timer); pending.current?.abort(); pending.current = null; savePending.current?.abort(); savePending.current = null; };
  }, [refresh]);

  return (
    <div className="flex min-w-0 flex-col gap-4 px-1 sm:px-0">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="min-w-0">
          <h1 className="text-lg font-semibold text-text-main">{translate("Channel balances")}</h1>
          <p className="mt-1 text-sm text-text-muted">{translate("Upstream wallet and subscription balances, separate from OAuth quotas")}</p>
        </div>
        <Button size="lg" variant="outline" icon="refresh" loading={loading} disabled={saving} onClick={() => refresh(true)} className="shrink-0">{translate("Refresh balances")}</Button>
      </div>
      <Card padding="sm" className="text-xs leading-relaxed text-text-muted">
        {translate("Shows relay and public welfare channels. Wallet balances, subscription credit and raw key quotas stay separate; unknown amounts are never treated as zero.")}
        <p className="mt-1">{translate("Refreshes every 5 minutes while visible. Manual refresh has a 30-second minimum interval. Queries do not call models.")}</p>
      </Card>
      {snapshot && <ChannelBalanceControls options={snapshot.channelOptions} onChange={changeVisibility} saving={saving} error={saveError} />}
      {error && <div role="alert" className="rounded-xl border border-danger/30 bg-danger/10 p-3 text-sm text-danger">{translate(error)}{snapshot && <p className="mt-1 text-xs">{translate("Showing the previous snapshot; amounts may be stale")}</p>}</div>}
      {snapshot?.errors?.length > 0 && <div role="alert" className="space-y-1 rounded-lg border border-danger/30 bg-danger/10 p-3 text-sm text-danger">
        {snapshot.errors.map(failure => <p key={`${failure.channelId}:${failure.connectionId}`} className="break-words">{failure.channelName} · {failure.connectionName}: {formatChannelBalanceError(failure.error)}</p>)}
      </div>}
      {!snapshot && loading && <p role="status" className="py-10 text-center text-sm text-text-muted">{translate("Loading channel balances")}</p>}
      {snapshot && snapshot.channels.length === 0 && <Card className="py-10 text-center text-sm text-text-muted">{translate(snapshot.channelOptions.some(option => option.enabled) ? "No channel balances available" : snapshot.channelOptions.length ? "All channels are hidden. Enable a channel under Manage displayed channels." : "No compatible channels with API keys connected. Add a connection under Providers.")}</Card>}
      {snapshot && <div className="grid min-w-0 grid-cols-1 items-start gap-4 xl:grid-cols-2">{snapshot.channels.map((channel) => <ChannelBalanceCard key={channel.id} channel={channel} />)}</div>}
    </div>
  );
}
