"use client";

import React from "react";
import Card from "@/shared/components/Card";
import { translate } from "@/i18n/runtime";

export function applyChannelOptions(snapshot, options) {
  const enabled = new Set(options.filter(option => option.enabled).map(option => option.id));
  return { ...snapshot, channelOptions: options, channels: (snapshot?.channels || []).filter(channel => enabled.has(channel.id)), errors: (snapshot?.errors || []).filter(error => enabled.has(error.channelId)) };
}

export default function ChannelBalanceControls({ options, onChange, saving = false, error = null }) {
  return (
    <Card padding="sm">
      <details>
        <summary className="min-h-11 cursor-pointer py-3 text-sm font-semibold text-text-main">{translate("Manage displayed channels")}</summary>
        <p className="mt-1 text-xs leading-relaxed text-text-muted">{translate("Hidden channels are not queried, including manual refresh")}</p>
        <p className="mt-1 text-xs leading-relaxed text-text-muted">{translate("Saved automatically for all devices; model routing is unchanged")}</p>
        <p className="mt-1 text-xs leading-relaxed text-text-muted">{translate("Queries already in progress may finish")}</p>
        <div className="mt-3 grid min-w-0 gap-2 sm:grid-cols-2 xl:grid-cols-3">
          {options.map(option => <label key={option.id} className={`flex min-h-11 min-w-0 cursor-pointer items-center gap-3 rounded-lg border border-border p-3 ${saving ? "opacity-60" : "hover:bg-bg-alt/50"}`}>
            <input type="checkbox" role="switch" checked={option.enabled} aria-checked={option.enabled} disabled={saving} onChange={event => onChange(option.id, event.target.checked)} className="size-4 shrink-0 accent-primary" />
            <span className="min-w-0 break-words text-sm text-text-main">{option.name}{option.prefix && <span className="ml-2 text-xs text-text-muted">{option.prefix}/</span>}</span>
          </label>)}
        </div>
        {saving && <p role="status" className="mt-2 text-xs text-text-muted">{translate("Saving channel visibility")}</p>}
      </details>
      {error && <p role="alert" className="mt-2 break-words text-sm text-danger">{translate(error)}</p>}
    </Card>
  );
}
