function sanitizeErrorMessage(message) {
  return message
    .replace(/https?:\/\/[^\s"'<>]+/gi, value => {
      try {
        const url = new URL(value);
        return url.origin + url.pathname;
      } catch {
        return "[URL]";
      }
    })
    .replace(/\bBearer\s+[^\s,;"']+/gi, "Bearer [REDACTED]")
    .replace(/\bsk-[A-Za-z0-9_-]+/g, "[REDACTED]")
    .replace(/((?:authorization|cookie|api[_-]?key|access[_-]?token|refresh[_-]?token)["'\s:=]+)[^\s,;"'}]+/gi, "$1[REDACTED]")
    .replace(/<[^>]*>/g, "")
    .replace(/[\u0000-\u001f\u007f]/g, " ")
    .trim()
    .slice(0, 512);
}

export function getRequestError(detail) {
  const raw = detail.error ?? detail.response?.error;
  if (!raw) return undefined;
  const source = typeof raw === "object" ? raw.error || raw : {};
  const rawMessage = typeof raw === "string" ? raw : source.message;
  if (typeof rawMessage !== "string") return undefined;
  const codeMatch = rawMessage.match(/"code"\s*:\s*"([A-Za-z0-9_.:-]{1,96})"/);
  const messageMatch = rawMessage.match(/"message"\s*:\s*"((?:\\.|[^"\\])*)"/);
  let message = rawMessage;
  if (messageMatch) {
    try { message = JSON.parse('"' + messageMatch[1] + '"'); } catch {}
  }
  const code = typeof source.code === "string" && /^[A-Za-z0-9_.:-]{1,96}$/.test(source.code)
    ? source.code : codeMatch?.[1];
  const status = source.status ?? detail.response?.status;
  return {
    ...(Number.isInteger(status) && status >= 400 && status <= 599 ? { status } : {}),
    ...(code ? { code } : {}),
    message: sanitizeErrorMessage(message),
  };
}

export function getRequestUsageSource(detail) {
  if (["upstream", "estimated", "unavailable"].includes(detail.usageSource)) return detail.usageSource;
  if (detail.tokens?.estimated === true) return "estimated";
  return ["prompt_tokens", "completion_tokens", "input_tokens", "output_tokens"].some(field =>
    typeof detail.tokens?.[field] === "number" && detail.tokens[field] > 0
  ) ? "upstream" : "unavailable";
}
