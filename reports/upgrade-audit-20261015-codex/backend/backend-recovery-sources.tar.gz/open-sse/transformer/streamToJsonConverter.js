import { parseSSEEvents } from "../utils/sse.js";
import { STREAM_DISCONNECTED_ERROR } from "../config/errorConfig.js";

/**
 * Stream-to-JSON Converter
 * Converts Responses API SSE stream to single JSON response
 * Used when client requests non-streaming but provider forces streaming (e.g., Codex)
 */

/**
 * Process a single SSE message and update state accordingly.
 */
function processSSEMessage(msg, state) {
  for (const event of parseSSEEvents(msg)) {
    if (event.done) continue;
    const parsed = event.data;
    if (event.error || parsed?.error || event.event === "response.failed") {
      state.status = "failed";
      state.error = event.error || parsed.error || parsed.response?.error || {
        type: "stream_error", code: "upstream_error", message: "Upstream Responses stream failed"
      };
    }
    if (!parsed) continue;
    if (parsed.response) {
      state.response = { ...state.response, ...parsed.response };
      state.responseId = parsed.response.id || state.responseId;
      state.created = parsed.response.created_at || state.created;
    }
    if (event.event === "response.output_item.done") {
      state.items.set(parsed.output_index ?? 0, parsed.item);
    }
    if (["response.completed", "response.done", "response.incomplete", "response.failed"].includes(event.event)) {
      if (state.status !== "failed") state.status = event.event === "response.incomplete" ? "incomplete" : "completed";
      if (Array.isArray(parsed.response?.output)) state.output = parsed.response.output;
      if (parsed.response?.usage) state.usage = { ...EMPTY_RESPONSE, ...parsed.response.usage };
    }
  }
}

const EMPTY_RESPONSE = { input_tokens: 0, output_tokens: 0, total_tokens: 0 };

/**
 * Convert Responses API SSE stream to single JSON response
 * @param {ReadableStream} stream - SSE stream from provider
 * @returns {Promise<Object>} Final JSON response in Responses API format
 */
export async function convertResponsesStreamToJson(stream) {
  if (!stream || typeof stream.getReader !== "function") {
    return { id: `resp_${Date.now()}`, object: "response", created_at: Math.floor(Date.now() / 1000), status: "failed", output: [], usage: { ...EMPTY_RESPONSE } };
  }

  const reader = stream.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  const state = {
    responseId: "",
    created: Math.floor(Date.now() / 1000),
    status: "in_progress",
    usage: { ...EMPTY_RESPONSE },
    response: {},
    items: new Map()
  };

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const messages = buffer.split(/\r\n\r\n|\n\n|\r\r/);
      buffer = messages.pop() || "";

      for (const msg of messages) {
        processSSEMessage(msg, state);
      }
    }

    // Flush remaining buffer (last event may not end with \n\n)
    buffer += decoder.decode();
    if (buffer.trim()) {
      processSSEMessage(buffer, state);
    }
  } finally {
    reader.releaseLock();
  }

  if (state.status === "in_progress") {
    state.status = "failed";
    state.error = { ...STREAM_DISCONNECTED_ERROR };
  }
  // Build output array from accumulated items (ordered by index)
  const output = [];
  const maxIndex = state.items.size > 0 ? Math.max(...state.items.keys()) : -1;
  for (let i = 0; i <= maxIndex; i++) {
    output.push(state.items.get(i) || { type: "message", content: [], role: "assistant" });
  }

  return {
    ...state.response,
    id: state.responseId || `resp_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    object: "response",
    created_at: state.created,
    status: state.status,
    output: state.output || output,
    usage: state.usage,
    ...(state.error ? { error: state.error } : {})
  };
}
