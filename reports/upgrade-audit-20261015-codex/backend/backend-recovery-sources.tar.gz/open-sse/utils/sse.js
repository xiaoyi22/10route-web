import { INVALID_SSE_ERROR } from "../config/errorConfig.js";

export function sseChunk(data) {
  return `data: ${JSON.stringify(data)}\n\n`;
}

// Keep incomplete events between chunks, including a CRLF split across reads.
export function createSSEFrameParser() {
  let buffer = "";
  let skipLeadingLF = false;
  return (text, flush = false) => {
    if (text) {
      if (skipLeadingLF && text.startsWith("\n")) text = text.slice(1);
      skipLeadingLF = text.endsWith("\r");
      buffer += text.replace(/\r\n|\r/g, "\n");
    }
    const frames = buffer.split("\n\n");
    buffer = frames.pop() || "";
    if (flush) {
      if (buffer.trim()) frames.push(buffer);
      buffer = "";
    }
    return frames;
  };
}

export function parseSSEEvents(rawSSE) {
  const events = [];
  for (const frame of createSSEFrameParser()(String(rawSSE || ""), true)) {
    let event = null;
    const dataLines = [];
    for (const line of frame.split(/\r\n|\n|\r/)) {
      if (line.startsWith("event:")) event = line.slice(6).trim();
      else if (line.startsWith("data:")) dataLines.push(line.slice(5).trimStart());
    }
    if (dataLines.length === 0) continue;
    const payload = dataLines.join("\n").trim();
    if (payload === "[DONE]") {
      events.push({ done: true });
      continue;
    }
    try {
      const data = JSON.parse(payload);
      events.push({ event: event || data?.type || null, data });
    } catch {
      events.push({ error: { ...INVALID_SSE_ERROR } });
    }
  }
  return events;
}

// Build OpenAI chat.completion.chunk SSE frame. Key order: id, object, created, model, choices.
export function chatChunkSse({ id, created, model, delta, finishReason = null }) {
  return sseChunk({
    id,
    object: "chat.completion.chunk",
    created,
    model,
    choices: [{ index: 0, delta, finish_reason: finishReason }],
  });
}
