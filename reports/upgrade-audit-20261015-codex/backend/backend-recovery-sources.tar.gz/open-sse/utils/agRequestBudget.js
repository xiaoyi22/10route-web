/**
 * Per-request budget tracker for AG (auto-generation) flows.
 * Caps generation attempts, credential tries, refresh attempts and total wait time.
 * Fail-closed on exhaustion: count*() returns false once the limit is reached.
 */

export function createAgRequestBudget(overrides = {}) {
  const limits = {
    maxGenerationAttempts: 3,
    maxCredentials: 2,
    maxRefreshAttempts: 1,
    maxTotalWaitMs: 15000,
    ...overrides,
  };

  let gen = 0;
  let ref = 0;
  let cred = 0;
  let waitMs = 0;
  let exhaustedReason = null;

  function countGeneration() {
    if (gen >= limits.maxGenerationAttempts) {
      exhaustedReason = "generation";
      return false;
    }
    gen++;
    return true;
  }

  function countRefresh() {
    if (ref >= limits.maxRefreshAttempts) {
      exhaustedReason = "refresh";
      return false;
    }
    ref++;
    return true;
  }

  function countCredential() {
    if (cred >= limits.maxCredentials) {
      exhaustedReason = "credential";
      return false;
    }
    cred++;
    return true;
  }

  // canWait answers "does the NEXT wait still fit the budget?" — it only
  // reflects waitMs on purpose. It must NOT set exhaustedReason: the reason
  // string feeds isAgRequestBudgetExhausted(), which the f-case (and any
  // "budget not exhausted" assertion) relies on staying false after a merely
  // refused backoff wait. Only actual caps (generation/refresh/credential)
  // or the base executor set exhausted reasons; base.js returns the current
  // error response with budgetExhausted=true when canWait refuses.
  function canWait(ms) {
    return waitMs + ms <= limits.maxTotalWaitMs;
  }

  function spendWait(ms) {
    waitMs += ms;
  }

  function snapshot() {
    return {
      generationAttempts: gen,
      refreshAttempts: ref,
      waitMs,
      credentialsTried: cred,
      exhaustedReason,
    };
  }

  return {
    countGeneration,
    countRefresh,
    countCredential,
    canWait,
    spendWait,
    snapshot,
  };
}

export function isAgRequestBudgetExhausted(b) {
  return !!b.snapshot().exhaustedReason;
}
