import { AG_FORBIDDEN_COOLDOWN_MS } from "../config/errorConfig.js";

export { AG_FORBIDDEN_COOLDOWN_MS };

// Next can bundle the engine more than once in one Node process.
const stateKey = Symbol.for("10router.antigravityQuarantine");
const state = globalThis[stateKey] ||= { connections: new Map(), persist: null, read: null };

export function setQuarantinePersistenceHandler(fn) {
  state.persist = fn;
}

export function setQuarantineReadHandler(fn) {
  state.read = fn;
}

export const AG_TOS_DISABLED_SENTENCE = "This service has been disabled in this account for violation of Terms of Service.";

export function classifyAntigravityError(status, body) {
  const no = { isTos: false, reason: null };
  if (status !== 403 || !body) return no;
  let json = body;
  let text = "";
  if (typeof body === "string") {
    try { json = JSON.parse(body); }
    catch { json = null; text = body.trim(); }
  }
  const details = json?.error?.details;
  if (Array.isArray(details) && details.some(d =>
    d?.["@type"] === "type.googleapis.com/google.rpc.ErrorInfo" && d.reason === "TOS_VIOLATION"
  )) return { isTos: true, reason: "TOS_VIOLATION" };

  // Only the upstream error message, never arbitrary JSON fields or echoed prompts.
  if (json !== null) text = typeof json?.error?.message === "string" ? json.error.message.trim() : "";
  if (text === AG_TOS_DISABLED_SENTENCE || text === `${AG_TOS_DISABLED_SENTENCE} Please submit an appeal to continue using this product.`) {
    return { isTos: true, reason: "TOS_VIOLATION" };
  }
  return no;
}

export function isConnectionQuarantined(connectionId) {
  return !!connectionId && state.connections.has(connectionId);
}

export function getQuarantinedConnection(connectionId) {
  return state.connections.get(connectionId) || null;
}

export function hasPersistedQuarantine(credentials) {
  const conn = credentials?._connection || credentials;
  return !!conn?.quarantine || conn?.testStatus === "quarantined";
}

export function quarantineConnection(connectionId, reason = "TOS_VIOLATION") {
  if (!connectionId) return;
  state.connections.set(connectionId, {
    reason: String(reason || "TOS_VIOLATION").slice(0, 500),
    quarantinedAt: new Date().toISOString(),
    persisted: false,
  });
}

// Only call after an explicit manual release has committed to storage.
export function unquarantineConnection(connectionId, expected = state.connections.get(connectionId)) {
  if (state.connections.get(connectionId) === expected) state.connections.delete(connectionId);
}

export function resetQuarantineMemory() {
  state.connections.clear();
}

export async function getAntigravityBlockReason(credentials) {
  if (credentials?._agRequestState?.tosResponse) return "AG_TOS_QUARANTINED";
  const id = credentials?.connectionId || credentials?.id || credentials?._connection?.id;
  const memory = getQuarantinedConnection(id);
  if (id && state.read) {
    // Read failures fail closed: callers must not send a request with unknown state.
    let current;
    try { current = await state.read(id); }
    catch (cause) {
      throw Object.assign(new Error("Unable to verify AG quarantine state; request blocked", { cause }), { code: "AG_QUARANTINE_CHECK_FAILED" });
    }
    if (hasPersistedQuarantine(current)) return "AG_TOS_QUARANTINED";
    // Another process may have explicitly released a persisted quarantine.
    if (memory?.persisted && current) unquarantineConnection(id, memory);
    if (isConnectionQuarantined(id)) return "AG_TOS_QUARANTINED";
    return !current || current.isActive === false ? "AG_CONNECTION_DISABLED" : null;
  }
  if (memory || hasPersistedQuarantine(credentials)) return "AG_TOS_QUARANTINED";
  return (credentials?._connection || credentials)?.isActive === false ? "AG_CONNECTION_DISABLED" : null;
}

export async function isAntigravityBlocked(credentials) {
  return !!(await getAntigravityBlockReason(credentials));
}

export function isAntigravityBlockError(error) {
  return ["AG_TOS_QUARANTINED", "AG_CONNECTION_DISABLED", "AG_QUARANTINE_CHECK_FAILED"].includes(error?.code);
}

export async function assertAntigravityAllowed(credentials) {
  const code = await getAntigravityBlockReason(credentials);
  if (code) {
    throw Object.assign(new Error("Antigravity connection is quarantined, disabled or removed; request blocked locally"), { code });
  }
}

export async function checkAntigravityResponse(response, credentials, log = null) {
  if (response.status === 403) {
    const classification = classifyAntigravityError(response.status, await response.clone().text());
    if (classification.isTos) {
      const id = credentials?.connectionId || credentials?.id || credentials?._connection?.id;
      const result = await persistQuarantine(id, classification.reason, log);
      throw Object.assign(new Error(result.persisted ? "Antigravity TOS quarantine persisted; manual release required" : result.error), { code: "AG_TOS_QUARANTINED" });
    }
  }
  return response;
}

export async function persistQuarantine(connectionId, reason = "TOS_VIOLATION", log = null) {
  if (!connectionId || connectionId === "noauth") {
    const message = "Cannot persist AG quarantine without a connection ID; current request stopped only.";
    console.error(`[QUARANTINE_PERSIST_ERROR] ${message}`);
    log?.error?.("QUARANTINE", message);
    return { persisted: false, error: message };
  }
  quarantineConnection(connectionId, reason);
  const entry = getQuarantinedConnection(connectionId);
  try {
    if (!state.persist) throw new Error("Quarantine persistence handler is not registered");
    await state.persist(connectionId, { reason: entry.reason, quarantinedAt: entry.quarantinedAt });
    entry.persisted = true;
    return { persisted: true };
  } catch (err) {
    const message = `Failed to persist quarantine for ${connectionId}: ${err.message}. Blocked in this process ONLY; not guaranteed across processes or restarts.`;
    console.error(`[QUARANTINE_PERSIST_ERROR] ${message}`);
    log?.error?.("QUARANTINE", message);
    return { persisted: false, error: message };
  }
}
