import { NextResponse } from "next/server";
import { tickMonitor } from "@/lib/iqMonitor/service";

export const dynamic = "force-dynamic";

export async function POST(request) {
  const token = process.env.TENROUTER_IQ_TOKEN;
  if (!token || request.headers.get("x-10r-iq-token") !== token) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  try { await tickMonitor(); return NextResponse.json({ ok: true }); }
  catch (error) { console.error("[IQ monitor]", error); return NextResponse.json({ error: "IQ monitor failed" }, { status: 500 }); }
}
