import { NextResponse } from "next/server";
import { verifyDashboardAuthToken, verifyDashboardPassword } from "@/lib/auth/dashboardSession";
import { readDashboardPassword } from "@/lib/auth/authHeaders";
import { checkLock, recordFail, recordSuccess, getClientIp } from "@/lib/auth/loginLimiter";
import * as cowork from "../cli-tools/cowork-settings/route";
import { GET as cursorLogin } from "../oauth/cursor/auto-import/route";
import { GET as kiroLogin } from "../oauth/kiro/auto-import/route";
import { GET as zedLogin } from "../oauth/zed/auto-import/route";
import { GET as mimoLogin } from "../oauth/xiaomi-mimo/auto-import/route";
import { POST as startHeadroom } from "../headroom/start/route";
import { POST as stopHeadroom } from "../headroom/stop/route";
import { POST as restartHeadroom } from "../headroom/restart/route";

export const dynamic = "force-dynamic";

const operations = new Map([
  ["cowork.read", cowork.GET], ["cowork.apply", cowork.POST], ["cowork.remove", cowork.DELETE],
  ["credentials.cursor", cursorLogin], ["credentials.kiro", kiroLogin],
  ["credentials.zed", zedLogin], ["credentials.xiaomi-mimo", mimoLogin],
  ["headroom.start", startHeadroom], ["headroom.stop", stopHeadroom], ["headroom.restart", restartHeadroom],
]);

export async function POST(request) {
  const json = (body, status = 200, headers = {}) => NextResponse.json(body, {
    status, headers: { "Cache-Control": "no-store", ...headers },
  });
  if (!(await verifyDashboardAuthToken(request.cookies.get("auth_token")?.value))) {
    return json({ error: "Unauthorized" }, 401);
  }
  const origin = request.headers.get("origin");
  try {
    if (request.headers.get("sec-fetch-site") === "cross-site" ||
        (origin && new URL(origin).host !== request.headers.get("host"))) {
      return json({ error: "Request origin does not match" }, 403);
    }
  } catch { return json({ error: "Invalid request origin" }, 403); }
  let body;
  try { body = await request.json(); } catch { return json({ error: "Invalid JSON" }, 400); }
  const handler = operations.get(body?.operation);
  if (!handler) return json({ error: "Host operation is not allowed" }, 400);
  const ip = getClientIp(request);
  const lock = checkLock(ip);
  if (lock.locked) return json({ error: "Too many failed attempts" }, 429, { "Retry-After": String(lock.retryAfter) });
  if (!(await verifyDashboardPassword(readDashboardPassword(request)))) {
    recordFail(ip);
    return json({ error: "Invalid administrator password" }, 401);
  }
  recordSuccess(ip);
  const delegated = new Request(request.url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body.payload || {}) });
  const response = await handler(delegated);
  const result = await response.json();
  // Cowork's raw config contains the machine CLI token; only expose UI status.
  if (body.operation === "cowork.read") delete result.config;
  if (response.ok && ["cowork.apply", "cowork.remove"].includes(body.operation)) {
    const status = await (await cowork.GET()).json();
    delete status.config;
    result.status = status;
  }
  return json(result, response.status);
}
