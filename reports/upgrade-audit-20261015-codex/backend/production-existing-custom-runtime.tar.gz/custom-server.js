const http = require("http");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const { pathToFileURL } = require("url");

const origCreate = http.createServer.bind(http);

// Per-process secret proving x-10r-real-ip was stamped below rather than sent by the client.
// A bare `next start` / `next dev` never loads this file, so it cannot produce a matching
// header even though the env var is inherited by child processes. Named like x-9r-cli-token
// so the request-detail header sanitizer redacts it too.
const PEER_TOKEN = crypto.randomBytes(24).toString("hex");
process.env.TENROUTER_PEER_TOKEN = PEER_TOKEN;
process.env.TENROUTER_IQ_TOKEN = crypto.randomBytes(32).toString("hex");
let iqMonitorStarted = false;

function startIqMonitor(server) {
  if (iqMonitorStarted) return;
  const address = server.address();
  if (!address || typeof address === "string") return;
  iqMonitorStarted = true;
  let busy = false;
  const tick = async () => {
    if (busy) return;
    busy = true;
    try {
      const response = await fetch(`http://127.0.0.1:${address.port}/api/iq-monitor/tick`, { method: "POST", headers: { "x-10r-iq-token": process.env.TENROUTER_IQ_TOKEN } });
      await response.text();
      if (!response.ok) console.error(`[IQ monitor] scheduler HTTP ${response.status}`);
    } catch (error) { console.error("[IQ monitor] scheduler", error.message); }
    finally { busy = false; }
  };
  const timer = setInterval(tick, 30000);
  timer.unref();
  server.once("close", () => clearInterval(timer));
}

// Long-term console archive: tee server console output into a per-day file under
// the data dir (logs/app-YYYY-MM-DD.log, append-only, no cap — the durable record
// of upstream answers / request failures that requestDetails' 200-record ring
// buffer and the desktop 5MB server.log don't keep). Runs only from this file, so
// `next dev` keeps its plain console. Best-effort: a bare repo checkout without
// the standalone copy simply skips it.
import(pathToFileURL(path.join(__dirname, "src", "lib", "consoleArchiveStandalone.mjs")))
  .then((m) => m.installConsoleArchive())
  .catch(() => {});

// Full-Route-Cache staleness guard: an over-install upgrade (NSIS, fpk, npm -g,
// manual untar) writes the new build on top of the old tree but leaves the
// previous build's Full Route Cache under <distDir>/server/route-cache —
// prerendered HTML/RSC that references the OLD hashed static chunks. The new
// server happily serves those entries, so the dashboard keeps rendering the old
// bundle (sidebar version pill stuck at the previous version) even though
// package.json and /api/version already report the new release. Wipe that cache
// whenever BUILD_ID differs from the marker we last booted with. Marker lives
// next to route-cache (not inside it) so a wipe cannot erase the proof.
function pruneStaleRouteCache(root = __dirname) {
  for (const distDirName of [".next-cli-build", ".next"]) {
    try {
      const distDir = path.join(root, distDirName);
      let buildId;
      try {
        buildId = fs.readFileSync(path.join(distDir, "BUILD_ID"), "utf8").trim();
      } catch {
        continue; // bare checkout without a build for this distDir
      }
      if (!buildId) continue;
      const routeCache = path.join(distDir, "server", "route-cache");
      const markerPath = path.join(distDir, "server", ".route-cache-build-id");
      let marker = null;
      try {
        marker = fs.readFileSync(markerPath, "utf8").trim();
      } catch {
        /* first boot with the guard */
      }
      if (marker === buildId) continue;
      if (fs.existsSync(routeCache)) {
        fs.rmSync(routeCache, { recursive: true, force: true });
        console.warn(
          `[route-cache] pruned stale Full Route Cache from a previous build in ${distDirName}`
        );
      }
      fs.mkdirSync(path.dirname(markerPath), { recursive: true });
      fs.writeFileSync(markerPath, buildId + "\n");
    } catch {
      /* best-effort — a cache prune must never block boot */
    }
  }
}
pruneStaleRouteCache();

let backgroundRefreshStarted = false;

// Apply the outbound proxy from DB settings at boot. This is the Node-side
// replacement for the `@/lib/network/initOutboundProxy` import in layout.js,
// which Next tree-shakes out of the standalone build. Runs in custom-server.js
// (always loaded, never tree-shaken) so process.env.HTTP(S)_PROXY is restored
// on every restart instead of waiting for the user to re-save settings.
let outboundProxyStarted = false;
function startOutboundProxyFromCustomServer() {
  if (outboundProxyStarted) return;
  outboundProxyStarted = true;
  const modPath = path.join(__dirname, "src", "lib", "network", "outboundProxyStandalone.js");
  import(pathToFileURL(modPath).href)
    .then((m) => {
      try {
        m.ensureOutboundProxyInitialized();
      } catch (e) {
        console.error("[OutboundProxyInit] start failed:", e && e.message ? e.message : e);
      }
    })
    .catch((e) => {
      // Expected in a bare repo checkout (src/lib/network not shipped). The Next
      // app bootstrap (layout.js initOutboundProxy) covers it in dev.
      if (process.env.DEBUG_OUTBOUND_PROXY) {
        console.error("[OutboundProxyInit] import failed:", e && e.message ? e.message : e);
      }
    });
}

function startBackgroundTokenRefreshFromCustomServer() {
  if (backgroundRefreshStarted) return;
  backgroundRefreshStarted = true;
  // Prefer source path (repo / standalone that still has src). Fail-open if missing
  // — initializeApp also starts the same scheduler when the Next app boots.
  const modPath = path.join(__dirname, "src", "sse", "services", "backgroundTokenRefresh.js");
  import(pathToFileURL(modPath).href)
    .then((m) => {
      try {
        m.startBackgroundTokenRefresh();
      } catch (e) {
        console.error("[BackgroundTokenRefresh] start failed:", e && e.message ? e.message : e);
      }
      const stop = () => {
        try {
          m.stopBackgroundTokenRefresh();
        } catch {
          /* ignore */
        }
      };
      process.once("SIGINT", stop);
      process.once("SIGTERM", stop);
    })
    .catch((e) => {
      // Expected in published CLI standalone (src/ not on disk). App bootstrap covers it.
      if (process.env.DEBUG_BACKGROUND_TOKEN_REFRESH) {
        console.error("[BackgroundTokenRefresh] import failed:", e && e.message ? e.message : e);
      }
    });
}

// Wrap Next standalone HTTP server: derive client IP from the TCP socket
// (unspoofable) and strip client-supplied forwarding headers so downstream
// rate-limiting keys on the real peer address instead of attacker-controlled XFF.
http.createServer = (...args) => {
  const handler = args.find((a) => typeof a === "function");
  const rest = args.filter((a) => typeof a !== "function");
  if (!handler) return origCreate(...args);
  const wrapped = (req, res) => {
    const socketIp = req.socket && req.socket.remoteAddress ? req.socket.remoteAddress : "";
    const xff = req.headers["x-forwarded-for"];
    const xRealIp = req.headers["x-real-ip"];
    const viaProxy = !!(xff || xRealIp);
    const isLoopbackProxy = socketIp === "127.0.0.1" || socketIp === "::1" || socketIp === "::ffff:127.0.0.1";
    // Trust forwarding headers only when the TCP peer is a local reverse proxy.
    // Direct/public sockets remain keyed by the unspoofable peer address.
    const proxyIp = xRealIp || (xff ? String(xff).split(",")[0].trim() : "");
    const ip = isLoopbackProxy && proxyIp ? proxyIp : socketIp;
    delete req.headers["x-10r-real-ip"];
    delete req.headers["x-forwarded-for"];
    delete req.headers["x-10r-via-proxy"];
    delete req.headers["x-10r-peer-token"];
    req.headers["x-10r-real-ip"] = ip;
    req.headers["x-10r-peer-token"] = PEER_TOKEN;
    if (viaProxy) req.headers["x-10r-via-proxy"] = "1";
    return handler(req, res);
  };
  const server = origCreate(...rest, wrapped);
  server.once("listening", () => {
    startBackgroundTokenRefreshFromCustomServer();
    startOutboundProxyFromCustomServer();
    startIqMonitor(server);
  });
  const origEmit = server.emit;
  // JBR 25 sends h2c upgrades that the HTTP/1.1 server would otherwise close.
  server.emit = function (event, ...eventArgs) {
    const [req, socket, head] = eventArgs;
    if (event !== "upgrade" || String(req.headers.upgrade || "").toLowerCase() !== "h2c") {
      return origEmit.call(this, event, ...eventArgs);
    }

    const contentLength = Number(req.headers["content-length"] || 0);
    if (!Number.isSafeInteger(contentLength) || contentLength < 0) {
      socket.destroy();
      return true;
    }
    const chunks = [head];
    let received = head.length;
    const serve = () => {
      // Replay the upgraded request through the existing HTTP/1.1 handler.
      const replay = new http.IncomingMessage(socket);
      Object.assign(replay, { method: req.method, url: req.url, headers: req.headers, complete: true });
      if (received) replay.push(Buffer.concat(chunks, received).subarray(0, contentLength));
      replay.push(null);
      const res = new http.ServerResponse(replay);
      res.shouldKeepAlive = false;
      res.assignSocket(socket);
      res.once("finish", () => socket.end());
      Promise.resolve().then(() => wrapped(replay, res)).catch((error) => {
        console.error("Failed to downgrade h2c request", error);
        socket.destroy();
      });
    };
    if (received >= contentLength) serve();
    else {
      socket.on("data", function readBody(chunk) {
        chunks.push(chunk);
        received += chunk.length;
        if (received < contentLength) return;
        socket.off("data", readBody);
        serve();
      });
      socket.resume();
    }
    delete req.headers.upgrade;
    delete req.headers["http2-settings"];
    req.headers.connection = "close";
    return true;
  };
  return server;
};

if (require.main === module) {
  const standalone = path.join(__dirname, "server.js");
  if (fs.existsSync(standalone)) {
    require(standalone);
  } else {
    // Repo checkout has no standalone build next to us. `next start` builds its HTTP
    // server in-process, so the wrapper above still sanitizes every request.
    const nextBin = require.resolve("next/dist/bin/next");
    process.argv = [process.argv[0], nextBin, "start", ...process.argv.slice(2)];
    require(nextBin);
  }
}

module.exports = { pruneStaleRouteCache };
